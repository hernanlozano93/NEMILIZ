(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.avion = function() {
	this.initialize(img.avion);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1134,397);


(lib.Chica = function() {
	this.initialize(img.Chica);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,566,1266);


(lib.Chico = function() {
	this.initialize(img.Chico);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,452,1428);


(lib.Fondo1 = function() {
	this.initialize(img.Fondo1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,662,298);


(lib.Fondo2 = function() {
	this.initialize(img.Fondo2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1626,543);


(lib.Fondo3 = function() {
	this.initialize(img.Fondo3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,556,292);


(lib.Fondo4 = function() {
	this.initialize(img.Fondo4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,810,406);


(lib.Fondo5 = function() {
	this.initialize(img.Fondo5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,808,364);


(lib.FondoPersonaje = function() {
	this.initialize(img.FondoPersonaje);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5701,3200);


(lib.Intro1366768 = function() {
	this.initialize(img.Intro1366768);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5700,3200);


(lib.Intro21366768 = function() {
	this.initialize(img.Intro21366768);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5699,3202);


(lib.IntroTitulo1366768 = function() {
	this.initialize(img.IntroTitulo1366768);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2874,781);


(lib.TextosInicial2 = function() {
	this.initialize(img.TextosInicial2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1686,1083);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Volver4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIAAgrIAAgrQABgqgIgcIgBgCQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAdgGQADAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKAQAAQALAAAAAFIgCAOIgBAPIAAAOIAAAOQABAHgIAAIgKAAIgKgBQgPAAgGAFQgFAFAAANIAAAYIAAAXIACAQIAAAPQAAAFgGAAIgaABIgbgBg");
	this.shape.setTransform(46.8,1.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag7BFQgbgZAAgrQAAgoAYgbQAZgbAoAAQAjAAAYAZQAZAZAAAjQAAARgMADIgmAEIg+AGQACALANAGQAKAFANAAQAQAAAQgIIAOgJQAEACAJARQAJAQAAAFIgDAEQgWAXguAAQgqAAgbgZgAgVglQgHAIAAAMQAAAFAFAAQANAAAbgEQAGgBAAgCQAAgLgIgJQgIgIgKAAQgLAAgHAKg");
	this.shape_1.setTransform(30.325,1.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWBVQgDgBgDgCQgLgMgUgdQgWgfgDgLQgFgMAAgZIAAgWIAAgVQAAgFAHAAIAcABIAbAAQAEAAAAAGIgBAPIgBAQQAAASACAMQAAAHALAPQAJASAEAAQAFAAAKgRQAKgQAAgGQACgMgBgTIgBgPIAAgQQAAgGADAAIANABIANAAIANgBIANgBQAEAAACAFQADAKAAAgQAAAfgCAFQgEAMgVAfQgSAagMAPQgGAGgXAAQgTAAgHgCg");
	this.shape_2.setTransform(10.95,1.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbB+QgEgBgBgEIAAgHIABgwIAAgxIAAhEQAAgogEgdIgBgDQAAgEAFAAIBAAAQAEAAAAAEIAAADQgFBPAAA6IAABMIABAOIAAAPQAAAEgEAAQgIACgVAAQgVAAgGgCg");
	this.shape_3.setTransform(-3.9225,-2.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_4.setTransform(-18.625,1.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdB/QgEgBgCgFIgqhRQgghBAAgJIABgrIABgrQAAgGADAAIAhABIAhABQAFAAAAADIgCAsIgCAsQAAAMAkBDQAJgRANgbQARghAAgJIAAgnIgBgnQAAgGACAAIAGAAIAegBIAegBQAFAAAAAEIAAArIgBAqQAAALgjBGIgpBNIgCAFIgFABIgcAAIgbAAg");
	this.shape_5.setTransform(-40.425,-2.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_6.setTransform(0.5,-2.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_7.setTransform(0.5,-2.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_8.setTransform(0.5,-2.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_9.setTransform(0.5,-2.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_10.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).to({state:[{t:this.shape_8},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_6}]},1).to({state:[{t:this.shape_10}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.Volver3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIAAgrIAAgrQABgqgIgcIgBgCQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAdgGQADAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKAQAAQALAAAAAFIgCAOIgBAPIAAAOIAAAOQABAHgIAAIgKAAIgKgBQgPAAgGAFQgFAFAAANIAAAYIAAAXIACAQIAAAPQAAAFgGAAIgaABIgbgBg");
	this.shape.setTransform(46.8,1.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag7BFQgbgZAAgrQAAgoAYgbQAZgbAoAAQAjAAAYAZQAZAZAAAjQAAARgMADIgmAEIg+AGQACALANAGQAKAFANAAQAQAAAQgIIAOgJQAEACAJARQAJAQAAAFIgDAEQgWAXguAAQgqAAgbgZgAgVglQgHAIAAAMQAAAFAFAAQANAAAbgEQAGgBAAgCQAAgLgIgJQgIgIgKAAQgLAAgHAKg");
	this.shape_1.setTransform(30.325,1.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWBVQgDgBgDgCQgLgMgUgdQgWgfgDgLQgFgMAAgZIAAgWIAAgVQAAgFAHAAIAcABIAbAAQAEAAAAAGIgBAPIgBAQQAAASACAMQAAAHALAPQAJASAEAAQAFAAAKgRQAKgQAAgGQACgMgBgTIgBgPIAAgQQAAgGADAAIANABIANAAIANgBIANgBQAEAAACAFQADAKAAAgQAAAfgCAFQgEAMgVAfQgSAagMAPQgGAGgXAAQgTAAgHgCg");
	this.shape_2.setTransform(10.95,1.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbB+QgEgBgBgEIAAgHIABgwIAAgxIAAhEQAAgogEgdIgBgDQAAgEAFAAIBAAAQAEAAAAAEIAAADQgFBPAAA6IAABMIABAOIAAAPQAAAEgEAAQgIACgVAAQgVAAgGgCg");
	this.shape_3.setTransform(-3.9225,-2.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_4.setTransform(-18.625,1.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdB/QgEgBgCgFIgqhRQgghBAAgJIABgrIABgrQAAgGADAAIAhABIAhABQAFAAAAADIgCAsIgCAsQAAAMAkBDQAJgRANgbQARghAAgJIAAgnIgBgnQAAgGACAAIAGAAIAegBIAegBQAFAAAAAEIAAArIgBAqQAAALgjBGIgpBNIgCAFIgFABIgcAAIgbAAg");
	this.shape_5.setTransform(-40.425,-2.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_6.setTransform(0.5,-2.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_7.setTransform(0.5,-2.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_8.setTransform(0.5,-2.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_9.setTransform(0.5,-2.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_10.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).to({state:[{t:this.shape_8},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_6}]},1).to({state:[{t:this.shape_10}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.Volver2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIAAgrIAAgrQABgqgIgcIgBgCQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAdgGQADAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKAQAAQALAAAAAFIgCAOIgBAPIAAAOIAAAOQABAHgIAAIgKAAIgKgBQgPAAgGAFQgFAFAAANIAAAYIAAAXIACAQIAAAPQAAAFgGAAIgaABIgbgBg");
	this.shape.setTransform(46.8,1.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag7BFQgbgZAAgrQAAgoAYgbQAZgbAoAAQAjAAAYAZQAZAZAAAjQAAARgMADIgmAEIg+AGQACALANAGQAKAFANAAQAQAAAQgIIAOgJQAEACAJARQAJAQAAAFIgDAEQgWAXguAAQgqAAgbgZgAgVglQgHAIAAAMQAAAFAFAAQANAAAbgEQAGgBAAgCQAAgLgIgJQgIgIgKAAQgLAAgHAKg");
	this.shape_1.setTransform(30.325,1.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWBVQgDgBgDgCQgLgMgUgdQgWgfgDgLQgFgMAAgZIAAgWIAAgVQAAgFAHAAIAcABIAbAAQAEAAAAAGIgBAPIgBAQQAAASACAMQAAAHALAPQAJASAEAAQAFAAAKgRQAKgQAAgGQACgMgBgTIgBgPIAAgQQAAgGADAAIANABIANAAIANgBIANgBQAEAAACAFQADAKAAAgQAAAfgCAFQgEAMgVAfQgSAagMAPQgGAGgXAAQgTAAgHgCg");
	this.shape_2.setTransform(10.95,1.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbB+QgEgBgBgEIAAgHIABgwIAAgxIAAhEQAAgogEgdIgBgDQAAgEAFAAIBAAAQAEAAAAAEIAAADQgFBPAAA6IAABMIABAOIAAAPQAAAEgEAAQgIACgVAAQgVAAgGgCg");
	this.shape_3.setTransform(-3.9225,-2.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_4.setTransform(-18.625,1.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdB/QgEgBgCgFIgqhRQgghBAAgJIABgrIABgrQAAgGADAAIAhABIAhABQAFAAAAADIgCAsIgCAsQAAAMAkBDQAJgRANgbQARghAAgJIAAgnIgBgnQAAgGACAAIAGAAIAegBIAegBQAFAAAAAEIAAArIgBAqQAAALgjBGIgpBNIgCAFIgFABIgcAAIgbAAg");
	this.shape_5.setTransform(-40.425,-2.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_6.setTransform(0.5,-2.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_7.setTransform(0.5,-2.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_8.setTransform(0.5,-2.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_9.setTransform(0.5,-2.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_10.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).to({state:[{t:this.shape_8},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_6}]},1).to({state:[{t:this.shape_10}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.Volver = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIAAgrIAAgrQABgqgIgcIgBgCQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAdgGQADAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKAQAAQALAAAAAFIgCAOIgBAPIAAAOIAAAOQABAHgIAAIgKAAIgKgBQgPAAgGAFQgFAFAAANIAAAYIAAAXIACAQIAAAPQAAAFgGAAIgaABIgbgBg");
	this.shape.setTransform(46.8,1.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag7BFQgbgZAAgrQAAgoAYgbQAZgbAoAAQAjAAAYAZQAZAZAAAjQAAARgMADIgmAEIg+AGQACALANAGQAKAFANAAQAQAAAQgIIAOgJQAEACAJARQAJAQAAAFIgDAEQgWAXguAAQgqAAgbgZgAgVglQgHAIAAAMQAAAFAFAAQANAAAbgEQAGgBAAgCQAAgLgIgJQgIgIgKAAQgLAAgHAKg");
	this.shape_1.setTransform(30.325,1.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgWBVQgDgBgDgCQgLgMgUgdQgWgfgDgLQgFgMAAgZIAAgWIAAgVQAAgFAHAAIAcABIAbAAQAEAAAAAGIgBAPIgBAQQAAASACAMQAAAHALAPQAJASAEAAQAFAAAKgRQAKgQAAgGQACgMgBgTIgBgPIAAgQQAAgGADAAIANABIANAAIANgBIANgBQAEAAACAFQADAKAAAgQAAAfgCAFQgEAMgVAfQgSAagMAPQgGAGgXAAQgTAAgHgCg");
	this.shape_2.setTransform(10.95,1.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbB+QgEgBgBgEIAAgHIABgwIAAgxIAAhEQAAgogEgdIgBgDQAAgEAFAAIBAAAQAEAAAAAEIAAADQgFBPAAA6IAABMIABAOIAAAPQAAAEgEAAQgIACgVAAQgVAAgGgCg");
	this.shape_3.setTransform(-3.9225,-2.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_4.setTransform(-18.625,1.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdB/QgEgBgCgFIgqhRQgghBAAgJIABgrIABgrQAAgGADAAIAhABIAhABQAFAAAAADIgCAsIgCAsQAAAMAkBDQAJgRANgbQARghAAgJIAAgnIgBgnQAAgGACAAIAGAAIAegBIAegBQAFAAAAAEIAAArIgBAqQAAALgjBGIgpBNIgCAFIgFABIgcAAIgbAAg");
	this.shape_5.setTransform(-40.425,-2.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_6.setTransform(0.5,-2.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_7.setTransform(0.5,-2.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_8.setTransform(0.5,-2.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_9.setTransform(0.5,-2.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_10.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).to({state:[{t:this.shape_8},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_6}]},1).to({state:[{t:this.shape_10}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.Símbolo3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhWEAnJQDzktCGidQDxkbEBkFQKhqqPXrkQXrxuaFuEQHrkIJaklQIhkLBSguQEQibGFioQDohkITjaQIEjYGwjQQJPkdJqlkQjrDArpL/Iq4LZQhyBPjBCjQmFFHmWGrQ0SVWvWc5QgZAug4BVQg5BWgZAtQg0Bfg9COQiSFegSEgQgKCaBOE7QAlCeA/DTQB2HbKZGXQE6DBEtBug");
	this.shape.setTransform(550.85,452.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Símbolo3, new cjs.Rectangle(0,0,1101.7,906), null);


(lib.Símbolo2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Fondo5();
	this.instance.setTransform(0,0,0.6016,0.6085);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Símbolo2, new cjs.Rectangle(0,0,486.1,221.5), null);


(lib.Símbolo1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Fondo3();
	this.instance.setTransform(0,0,0.5903,0.5903);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Símbolo1, new cjs.Rectangle(0,0,328.2,172.4), null);


(lib.PeruU = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAVC0QgKgDgagPQgYgOgIgHQgEgDACgFIAGgOQAFgKgCgBIAAgBIAAABQABABggAAQgiAAgVgMQg6ghAUg7QAJgaAbguQAdgzAYgYQAIgIAHAEIAeASIAeASQAHAEgDAGIgEAEQgUAcgSAeQgWAmgGAPQgKAaAZAPQAKAFAQgCQAQgCAGgIIA/huQAEgHACgBQADgBAGAEIAhATIAgASQAHAEgBAEIgDAGIgeAvIgdAwIgbAwIgaAwQgCAEgFAAIgDAAgABVh2QgwgGgagOIgCgBQgFgCADgFIAEgFIADgGIAFgIIADgJQACgDAGABQANACApAAIA5gFIAGAAIACAFIAIAYIAMAVQACAFgBACQgBABgFACQgRAEgXAAQgRAAgWgDg");
	this.shape.setTransform(6.2619,8.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAVC0QgKgDgagPQgYgOgIgHQgEgDACgFIAGgOQAFgKgCgBIAAgBIAAABQABABggAAQgiAAgVgMQg6ghAUg7QAJgaAbguQAdgzAYgYQAIgIAHAEIAeASIAeASQAHAEgDAGIgEAEQgUAcgSAeQgWAmgGAPQgKAaAZAPQAKAFAQgCQAQgCAGgIIA/huQAEgHACgBQADgBAGAEIAhATIAgASQAHAEgBAEIgDAGIgeAvIgdAwIgbAwIgaAwQgCAEgFAAIgDAAgABVh2QgwgGgagOIgCgBQgFgCADgFIAEgFIADgGIAFgIIADgJQACgDAGABQANACApAAIA5gFIAGAAIACAFIAIAYIAMAVQACAFgBACQgBABgFACQgRAEgXAAQgRAAgWgDg");
	this.shape_1.setTransform(4.3619,7.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.4,-32.7,63,72.9);


(lib.PeruR = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("Ag8B9IghgRQgVgMgLgJQgHgFADgHIAfg0IAfg0QAeg0AJgmIACgEQACgDAEABIAlAQIAoANQAEADgHAOQgHANACACIABABIgBgBQAAgBAZABQAcABAUALQAMAHgDAFIgMASIgLARIgKAQIgKARQgFAJgJgGIgMgHIgLgIQgTgKgKABQgKADgKARIgPAdIgQAdIgKAUIgKATQgCADgEAAIgFgCg");
	this.shape.setTransform(-5.3533,-0.9019);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag8B9IghgRQgVgMgLgJQgHgFADgHIAfg0IAfg0QAeg0AJgmIACgEQACgDAEABIAlAQIAoANQAEADgHAOQgHANACACIABABIgBgBQAAgBAZABQAcABAUALQAMAHgDAFIgMASIgLARIgKAQIgKARQgFAJgJgGIgMgHIgLgIQgTgKgKABQgKADgKARIgPAdIgQAdIgKAUIgKATQgCADgEAAIgFgCg");
	this.shape_1.setTransform(-7.0033,1.3981);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.6,-38,53.6,68.4);


(lib.PeruP = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AhuCyIgngXIgogYQgGgEADgGIArhJIAshIQAnhFAmhQIACgCQACgGAIAEQARAIA6AhQAjAUAfAUQAzAfAOAyQAOAxgeA1QgfA1gvARQgyARgzgeIgagQIgagQQgJgGgFAIIgPAfIgQAfQgCAEgCAAIgEgCgAAZg5QgDACgbAvIgLAVIgLATQgDAFAnAXQAwAcAbgxQAegygygcQgfgSgHAAIgBAAg");
	this.shape.setTransform(0.0833,-3.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhuCyIgngXIgogZQgGgDADgGIArhJIAshIQAnhFAmhQIACgCQACgGAIAEQARAHA6AiQAjAUAfAUQAzAfAOAyQAOAxgeA0QgfA2gvARQgyARgzgeIgagQIgagQQgJgGgFAIIgPAfIgQAfQgCAEgCAAIgEgCgAAZg5QgDACgbAwIgLAUIgLATQgDAFAnAXQAwAcAbgxQAegygygdQgfgRgHAAIgBAAg");
	this.shape_1.setTransform(-1.7167,-3.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.8,-36.3,66,73.4);


(lib.PeruE = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("Ag2BzQg1gegOgxQgPgxAeg0QAdgzAwgPQAxgQAyAdQAqAYALAwQAMAvgYAqQgNAXgQgFIgwgWIhRgmQgFAQALARQAKANAQAKQASALAaABIAXgBQAEAFgBAbQgBAagDAFQgBACgFABQgNAEgOAAQggAAgogXgAAAhEQgPAGgIAOQgEAGAHAEQAQAJAkAPQAIADABgDQAIgNgDgQQgEgQgNgIQgIgEgIAAQgHAAgGADg");
	this.shape.setTransform(1.9223,7.5387);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag2BzQg1gegOgxQgPgxAeg0QAdgzAwgPQAxgQAyAdQAqAYALAwQAMAvgYAqQgNAXgQgFIgwgWIhRgmQgFAQALARQAKANAQAKQASALAaABIAXgBQAEAFgBAbQgBAagDAFQgBACgFABQgNAEgOAAQggAAgogXgAAAhEQgPAGgIAOQgEAGAHAEQAQAJAkAPQAIADABgDQAIgNgDgQQgEgQgNgIQgIgEgIAAQgHAAgGADg");
	this.shape_1.setTransform(-0.0777,7.5387);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-33,59.4,69.2);


(lib.ParaguayY = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AinCEQgKgGgCgEIAFgZIACgUQACgOACgEQACgEAEACQA9AjAQgcQACgCgGg7QgHg7ADgNQADgIAWgnIAOgXIAOgYQAEgGAHAEIAhAVIAhAUQAFADgEAHIgLASIgMASQgPAcgFAKQgDAIAAAcQABAdAGADQAEADAYgOQAXgOAFgGQAOgSANgXIAJgSIAJgTQADgEAFACIAiATIAiASQAFADgBAHQgDAMgVAkQgZArgIAHQgKAJhUArQgNAHgzAWQg5AYgGAAIAAAAQgIAAg9gjg");
	this.shape.setTransform(3.0911,10.2203);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AinCEQgKgGgCgEIAFgZIACgUQACgOACgEQACgEAEACQA9AjAQgcQACgCgGg7QgHg7ADgNQADgIAWgnIAOgXIAOgYQAEgGAHAEIAhAVIAhAUQAFADgEAHIgLASIgMASQgPAcgFAKQgDAIAAAcQABAdAGADQAEADAYgOQAXgOAFgGQAOgSANgXIAJgSIAJgTQADgEAFACIAiATIAiASQAFADgBAHQgDAMgVAkQgZArgIAHQgKAJhUArQgNAHgzAWQg5AYgGAAIAAAAQgIAAg9gjg");
	this.shape_1.setTransform(1.5911,9.2203);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.4,-31.5,60.6,71.1);


(lib.ParaguayU = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAhCkQgKgDgagPQgYgOgIgHQgEgDACgFIAGgOQAFgKgCgCIAAAAIAAAAQABACggAAQgiAAgVgMQg6ghAUg6QAJgbAbguQAdgzAYgYQAIgIAHAEIAeASIAeASQAHAEgDAGIgEAEQgUAcgSAeQgWAngGAPQgKAZAZAPQAKAFAQgCQAPgCAGgIIBAhuQAEgHACgBQADgBAGAEIAhATIAgASQAHAEgBAEIgDAGIgeAvIgdAwIgbAwIgaAwQgCAEgEAAIgEAAg");
	this.shape.setTransform(6.6519,10.9304);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAhCkQgKgDgagPQgYgOgIgHQgEgDACgFIAGgOQAFgKgCgCIAAAAIAAAAQABACggAAQgiAAgVgMQg6ghAUg6QAJgbAbguQAdgzAYgYQAIgIAHAEIAeASIAeASQAHAEgDAGIgEAEQgUAcgSAeQgWAngGAPQgKAZAZAPQAKAFAQgCQAPgCAGgIIBAhuQAEgHACgBQADgBAGAEIAhATIAgASQAHAEgBAEIgDAGIgeAvIgdAwIgbAwIgaAwQgCAEgEAAIgEAAg");
	this.shape_1.setTransform(5.1519,9.9304);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.4,-31.5,62.6,72.3);


(lib.ParaguayR = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("Ag8B9IghgRQgVgMgLgJQgHgFADgHIAfg0IAfg0QAeg0AJgmIACgEQACgDAEABIAlAQIAoANQAEADgHAOQgHANACACIABABIgBgBQAAgBAZABQAcABAUALQAMAHgDAFIgMASIgLARIgKAQIgKARQgFAJgJgGIgMgHIgLgIQgTgKgKABQgKADgKARIgPAdIgQAdIgKAUIgKATQgCADgEAAIgFgCg");
	this.shape.setTransform(-5.3533,-0.9019);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag8B9IghgRQgVgMgLgJQgHgFADgHIAfg0IAfg0QAeg0AJgmIACgEQACgDAEABIAlAQIAoANQAEADgHAOQgHANACACIABABIgBgBQAAgBAZABQAcABAUALQAMAHgDAFIgMASIgLARIgKAQIgKARQgFAJgJgGIgMgHIgLgIQgTgKgKABQgKADgKARIgPAdIgQAdIgKAUIgKATQgCADgEAAIgFgCg");
	this.shape_1.setTransform(-7.0033,1.3981);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.6,-38,53.6,68.4);


(lib.ParaguayP = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AhuCyIgngXIgogYQgGgEADgGIArhJIAshIQAnhFAmhQIACgCQACgGAIAEQARAIA6AhQAjAUAfAUQAzAfAOAyQAOAxgeA1QgfA1gvARQgyARgzgeIgagQIgagQQgJgGgFAIIgPAfIgQAfQgCAEgCAAIgEgCgAAZg5QgDACgbAvIgLAVIgLATQgDAFAnAXQAwAcAbgxQAegygygcQgfgSgHAAIgBAAg");
	this.shape.setTransform(0.0833,-3.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhuCyIgngXIgogZQgGgDADgGIArhJIAshIQAnhFAmhQIACgCQACgGAIAEQARAHA6AiQAjAUAfAUQAzAfAOAyQAOAxgeA0QgfA2gvARQgyARgzgeIgagQIgagQQgJgGgFAIIgPAfIgQAfQgCAEgCAAIgEgCgAAZg5QgDACgbAwIgLAUIgLATQgDAFAnAXQAwAcAbgxQAegygygdQgfgRgHAAIgBAAg");
	this.shape_1.setTransform(-1.7167,-3.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.8,-36.3,66,73.4);


(lib.ParaguayG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AhfCLQgTgLgcgYQglgfAGgKQADgEAggiQAFgFADACIACADQAZAkAcAQQAQAJAUABQAZACAIgOIAHgPQghAIgjgUQgqgYgJgsQgKgsAYgqQAZgqApgNQApgOApAYQAiATAEAiQAAAHABABQACABAFgIQAKgSAEADIAkAaIAiAYQACADgCAFIgbAtIgbArIgQAcIgPAbQgkA+gqANQgLADgLAAQglAAgvgcgAAAhPQgRAFgJAQQgJAQAEASQAEASAPAIQAQAJARgFQASgGAJgPQAJgQgEgSQgDgSgRgJQgKgGgKAAQgGAAgHADg");
	this.shape.setTransform(4.2956,11.164);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhfCLQgTgLgcgYQglgfAGgKQADgEAggiQAFgFADACIACADQAZAkAcAQQAQAJAUABQAZACAIgOIAHgPQghAIgjgUQgqgYgJgsQgKgsAYgqQAZgqApgNQApgOApAYQAiATAEAiQAAAHABABQACABAFgIQAKgSAEADIAkAaIAiAYQACADgCAFIgbAtIgbArIgQAcIgPAbQgkA+gqANQgLADgLAAQglAAgvgcgAAAhPQgRAFgJAQQgJAQAEASQAEASAPAIQAQAJARgFQASgGAJgPQAJgQgEgSQgDgSgRgJQgKgGgKAAQgGAAgHADg");
	this.shape_1.setTransform(2.6956,11.564);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.6,-32,62.2,71.4);


(lib.ParaguayA3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape.setTransform(6.8188,11.8989);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape_1.setTransform(5.3188,10.8989);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.4,-31.5,62.8,72.4);


(lib.ParaguayA2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape.setTransform(5.2188,11.2989);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape_1.setTransform(3.3188,9.7489);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.4,-32.7,63.199999999999996,73);


(lib.ParaguayA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape.setTransform(4.7688,9.4489);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape_1.setTransform(2.7688,9.4489);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-33,63.3,71.4);


(lib.Intro2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Intro21366768();
	this.instance.setTransform(0,0,0.2397,0.2399);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Intro2, new cjs.Rectangle(0,0,1366,768), null);


(lib.Interpolación2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Chico();
	this.instance.setTransform(-226,-714);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-226,-714,452,1428);


(lib.Interpolación1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Chica();
	this.instance.setTransform(-283,-633);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-283,-633,566,1266);


(lib.fondo3cp = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Fondo4();
	this.instance.setTransform(0,0,0.6606,0.6606);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fondo3cp, new cjs.Rectangle(0,0,535.1,268.2), null);


(lib.Fondo2CP = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Fondo2();
	this.instance.setTransform(0,0,0.5648,0.5648);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Fondo2CP, new cjs.Rectangle(0,0,918.4,306.7), null);


(lib.Fondo1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Fondo1();
	this.instance.setTransform(0,0,0.722,0.7315);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Fondo1_1, new cjs.Rectangle(0,0,478,218), null);


(lib.CubaU = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAhCkQgKgDgagPQgYgOgIgHQgEgDACgFIAGgOQAFgKgCgCIAAAAIAAAAQABACggAAQgiAAgVgMQg6ghAUg6QAJgbAbguQAdgzAYgYQAIgIAHAEIAeASIAeASQAHAEgDAGIgEAEQgUAcgSAeQgWAngGAPQgKAZAZAPQAKAFAQgCQAPgCAGgIIBAhuQAEgHACgBQADgBAGAEIAhATIAgASQAHAEgBAEIgDAGIgeAvIgdAwIgbAwIgaAwQgCAEgEAAIgEAAg");
	this.shape.setTransform(4.6019,8.4804);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAhCkQgKgDgagPQgYgOgIgHQgEgDACgFIAGgOQAFgKgCgCIAAAAIAAAAQABACggAAQgiAAgVgMQg6ghAUg6QAJgbAbguQAdgzAYgYQAIgIAHAEIAeASIAeASQAHAEgDAGIgEAEQgUAcgSAeQgWAngGAPQgKAZAZAPQAKAFAQgCQAPgCAGgIIBAhuQAEgHACgBQADgBAGAEIAhATIAgASQAHAEgBAEIgDAGIgeAvIgdAwIgbAwIgaAwQgCAEgEAAIgEAAg");
	this.shape_1.setTransform(2.6019,8.4804);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-33,63.1,71.3);


(lib.CubaC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AhZCiQhFgngQhHQgPhFAohFQAmhDBEgXQBGgYBBAmQBIApAPBDQABAIgCADQgCAFgfARQgfASgFABQgDABgDgBIgGgQQgGgRgIgNQgMgSgTgLQgggTggANQgfAMgTAhQgUAiAFAgQAFAjAhATQATALAVACQAOABARgDIAQgDQACACABADQACAGABAhQACAigBACQgCAEgIADQgaAJgaAAQgpAAgpgYg");
	this.shape.setTransform(3.1907,2.1174);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhZCiQhFgngQhHQgPhFAohFQAmhDBEgXQBGgYBBAmQBIApAPBDQABAIgCADQgCAFgfARQgfASgFABQgDABgDgBIgGgQQgGgRgIgNQgMgSgTgLQgggTggANQgfAMgTAhQgUAiAFAgQAFAjAhATQATALAVACQAOABARgDIAQgDQACACABADQACAGABAhQACAigBACQgCAEgIADQgaAJgaAAQgpAAgpgYg");
	this.shape_1.setTransform(1.3907,1.7674);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.8,-36.3,64.7,72.69999999999999);


(lib.CubaB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AgYC9QghgUgJgeIgCgDQgCgBgGAHQgHAHgDgBQgFgBg7giQgNgIADgFIACgDQAYggA5hiQA2heAhhJIABgCQACgEAHAEIApATQAYALAPAJQAEACgEAHIgOAWIgPAWQgOAVgVAmQgEAHADACQABAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAfgKAhATQAwAcAIAvQAHAtgcAxQgbAugsAQQgTAHgSAAQgcAAgbgQgAAJARQgRAGgLATQgLATADASQAEATATALQASALASgHQASgGALgTQAKgSgEgTQgEgUgSgKQgLgGgLAAQgHAAgHACg");
	this.shape.setTransform(-2.8991,-3.4456);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYC9QghgUgJgeIgCgDQgCgBgGAHQgHAHgDgBQgFgBg7giQgNgIADgFIACgDQAYggA5hiQA2heAhhJIABgCQACgEAHAEIApATQAYALAPAJQAEACgEAHIgOAWIgPAWQgOAVgVAmQgEAHADACQABAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAfgKAhATQAwAcAIAvQAHAtgcAxQgbAugsAQQgTAHgSAAQgcAAgbgQgAAJARQgRAGgLATQgLATADASQAEATATALQASALASgHQASgGALgTQAKgSgEgTQgEgUgSgKQgLgGgLAAQgHAAgHACg");
	this.shape_1.setTransform(-4.5491,-1.1456);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.6,-38,63,73.8);


(lib.CubaA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape.setTransform(5.2188,11.2989);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape_1.setTransform(3.3188,9.7489);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.4,-32.7,63.199999999999996,73);


(lib.ColombiaO2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AhABwQgwgcgOgxQgNgvAcgxQAdgzAwgOQAwgPAzAeQAxAdANAwQANAwgdAyQgdAygwAOQgQAEgPAAQghAAgigUgAgJguQgSAHgKASQgLARAEASQADAUARAKQARAKATgHQARgHAKgRQAKgSgDgSQgDgUgRgKQgKgGgLAAQgGAAgIADg");
	this.shape.setTransform(2.671,9.0366);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABwQgwgcgOgxQgNgvAcgxQAdgzAwgOQAwgPAzAeQAxAdANAwQANAwgdAyQgdAygwAOQgQAEgPAAQghAAgigUgAgJguQgSAHgKASQgLARAEASQADAUARAKQARAKATgHQARgHAKgRQAKgSgDgSQgDgUgRgKQgKgGgLAAQgGAAgIADg");
	this.shape_1.setTransform(0.771,7.4866);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.4,-32.7,60.5,71.5);


(lib.ColombiaO = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AhABwQgwgcgOgxQgNgvAcgxQAdgzAwgOQAwgPAzAeQAxAdANAwQANAwgdAyQgdAygwAOQgQAEgPAAQghAAgigUgAgJguQgSAHgKASQgLARAEASQADAUARAKQARAKATgHQARgHAKgRQAKgSgDgSQgDgUgRgKQgKgGgLAAQgGAAgIADg");
	this.shape.setTransform(2.221,7.1866);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABwQgwgcgOgxQgNgvAcgxQAdgzAwgOQAwgPAzAeQAxAdANAwQANAwgdAyQgdAygwAOQgQAEgPAAQghAAgigUgAgJguQgSAHgKASQgLARAEASQADAUARAKQARAKATgHQARgHAKgRQAKgSgDgSQgDgUgRgKQgKgGgLAAQgGAAgIADg");
	this.shape_1.setTransform(0.221,7.1866);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-33,60.7,69.9);


(lib.ColombiaM = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("ABzDJIghgSQgbgPgGgFQgFgGAFgJIASgeIASgeQAWgmAJgRQAOgbgYgMQgKgGgPACQgQADgHAJQgGAJgaAtIgRAgIgRAfQgEAHgHgDIhCgnQgGgDAFgJIASgfIATgeIAOgZIAOgYQASgggYgOQgKgFgPABQgRABgGAJIgiA8IgiA6QgDAGgCAAQgCABgGgDIgggRQgOgIgQgMQgFgDgBgCQAAgBADgFIAfg0IAeg1QAVgkAVgwIACgEQACgEAEAAQAFABAPAGIAUAKIAVAFQAMAEAHADQAEADgJAPQgIAPABABIAHAAQAdgEAOABQAVACAUALQAUAMALASQAMAVgGAVQAVgKAbACQAbABATALQAdAQALAYQALAagQAdIgVAjIgUAiIgYArIgYApQgDAGgFAAIgDgBg");
	this.shape.setTransform(10.9119,12.9785);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABzDJIghgSQgbgPgGgFQgFgGAFgJIASgeIASgeQAWgmAJgRQAOgbgYgMQgKgGgPACQgQADgHAJQgGAJgaAtIgRAgIgRAfQgEAHgHgDIhCgnQgGgDAFgJIASgfIATgeIAOgZIAOgYQASgggYgOQgKgFgPABQgRABgGAJIgiA8IgiA6QgDAGgCAAQgCABgGgDIgggRQgOgIgQgMQgFgDgBgCQAAgBADgFIAfg0IAeg1QAVgkAVgwIACgEQACgEAEAAQAFABAPAGIAUAKIAVAFQAMAEAHADQAEADgJAPQgIAPABABIAHAAQAdgEAOABQAVACAUALQAUAMALASQAMAVgGAVQAVgKAbACQAbABATALQAdAQALAYQALAagQAdIgVAjIgUAiIgYArIgYApQgDAGgFAAIgDgBg");
	this.shape_1.setTransform(9.3119,13.3785);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.6,-32,75.80000000000001,79.2);


(lib.ColombiaL = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("Ag4CwQgLgEgagOQgagQgHgGQgEgEACgFIAGgKIAig6IAig6QA1hbgEAIQAagxAQgmIACgEQADgFAFADIBPAuQAFADgDAEIgCAEQg9BcgqBIIg0BdIgJARIgKASQgBADgEAAIgDgBg");
	this.shape.setTransform(-5.6903,-6.0255);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag4CwQgLgEgagOQgagQgHgGQgEgEACgFIAGgKIAig6IAig6QA1hbgEAIQAagxAQgmIACgEQADgFAFADIBPAuQAFADgDAEIgCAEQg9BcgqBIIg0BdIgJARIgKASQgBADgEAAIgDgBg");
	this.shape_1.setTransform(-7.3403,-3.7255);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.6,-38,48.5,65.4);


(lib.ColombiaI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AgvClQgJgDgagPQgagQgHgFQgEgEAAgDIADgHIAbgtIAcgtQAkg+AQgoIACgEQADgFAFAEIASAMIASAMQAGAEAOAGIATAKQAGADgDAFIgDADQgdAoghA4IgaAwIgbAwQgBADgEAAIgDAAgAAxhQQgTgKgGgRQgHgSAKgSQAKgRAUgDQASgDASAKQARAKAHASQAHASgKARQgNAXgVAAQgOAAgRgKg");
	this.shape.setTransform(0.5607,2.6462);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvClQgJgDgagPQgagQgHgFQgEgEAAgDIADgHIAbgtIAcgtQAkg+AQgoIACgEQADgFAFAEIASAMIASAMQAGAEAOAGIATAKQAGADgDAFIgDADQgdAoghA4IgaAwIgbAwQgBADgEAAIgDAAgAAxhQQgTgKgGgRQgHgSAKgSQAKgRAUgDQASgDASAKQARAKAHASQAHASgKARQgNAXgVAAQgOAAgRgKg");
	this.shape_1.setTransform(-0.9393,1.6462);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.4,-31.5,48.7,64.3);


(lib.ColombiaC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AhZCiQhFgngQhHQgPhFAohFQAmhDBEgXQBGgYBBAmQBIApAPBDQABAIgCADQgCAFgfARQgfASgFABQgDABgDgBIgGgQQgGgRgIgNQgMgSgTgLQgggTggANQgfAMgTAhQgUAiAFAgQAFAjAhATQATALAVACQAOABARgDIAQgDQACACABADQACAGABAhQACAigBACQgCAEgIADQgaAJgaAAQgpAAgpgYg");
	this.shape.setTransform(3.1907,2.1174);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhZCiQhFgngQhHQgPhFAohFQAmhDBEgXQBGgYBBAmQBIApAPBDQABAIgCADQgCAFgfARQgfASgFABQgDABgDgBIgGgQQgGgRgIgNQgMgSgTgLQgggTggANQgfAMgTAhQgUAiAFAgQAFAjAhATQATALAVACQAOABARgDIAQgDQACACABADQACAGABAhQACAigBACQgCAEgIADQgaAJgaAAQgpAAgpgYg");
	this.shape_1.setTransform(1.3907,1.7674);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.8,-36.3,64.7,72.69999999999999);


(lib.ColombiaB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AgYC9QghgUgJgeIgCgDQgCgBgGAHQgHAHgDgBQgFgBg7giQgNgIADgFIACgDQAYggA5hiQA2heAhhJIABgCQACgEAHAEIApATQAYALAPAJQAEACgEAHIgOAWIgPAWQgOAVgVAmQgEAHADACQABAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAfgKAhATQAwAcAIAvQAHAtgcAxQgbAugsAQQgTAHgSAAQgcAAgbgQgAAJARQgRAGgLATQgLATADASQAEATATALQASALASgHQASgGALgTQAKgSgEgTQgEgUgSgKQgLgGgLAAQgHAAgHACg");
	this.shape.setTransform(4.1509,4.0044);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYC9QghgUgJgeIgCgDQgCgBgGAHQgHAHgDgBQgFgBg7giQgNgIADgFIACgDQAYggA5hiQA2heAhhJIABgCQACgEAHAEIApATQAYALAPAJQAEACgEAHIgOAWIgPAWQgOAVgVAmQgEAHADACQABAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAfgKAhATQAwAcAIAvQAHAtgcAxQgbAugsAQQgTAHgSAAQgcAAgbgQgAAJARQgRAGgLATQgLATADASQAEATATALQASALASgHQASgGALgTQAKgSgEgTQgEgUgSgKQgLgGgLAAQgHAAgHACg");
	this.shape_1.setTransform(2.6509,3.0044);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.4,-31.5,62.8,72.4);


(lib.ColombiaA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape.setTransform(6.8188,11.8989);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape_1.setTransform(5.3188,10.8989);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.4,-31.5,62.8,72.4);


(lib.BrasilS = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("Ag1BxQgdgDgUgMQgEgCgCghQgCggADgGQABAAAAgBQAAAAABAAQAAAAABAAQABgBAAABIAiAMQAXAGAJgOQAFgKgEgSIgHgkQgCgWAKgSQATghAugEQAqgDAiAUQADACAAAfQABAggDAEQgBACgFACQgGgFgGgEQgNgHgMAAQgOABgHAMQgFAIAFASQAGAbABAIQABAXgLAUQgGALgMAKQgNALgKACQgPACgQAAIgVgBg");
	this.shape.setTransform(-1.1958,6.49);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag1BxQgdgDgUgMQgEgCgCghQgCggADgGQABAAAAgBQAAAAABAAQAAAAABAAQABgBAAABIAiAMQAXAGAJgOQAFgKgEgSIgHgkQgCgWAKgSQATghAugEQAqgDAiAUQADACAAAfQABAggDAEQgBACgFACQgGgFgGgEQgNgHgMAAQgOABgHAMQgFAIAFASQAGAbABAIQABAXgLAUQgGALgMAKQgNALgKACQgPACgQAAIgVgBg");
	this.shape_1.setTransform(-3.0958,4.94);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.4,-32.7,52.8,67);


(lib.BrasilR = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("Ag8B9IghgRQgVgMgLgJQgHgFADgHIAfg0IAfg0QAeg0AJgmIACgEQACgDAEABIAlAQIAoANQAEADgHAOQgHANACACIABABIgBgBQAAgBAZABQAcABAUALQAMAHgDAFIgMASIgLARIgKAQIgKARQgFAJgJgGIgMgHIgLgIQgTgKgKABQgKADgKARIgPAdIgQAdIgKAUIgKATQgCADgEAAIgFgCg");
	this.shape.setTransform(-0.3533,4.0981);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag8B9IghgRQgVgMgLgJQgHgFADgHIAfg0IAfg0QAeg0AJgmIACgEQACgDAEABIAlAQIAoANQAEADgHAOQgHANACACIABABIgBgBQAAgBAZABQAcABAUALQAMAHgDAFIgMASIgLARIgKAQIgKARQgFAJgJgGIgMgHIgLgIQgTgKgKABQgKADgKARIgPAdIgQAdIgKAUIgKATQgCADgEAAIgFgCg");
	this.shape_1.setTransform(-2.3533,4.0981);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26,-33,54,66.1);


(lib.BrasilL = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("Ag4CwQgLgEgagOQgagQgHgGQgEgEACgFIAGgKIAig6IAig6QA1hbgEAIQAagxAQgmIACgEQADgFAFADIBPAuQAFADgDAEIgCAEQg9BcgqBIIg0BdIgJARIgKASQgBADgEAAIgDgBg");
	this.shape.setTransform(1.3597,1.4245);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag4CwQgLgEgagOQgagQgHgGQgEgEACgFIAGgKIAig6IAig6QA1hbgEAIQAagxAQgmIACgEQADgFAFADIBPAuQAFADgDAEIgCAEQg9BcgqBIIg0BdIgJARIgKASQgBADgEAAIgDgBg");
	this.shape_1.setTransform(-0.1403,0.4245);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.4,-31.5,48.4,64.1);


(lib.BrasilI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AgvClQgJgDgagPQgagQgHgFQgEgEAAgDIADgHIAbgtIAcgtQAkg+AQgoIACgEQADgFAFAEIASAMIASAMQAGAEAOAGIATAKQAGADgDAFIgDADQgdAoghA4IgaAwIgbAwQgBADgEAAIgDAAgAAxhQQgTgKgGgRQgHgSAKgSQAKgRAUgDQASgDASAKQARAKAHASQAHASgKARQgNAXgVAAQgOAAgRgKg");
	this.shape.setTransform(0.5107,1.1462);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvClQgJgDgagPQgagQgHgFQgEgEAAgDIADgHIAbgtIAcgtQAkg+AQgoIACgEQADgFAFAEIASAMIASAMQAGAEAOAGIATAKQAGADgDAFIgDADQgdAoghA4IgaAwIgbAwQgBADgEAAIgDAAgAAxhQQgTgKgGgRQgHgSAKgSQAKgRAUgDQASgDASAKQARAKAHASQAHASgKARQgNAXgVAAQgOAAgRgKg");
	this.shape_1.setTransform(-1.0893,1.5462);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.6,-32,48.900000000000006,63.7);


(lib.BrasilB = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AhDCxIgPgJIgQgJQhRgvgOgMQgFgFADgFQAOgYAeguQAegtAOgYQAPgZAlhIIAeg4IABgDQACgEAIADQAHADArAZIBSAwQA1AiAQAeQAXApgdAwQgHANgRAKQgMAHgPAFQgNAFABgBQgBACADAGQALASgDAYQgCAVgLAUQgXAogpAMQgMAEgNAAQgnAAg2gggAgkAZQgEABgOAZQgPAaABAEQACAFAcAQQAYAOAMABQATAEALgUQALgTgMgRQgIgKgXgOQgbgQgFAAIAAAAgAAdheIgIAMIgIAMQgNAWADAFQABAEAZAPQAvAaAQgbQALgSgPgSQgJgJgYgOQgTgLgGAAIgBABg");
	this.shape.setTransform(0.0901,-0.5016);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhDCxIgPgJIgQgJQhRgvgOgMQgFgFADgFQAOgYAeguQAegtAOgYQAPgZAlhIIAeg4IABgDQACgEAIADQAHADArAZIBSAwQA1AiAQAeQAXApgdAwQgHANgRAKQgMAHgPAFQgNAFABgBQgBACADAGQALASgDAYQgCAVgLAUQgXAogpAMQgMAEgNAAQgnAAg2gggAgkAZQgEABgOAZQgPAaABAEQACAFAcAQQAYAOAMABQATAEALgUQALgTgMgRQgIgKgXgOQgbgQgFAAIAAAAgAAdheIgIAMIgIAMQgNAWADAFQABAEAZAPQAvAaAQgbQALgSgPgSQgJgJgYgOQgTgLgGAAIgBABg");
	this.shape_1.setTransform(-1.7099,-0.8516);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.8,-36.3,65.5,73.1);


(lib.BrasilA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape.setTransform(-0.2312,4.4489);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAdCZQgcgOgigUQgEgDAFgNQAGgOgCgBIgGABQgoALgcgQQgrgZgIgyQgIguAZgsQAdgzAugPQAvgQAwAdQAjAUAGAkIABACQACABAJgJQAJgKADACQAIAFAUASIAbAZQADAEgBACIgEAEQgeAjgaAsQgKARgRAjIgbAzQgDAGgFAAIgFgBgAgdhCQgTAFgLATQgKARAFAUQAFATARAKQATALATgFQASgFALgTQALgSgFgTQgFgTgTgLQgLgHgNAAQgGAAgGACg");
	this.shape_1.setTransform(-1.8812,6.7489);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.6,-38,62.9,73.7);


(lib.BotonIniciar2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIABgrIAAgrQgBgqgHgcIgBgCQABgBAAgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAegGQACAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKAQAAQALAAgBAFIAAAOIgCAPIABAOIAAAOQgBAHgHAAIgKAAIgKgBQgPAAgFAFQgGAFAAANIAAAYIAAAXIABAQIABAPQAAAFgGAAIgZABIgcgBg");
	this.shape.setTransform(45.5,1.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhLBAQgVgaAAgkQAAgpAWgZQAXgbApAAQAcAAAQAUIABABQACAAACgJQACgIADAAQAGAAATADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhABAkIABApIACApQAAAHgHABQgWABgdAAQgDAAgCgKQAAgKgCgBIgEADQgVAVgVAAQgkAAgXgcgAgZgaQgLAKAAAQQAAANALALQAKAKAOAAQAOAAAKgKQALgKgBgOQABgQgLgKQgJgKgPAAQgPAAgJAKg");
	this.shape_1.setTransform(27,1.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbB8QgDgBgBgCIgBgFIABglIAAgmQAAgygEgfIAAgEQAAgDAFAAIAPABIAPABIAQgBIAPgBQAEAAAAAEIAAADQgEAjAAAuIABAnIABAnQgBAEgEABQgHABgVAAQgUAAgHgBgAgYhFQgKgJgBgOQABgOAKgKQALgIANAAQAPAAAKAJQALAJAAAOQAAAfgkAAQgOAAgKgIg");
	this.shape_2.setTransform(11.4,-2.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgtBDQgagbAAgoQAAgnAagbQAagbAnAAQAbAAAUAMQAFACAAADIgGAVIgGAXQgBAAAAABQAAABgBAAQAAABAAAAQgBAAAAAAIgLgDQgLgCgHAAQgQgBgJAKQgJAKAAAPQAAAQAKAKQAKAKARgBQAIAAAKgDIAJgFQADAAAFAXQAEAVAAAHQAAAHgWAEQgRAFgLAAQgngBgagag");
	this.shape_3.setTransform(-1.275,1.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbB8QgDgBgBgCIgBgFIABglIAAgmQAAgygEgfIAAgEQAAgDAFAAIAPABIAPABIAPgBIAQgBQAFAAgBAEIAAADQgEAjAAAuIABAnIABAnQgBAEgEABQgHABgVAAQgUAAgHgBgAgXhFQgMgJAAgOQAAgOAMgKQAKgIANAAQAOAAALAJQALAJAAAOQAAAfgkAAQgOAAgJgIg");
	this.shape_4.setTransform(-14.15,-2.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAhBZQgGgBAAgHIABgZIAAgaIAAgUIAAgTQAAgZgWAAQgGAAgJAGQgLAHAAAHIAABgQAAAGgFABIgaABQgVAAgGgBQgGgBAAgFIAAgrIAAgpQAAgtgHgaIAAgDQAAgDADgBIAegEIAggFQACAAABAMQABAMACAAIAAAAIAAAAQgBAAAVgMQAUgNAQAAQAXAAAQALQARAMAAAXIAAA4IAAAjIAAAkQAAAEgFABIgaABQgXAAgFgBg");
	this.shape_5.setTransform(-29.975,1.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AghB+QgFgBAAgEIABghQAEhJAAgVIgCg7IgBg5QAAgFAEAAIARABIAQAAIARAAIAQgBQAFAAAAAFIgCA5IgCA7IABA/IABBAQAAABAAABQAAAAAAABQAAAAgBABQAAAAAAAAIgFABQgMACgTAAQgaAAgHgCg");
	this.shape_6.setTransform(-45.775,-2.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).wait(1));

	// Rectangulos
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4kRMAjxAAAQA8AAAqANQBiAfAABoIAAD7QAABohiAfQgqANg8AAMgjxAAAQjIAAAAiUIAAj7QAAiUDIAAg");
	this.shape_7.setTransform(0.5,-2.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#CA9783","#655293","#B3AAC3","#B3AAC3","#B3AAC3"],[0,1,1,1,1],-134.5,0,134.5,0).s().p("Ax4ESQjIAAAAiUIAAj7QAAiUDIAAMAjxAAAQA8AAAqANQBiAfAABoIAAD7QAABohiAfQgqANg8AAg");
	this.shape_8.setTransform(0.5,-2.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#FD9783","#1C5293","#B3AAC3","#B3AAC3","#B3AAC3"],[0,1,1,1,1],-134.5,0,134.5,0).s().p("Ax4ESQjIAAAAiUIAAj7QAAiUDIAAMAjxAAAQA8AAAqANQBiAfAABoIAAD7QAABohiAfQgqANg8AAg");
	this.shape_9.setTransform(0.5,-2.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#CAE515","#65BBD6","#B3AAC3","#B3AAC3","#B3AAC3"],[0,1,1,1,1],-134.5,0,134.5,0).s().p("Ax4ESQjIAAAAiUIAAj7QAAiUDIAAMAjxAAAQA8AAAqANQBiAfAABoIAAD7QAABohiAfQgqANg8AAg");
	this.shape_10.setTransform(0.5,-2.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7}]}).to({state:[{t:this.shape_9},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_7}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-31.4,271,56.9);


(lib.BotonIniciar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIABgrIAAgrQgBgqgHgcIgBgCQABgBAAgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAegGQACAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKAQAAQALAAgBAFIAAAOIgCAPIABAOIAAAOQgBAHgHAAIgKAAIgKgBQgPAAgFAFQgGAFAAANIAAAYIAAAXIABAQIABAPQAAAFgGAAIgZABIgcgBg");
	this.shape.setTransform(45.5,1.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhLBAQgVgaAAgkQAAgpAWgZQAXgbApAAQAcAAAQAUIABABQACAAACgJQACgIADAAQAGAAATADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhABAkIABApIACApQAAAHgHABQgWABgdAAQgDAAgCgKQAAgKgCgBIgEADQgVAVgVAAQgkAAgXgcgAgZgaQgLAKAAAQQAAANALALQAKAKAOAAQAOAAAKgKQALgKgBgOQABgQgLgKQgJgKgPAAQgPAAgJAKg");
	this.shape_1.setTransform(27,1.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbB8QgDgBgBgCIgBgFIABglIAAgmQAAgygEgfIAAgEQAAgDAFAAIAPABIAPABIAQgBIAPgBQAEAAAAAEIAAADQgEAjAAAuIABAnIABAnQgBAEgEABQgHABgVAAQgUAAgHgBgAgYhFQgKgJgBgOQABgOAKgKQALgIANAAQAPAAAKAJQALAJAAAOQAAAfgkAAQgOAAgKgIg");
	this.shape_2.setTransform(11.4,-2.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgtBDQgagbAAgoQAAgnAagbQAagbAnAAQAbAAAUAMQAFACAAADIgGAVIgGAXQgBAAAAABQAAABgBAAQAAABAAAAQgBAAAAAAIgLgDQgLgCgHAAQgQgBgJAKQgJAKAAAPQAAAQAKAKQAKAKARgBQAIAAAKgDIAJgFQADAAAFAXQAEAVAAAHQAAAHgWAEQgRAFgLAAQgngBgagag");
	this.shape_3.setTransform(-1.275,1.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbB8QgDgBgBgCIgBgFIABglIAAgmQAAgygEgfIAAgEQAAgDAFAAIAPABIAPABIAPgBIAQgBQAFAAgBAEIAAADQgEAjAAAuIABAnIABAnQgBAEgEABQgHABgVAAQgUAAgHgBgAgXhFQgMgJAAgOQAAgOAMgKQAKgIANAAQAOAAALAJQALAJAAAOQAAAfgkAAQgOAAgJgIg");
	this.shape_4.setTransform(-14.15,-2.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAhBZQgGgBAAgHIABgZIAAgaIAAgUIAAgTQAAgZgWAAQgGAAgJAGQgLAHAAAHIAABgQAAAGgFABIgaABQgVAAgGgBQgGgBAAgFIAAgrIAAgpQAAgtgHgaIAAgDQAAgDADgBIAegEIAggFQACAAABAMQABAMACAAIAAAAIAAAAQgBAAAVgMQAUgNAQAAQAXAAAQALQARAMAAAXIAAA4IAAAjIAAAkQAAAEgFABIgaABQgXAAgFgBg");
	this.shape_5.setTransform(-29.975,1.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AghB+QgFgBAAgEIABghQAEhJAAgVIgCg7IgBg5QAAgFAEAAIARABIAQAAIARAAIAQgBQAFAAAAAFIgCA5IgCA7IABA/IABBAQAAABAAABQAAAAAAABQAAAAgBABQAAAAAAAAIgFABQgMACgTAAQgaAAgHgCg");
	this.shape_6.setTransform(-45.775,-2.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).wait(1));

	// Rectangulos
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4kRMAjxAAAQA8AAAqANQBiAfAABoIAAD7QAABohiAfQgqANg8AAMgjxAAAQjIAAAAiUIAAj7QAAiUDIAAg");
	this.shape_7.setTransform(0.5,-2.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#CA9783","#655293","#B3AAC3","#B3AAC3","#B3AAC3"],[0,1,1,1,1],-134.5,0,134.5,0).s().p("Ax4ESQjIAAAAiUIAAj7QAAiUDIAAMAjxAAAQA8AAAqANQBiAfAABoIAAD7QAABohiAfQgqANg8AAg");
	this.shape_8.setTransform(0.5,-2.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#FD9783","#1C5293","#B3AAC3","#B3AAC3","#B3AAC3"],[0,1,1,1,1],-134.5,0,134.5,0).s().p("Ax4ESQjIAAAAiUIAAj7QAAiUDIAAMAjxAAAQA8AAAqANQBiAfAABoIAAD7QAABohiAfQgqANg8AAg");
	this.shape_9.setTransform(0.5,-2.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#CAE515","#65BBD6","#B3AAC3","#B3AAC3","#B3AAC3"],[0,1,1,1,1],-134.5,0,134.5,0).s().p("Ax4ESQjIAAAAiUIAAj7QAAiUDIAAMAjxAAAQA8AAAqANQBiAfAABoIAAD7QAABohiAfQgqANg8AAg");
	this.shape_10.setTransform(0.5,-2.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7}]}).to({state:[{t:this.shape_9},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_7}]},1).to({state:[{t:this.shape_8},{t:this.shape_7}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-31.4,271,56.9);


(lib.BotonContinuar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjaCtIFbisIlbitIAAhfIG1DjIAABSIm1Dig");
	this.shape.setTransform(60.7,53.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#CA9783","#655293","#B3AAC3","#B3AAC3","#B3AAC3"],[0,1,1,1,1],-55.1,0,55.2,0).s().p("AmFGGQiiihAAjlQAAjkCiihQChiiDkAAQDlAAChCiQCiChAADkQAADliiChQihCijlAAQjkAAihiig");
	this.shape_1.setTransform(55.15,55.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#2F9783","#DD5293","#B3AAC3","#B3AAC3","#B3AAC3"],[0,1,1,1,1],-55.1,0,55.2,0).s().p("AmFGGQiiihAAjlQAAjkCiihQChiiDkAAQDlAAChCiQCiChAADkQAADliiChQihCijlAAQjkAAihiig");
	this.shape_2.setTransform(55.15,55.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#CA9783","#65FFD8","#B3AAC3","#B3AAC3","#B3AAC3"],[0,1,1,1,1],-55.1,0,55.2,0).s().p("AmFGGQiiihAAjlQAAjkCiihQChiiDkAAQDlAAChCiQCiChAADkQAADliiChQihCijlAAQjkAAihiig");
	this.shape_3.setTransform(55.15,55.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_3},{t:this.shape}]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-14.4,128.9,135.7);


(lib.boton7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgzBuQgggDgBgGIgBgQIABgUQADgRADAAIADABQAWAMAbAAQAnAAABgaQgBgPgOgHQgLgGgQAAIgTACIgUABQgHABAAgHIACg0IABg0QAAgEADgDQACgEAEgBIAygBIBGABQAEAAAAAEIgCAcQgDAXgDAAIgCAAIgzgEQgTAAgCACQgCAGAAAPIABAEIANgBIAOgBQAhgBAXATQAYASAAAhQAABQhiAAQgPAAgYgDg");
	this.shape.setTransform(82.25,-0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_1.setTransform(53.975,1.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbB8QgEgBAAgCIgBgFIABglIAAgmQAAgygEgfIAAgEQAAgDAFAAIAPABIAPABIAPgBIAQgBQAFAAgBAEIAAADQgEAjAAAuIAAAnIABAnQAAAEgEABQgGABgWAAQgVAAgGgBgAgXhFQgLgJAAgOQAAgOALgKQAKgIAOAAQAOAAAKAJQALAJAAAOQAAAfgjAAQgPAAgJgIg");
	this.shape_2.setTransform(39.15,-2.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIABgrIAAgrQAAgqgIgcIAAgCQAAgBAAgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAegGQACAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKARAAQAKAAAAAFIgBAOIgCAPIABAOIAAAOQAAAHgIAAIgKAAIgKgBQgPAAgGAFQgFAFAAANIABAYIAAAXIABAQIAAAPQAAAFgGAAIgaABIgbgBg");
	this.shape_3.setTransform(27.3,1.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhLBAQgVgagBgkQABgpAWgZQAYgbAoAAQAbAAARAUIABABQACAAACgJQACgIADAAQAHAAATADIAZAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhAAAkIACApIACApQAAAHgHABQgWABgdAAQgDAAgBgKQgBgKgCgBIgEADQgVAVgWAAQgiAAgYgcgAgagaQgJAKgBAQQAAANALALQAKAKAOAAQAOAAALgKQAKgKgBgOQABgQgKgKQgKgKgPAAQgPAAgKAKg");
	this.shape_4.setTransform(8.8,1.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAhBZQgGgBAAgHIABgZIAAgaIAAgUIAAgTQAAgZgWAAQgGAAgJAGQgLAHAAAHIAABgQAAAGgFABIgaABQgVAAgGgBQgGgBAAgFIAAgrIAAgpQAAgtgHgaIAAgDQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAABgBIAegEIAggFQACAAABAMQABAMACAAIAAAAIAAAAQgBAAAVgMQAUgNAQAAQAXAAAQALQARAMAAAXIAAA4IAAAjIAAAkQAAAEgFABIgaABQgXAAgFgBg");
	this.shape_5.setTransform(-12.475,1.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag7BFQgbgZAAgrQAAgoAYgbQAZgbAoAAQAjAAAYAZQAZAZAAAjQAAARgMADIgmAEIg+AGQACALANAGQAKAFANAAQAQAAAQgIIAOgJQAEACAJARQAJAQAAAFIgDAEQgWAXguAAQgqAAgbgZgAgVglQgHAIAAAMQAAAFAFAAQANAAAbgEQAGgBAAgCQAAgLgIgJQgIgIgKAAQgLAAgHAKg");
	this.shape_6.setTransform(-31.875,1.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgtBDQgagbAAgoQAAgnAagbQAagbAnAAQAbAAAUAMQAFACAAADIgGAVIgGAXQgBAAAAABQAAABgBAAQAAABgBAAQAAAAAAAAIgLgDQgLgCgHAAQgQgBgJAKQgJAKAAAPQAAAQAKAKQAKAKARgBQAIAAAKgDIAJgFQADAAAFAXQAEAVAAAHQAAAHgWAEQgRAFgLAAQgngBgagag");
	this.shape_7.setTransform(-48.875,1.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgrBOQgNgUAAgEQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAAAAAIAagEQAQgGAAgLQAAgIgKgKIgRgTQgJgNAAgPQAAgaAcgUQAXgRAcAAQADAAALAVQAMASAAAEIgDAFIgKgBQgLgBgHAFQgJAFAAALQAAAGAKAKQAOAOADAFQAJANAAAQQAAAJgEAKQgEAMgGAFQgNALgSAIQgTAJgQgBQgEABgMgUg");
	this.shape_8.setTransform(-63.425,1.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABJB/QgOgBg+AAIgqAAIgpAAQgGAAAAgGIACg8QADgpAAgTIgDhNIgBgsIgBgCQAAgEAFAAIAoABIAoABIAngBIAogBQAJAAACAHIACAZIACAaQAAABAAABQAAAAgBABQAAAAgBAAQAAABgBAAIgEAAQgwgFglAAQgKABgCAEQgBACAAAMQAAAMADAEQAEAEAIgBIAGAAIAJAAIAugBIAKgBIAKgBQAEAAAAAEIgDAcQgCANAAAPQAAADgFAAIgQgBQgKgBglAAIgSAAQgIgBgBAEIAAALQAAAOACAEQADAHATABIAaAAIAdgCIAcgBQAEAAAAAHQAAAHgDAVQgDAXgDAEQgCADgEAAIgFgBgABSgfIAAAAIAAAAg");
	this.shape_9.setTransform(-79.8773,-2.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_10.setTransform(0.5,-2.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_11.setTransform(0.5,-2.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_12.setTransform(0.5,-2.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_13.setTransform(0.5,-2.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_14.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10}]}).to({state:[{t:this.shape_12},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_10}]},1).to({state:[{t:this.shape_14}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.boton6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhLBAQgWgaABgkQgBgpAXgZQAYgbAoAAQAcAAAQAUIABABQACAAACgJQACgIADAAQAHAAASADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQABAAAAAAIgBAEQgFAhAAAkIABApIABApQAAAHgFABQgXABgdAAQgEAAgBgKQgBgKgBgBIgEADQgVAVgVAAQgjAAgYgcgAgZgaQgKAKAAAQQAAANAKALQAKAKAPAAQAOAAAJgKQAKgKAAgOQAAgQgKgKQgJgKgOAAQgQAAgJAKg");
	this.shape.setTransform(49.25,1.475);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AguBPIABgkIABgkQAAgHgKAAIgCAAIgCAAQgHAAAAgFIAAgJIABgIIgBgMIAAgLQAAgEALgBQAHAAAAgDQACgHgBgOIgBgXQAAgVAEAAQAFAAAJACIAPADIAaAEQAFAAAAACIgBAXIgBAVQAAAKAFgBIATAAIATgBQAEAAAAADIgBANIAAAMIAAAMIAAANQAAADgFAAIgMAAIgNgBIgNAAQgDAAAAAIIAAANIAAANQAAAPAEAGQAFAHAOAAIANgBIAMgCQADAAAAADIgBARIgBARQAAAFgBABIgGAEQgYANgcAAQgzAAAAgog");
	this.shape_1.setTransform(31.675,-1.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag7BFQgbgZAAgrQAAgoAYgbQAZgbAoAAQAjAAAYAZQAZAZAAAjQAAARgMADIgmAEIg+AGQACALANAGQAKAFANAAQAQAAAQgIIAOgJQAEACAJARQAJAQAAAFIgDAEQgWAXguAAQgqAAgbgZgAgVglQgHAIAAAMQAAAFAFAAQANAAAbgEQAGgBAAgCQAAgLgIgJQgIgIgKAAQgLAAgHAKg");
	this.shape_2.setTransform(15.575,1.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AguB2QAAgQAFgBQAOgFAEgEQAFgFAAgPIABgyQAAgvgHgmIAAgDQAAgFAFABIAbgBIAggEQAEAAAAAFQABAIAAA+IAAA/QAAAlgNATQgOAUgiAIQgKACgMAAQgIAAAAgfgAgNhfQgLgHAAgPQAAgPALgIQALgIANAAQAOAAALAIQALAIAAAPQAAAegkAAQgOAAgKgIg");
	this.shape_3.setTransform(0.025,0.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIABgrIAAgrQAAgqgIgcIAAgCQAAgBAAgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAegGQACAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKARAAQAKAAgBAFIAAAOIgCAPIABAOIAAAOQAAAHgIAAIgKAAIgKgBQgPAAgGAFQgFAFAAANIABAYIAAAXIAAAQIABAPQAAAFgGAAIgaABIgbgBg");
	this.shape_4.setTransform(-10.85,1.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhLBAQgVgaAAgkQAAgpAWgZQAXgbApAAQAbAAARAUIABABQACAAACgJQACgIADAAQAGAAATADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhABAkIABApIACApQAAAHgHABQgWABgdAAQgDAAgCgKQAAgKgCgBIgEADQgVAVgWAAQgiAAgYgcgAgagaQgJAKgBAQQAAANALALQAKAKAOAAQAOAAAKgKQALgKgBgOQABgQgLgKQgJgKgPAAQgPAAgKAKg");
	this.shape_5.setTransform(-29.35,1.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgfB/QgFgBAAgEIAChAIACg/IgCg/QgkADgVAAQgBAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAAAIACgPIAEgPIABgRQABgOADAAIADABQAdAEA4AAQAQAAAsgEIAYgCIAEABQAAAAAAAAQAAABABAAQAAABAAAAQAAABAAAAIgBAOIAAANIABAOIABANQAAADgEABIg2gEIgBBBIACA/IABBAQAAABAAAAQAAABAAABQAAAAgBAAQAAABAAAAIgFABQgLACgVAAQgWAAgKgCg");
	this.shape_6.setTransform(-49.725,-2.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_7.setTransform(0.5,-2.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_8.setTransform(0.5,-2.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_9.setTransform(0.5,-2.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_10.setTransform(0.5,-2.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_11.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7}]}).to({state:[{t:this.shape_9},{t:this.shape_7}]},1).to({state:[{t:this.shape_10},{t:this.shape_7}]},1).to({state:[{t:this.shape_11}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.boton5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhEBWQgagcAAgtQAAg3ArglQApgjA5AAQADAAACAFQAOAjAAAEQAAAIgIAAQgVAAgSAGQgXAGgIAPIgCAEIABABIACAAQAPgHATAAQAfAAAUASQAVATAAAfQAAAogbAXQgZAVgqAAQgrAAgagdgAgSAKQgJAIAAANQAAAPAHAJQAIAKAOAAQAOAAAJgKQAHgJAAgPQAAgNgIgIQgIgIgNAAQgNAAgIAIg");
	this.shape.setTransform(82.475,-0.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_1.setTransform(53.075,1.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbB8QgDgBgBgCIgBgFIABglIAAgmQAAgygEgfIAAgEQAAgDAEAAIAQABIAPABIAPgBIAQgBQAFAAgBAEIAAADQgEAjAAAuIAAAnIABAnQAAAEgEABQgGABgWAAQgVAAgGgBgAgXhFQgLgJAAgOQAAgOALgKQAKgIAOAAQAOAAAKAJQALAJAAAOQAAAfgjAAQgPAAgJgIg");
	this.shape_2.setTransform(38.25,-2.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIABgrIAAgrQAAgqgIgcIAAgCQAAgBAAgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAegGQACAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKARAAQAKAAAAAFIgBAOIgCAPIABAOIAAAOQAAAHgIAAIgKAAIgKgBQgPAAgGAFQgFAFAAANIABAYIAAAXIABAQIAAAPQAAAFgGAAIgaABIgbgBg");
	this.shape_3.setTransform(26.4,1.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhLBAQgVgagBgkQABgpAWgZQAYgbAoAAQAbAAARAUIABABQACAAACgJQACgIADAAQAHAAASADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhAAAkIACApIACApQAAAHgHABQgWABgdAAQgDAAgBgKQgBgKgCgBIgEADQgVAVgWAAQgiAAgYgcgAgagaQgJAKgBAQQAAANALALQAKAKAOAAQAOAAALgKQAKgKAAgOQAAgQgKgKQgKgKgPAAQgPAAgKAKg");
	this.shape_4.setTransform(7.9,1.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAhBZQgGgBAAgHIABgZIAAgaIAAgUIAAgTQAAgZgWAAQgGAAgJAGQgLAHAAAHIAABgQAAAGgFABIgaABQgVAAgGgBQgGgBAAgFIAAgrIAAgpQAAgtgHgaIAAgDQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAABgBIAegEIAggFQACAAABAMQABAMACAAIAAAAIAAAAQgBAAAVgMQAUgNAQAAQAXAAAQALQARAMAAAXIAAA4IAAAjIAAAkQAAAEgFABIgaABQgXAAgFgBg");
	this.shape_5.setTransform(-13.375,1.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag7BFQgbgZAAgrQAAgoAYgbQAZgbAoAAQAjAAAYAZQAZAZAAAjQAAARgMADIgmAEIg+AGQACALANAGQAKAFANAAQAQAAAQgIIAOgJQAEACAJARQAJAQAAAFIgDAEQgWAXguAAQgqAAgbgZgAgVglQgHAIAAAMQAAAFAFAAQANAAAbgEQAGgBAAgCQAAgLgIgJQgIgIgKAAQgLAAgHAKg");
	this.shape_6.setTransform(-32.775,1.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgtBDQgagbAAgoQAAgnAagbQAagbAnAAQAbAAAUAMQAFACAAADIgGAVIgGAXQgBAAAAABQAAABgBAAQAAABgBAAQAAAAAAAAIgLgDQgLgCgHAAQgQgBgJAKQgJAKAAAPQAAAQAKAKQAKAKARgBQAIAAAKgDIAJgFQADAAAFAXQAEAVAAAHQAAAHgWAEQgRAFgLAAQgngBgagag");
	this.shape_7.setTransform(-49.775,1.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgrBOQgNgUAAgEQAAAAAAgBQAAAAABAAQAAAAAAgBQABAAAAAAIAagEQAQgGAAgLQAAgIgKgKIgRgTQgJgNAAgPQAAgaAcgUQAXgRAcAAQADAAALAVQAMASAAAEIgDAFIgKgBQgLgBgHAFQgJAFAAALQAAAGAKAKQAOAOADAFQAJANAAAQQAAAJgEAKQgEAMgGAFQgNALgSAIQgTAJgQgBQgEABgMgUg");
	this.shape_8.setTransform(-64.325,1.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABJB/QgOgBg+AAIgqAAIgpAAQgGAAAAgGIACg8QADgpAAgTIgDhNIgBgsIgBgCQAAgEAFAAIAoABIAoABIAngBIAogBQAJAAACAHIACAZIACAaQAAABAAABQAAAAgBABQAAAAgBAAQAAABgBAAIgEAAQgwgFglAAQgKABgCAEQgBACAAAMQAAAMADAEQAEAEAIgBIAGAAIAJAAIAugBIAKgBIAKgBQAEAAAAAEIgDAcQgCANAAAPQAAADgFAAIgQgBQgKgBglAAIgSAAQgIgBgBAEIAAALQAAAOACAEQADAHATABIAaAAIAdgCIAcgBQAEAAAAAHQAAAHgDAVQgDAXgDAEQgCADgEAAIgFgBgABSgfIAAAAIAAAAg");
	this.shape_9.setTransform(-80.7773,-2.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_10.setTransform(0.5,-2.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_11.setTransform(0.5,-2.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_12.setTransform(0.5,-2.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_13.setTransform(0.5,-2.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_14.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10}]}).to({state:[{t:this.shape_12},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_10}]},1).to({state:[{t:this.shape_14}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.boton4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhMBQQgegiAAguQAAguAeghQAfgiAtAAQAuAAAfAiQAeAhAAAuQAAAugeAiQgfAiguAAQgtAAgfgigAgdggQgLANAAATQAAASALAOQAMAPARAAQARAAANgPQALgOAAgSQgBgSgKgOQgMgOgSAAQgRAAgMAOg");
	this.shape.setTransform(107.1,-0.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABDBvQgRgEgtAAIgoACIgqABQgEAAgBgEIgDgSIgEgWQAAgDAPgCQASgDAFgEQASgPATgYQAYgcAAgPQAAgNgKgJQgIgJgNAAQgOAAgPAGQgJAEgLAHIgJAFQgGAAAAgOIgBgQIgDgKIgCgKQAAgCADgCQAPgLAZgGQAWgFAVAAQAiAAAXAPQAbASAAAgQAAAshCA5IBKgCQAFAAAAAGIgBANIgBAMIAAAOIAAAOQAAAEgGAAIgRgDg");
	this.shape_1.setTransform(85.925,-0.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhLBAQgWgaABgkQgBgpAXgZQAYgbAoAAQAcAAAQAUIABABQACAAACgJQACgIADAAQAGAAATADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhABAkIABApIABApQABAHgHABQgWABgdAAQgEAAgBgKQgBgKgBgBIgEADQgVAVgVAAQgkAAgXgcgAgZgaQgKAKAAAQQgBANALALQAKAKAOAAQAPAAAJgKQAKgKAAgOQAAgQgKgKQgJgKgPAAQgPAAgJAKg");
	this.shape_2.setTransform(55.9,1.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ABWBZQgGgBAAgIIABgYIAAgZIAAgsQgBgWgUAAQgIAAgJAHQgIAIgBAIQgBAIAAAkIABAZIAAAaQAAAGgFAAIg2AAQgFAAAAgHIABgaIAAgZIAAgVIAAgTQAAgagUAAQgIAAgJAGQgKAHAAAHIAAAxIAAAxQAAAEgBABIgGACIgZAAIgagBIgFgBQgBgBAAgEIAAgsIAAgqQAAgegEglIAAgDQAAgDACgBQAEgCALgBIAQgBIAOgEQAJgDAGAAQADAAAAANQABAMABAAIAEgCQAQgNAKgEQAOgHAQAAQAQAAAMAHQAPAJAEAPQAKgNARgJQARgJAPAAQAYAAAPALQARAMAAAXIAAAdIgBAcIABAiIAAAjQAAAGgFABIgbAAQgWAAgFgBg");
	this.shape_3.setTransform(28.925,1.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhLBAQgWgaABgkQgBgpAXgZQAYgbAoAAQAcAAAQAUIABABQACAAACgJQACgIADAAQAGAAATADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhABAkIABApIABApQABAHgHABQgWABgdAAQgEAAgBgKQgBgKgBgBIgEADQgVAVgVAAQgkAAgXgcgAgZgaQgKAKAAAQQgBANALALQAKAKAOAAQAPAAAJgKQAKgKAAgOQAAgQgKgKQgJgKgPAAQgPAAgJAKg");
	this.shape_4.setTransform(1.9,1.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIAAgrIAAgrQAAgqgHgcIgBgCQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAdgGQADAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKAQAAQAKAAAAAFIgBAOIgBAPIAAAOIAAAOQAAAHgHAAIgKAAIgKgBQgPAAgFAFQgGAFAAANIAAAYIAAAXIABAQIABAPQAAAFgGAAIgZABIgcgBg");
	this.shape_5.setTransform(-15.4,1.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgrBuQghgGAAgJIAHgjQACgFADAAIABABQAcANAYAAQAMAAANgGQAPgIAAgMIAAgMQgSARgcAAQgiAAgVgYQgWgXAAgiQAAgiAVgXQAUgYAjAAQAaAAAPAUIADAEQACAAAAgHQAAgOAEAAIAeADIAeADQADABAAAEIAAAlIgCAlIAAAXIABAVQAAAzgWAXQgWAXgzAAQgPAAgbgFgAgUg2QgJAKAAANQAAANAJAKQAJAIALAAQAOAAAJgIQAIgKABgNQgBgNgIgKQgJgKgOAAQgMAAgIAKg");
	this.shape_6.setTransform(-33.7,3.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_7.setTransform(-53.625,1.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AguBPIABgkIABgkQAAgHgKAAIgCAAIgCAAQgHAAAAgFIAAgJIABgIIgBgMIAAgLQAAgEALgBQAHAAAAgDQACgHgBgOIgBgXQAAgVAEAAQAFAAAJACIAPADIAaAEQAFAAAAACIgBAXIgBAVQAAAKAFgBIATAAIATgBQAEAAAAADIgBANIAAAMIAAAMIAAANQAAADgFAAIgMAAIgNgBIgNAAQgDAAAAAIIAAANIAAANQAAAPAEAGQAFAHAOAAIANgBIAMgCQADAAAAADIgBARIgBARQAAAFgBABIgGAEQgYANgcAAQgzAAAAgog");
	this.shape_8.setTransform(-70.425,-1.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_9.setTransform(-87.175,1.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpCBQgiAAgJgCQgGgCAAgEIABg8IACg8QAAgXgDgkIgDg8IAAgCQAAgFAFAAIApABIAoAAQAOAAAdgCIArgCQAKAAAAAHIABAXIADAQIABAPQAAABAAAAQAAABgBAAQAAAAgBAAQgBAAgBAAQgNAAgbgCQgcgDgOAAQgQAAgDACQgGADgBAOQAAARAJADIAKAAIAmgBIAlgBQAFAAAAAgQAAAagCAFQgBADgDAAIgMgBQgTgCgnAAIgOAAQgIACgBAGQAAAaACAhIADAbQAAAFgMAAg");
	this.shape_10.setTransform(-106.85,-2.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_11.setTransform(0.5,-2.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_12.setTransform(0.5,-2.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_13.setTransform(0.5,-2.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_14.setTransform(0.5,-2.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_15.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11}]}).to({state:[{t:this.shape_13},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_11}]},1).to({state:[{t:this.shape_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.boton3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag0BuQgfgDgCgGIAAgQIABgUQADgRADAAIADABQAWAMAcAAQAmAAAAgaQAAgPgNgHQgLgGgQAAIgVACIgUABQgGABAAgHIACg0IACg0QgBgEADgDQADgEADgBIAygBIBFABQAGAAAAAEIgCAcQgDAXgEAAIgCAAIgzgEQgTAAgBACQgEAGAAAPIABAEIAPgBIANgBQAigBAWATQAYASAAAhQAABQhjAAQgOAAgZgDg");
	this.shape.setTransform(103.35,-0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUBsIAAgCIAChTIAAg1QAAgFgCAAQgEAAgGACIgMACQgFAAgBgGIAAgTIAAgSQAAgEAFgCQAagLAPgSQACgEADAAIACAAIAUAFIAWADQAAAAABAAQAAABAAAAQABABAAAAQAAABAAABIAAAEQgCAQAAA+IAAA9IAAA/QAAADgDADQgDADgDAAIgaAAIgZAAQgIAAABgGg");
	this.shape_1.setTransform(87.3,-1.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhLBAQgVgagBgkQABgpAWgZQAXgbApAAQAcAAAQAUIABABQACAAACgJQACgIADAAQAGAAAUADIAZAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhAAAkIACApIACApQgBAHgFABQgXABgdAAQgDAAgBgKQgBgKgDgBIgDADQgVAVgWAAQgiAAgYgcgAgagaQgKAKAAAQQAAANALALQAKAKAOAAQAOAAALgKQAKgKAAgOQAAgQgKgKQgKgKgPAAQgPAAgKAKg");
	this.shape_2.setTransform(61.8,1.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ABWBZQgGgBAAgIIABgYIAAgZIAAgsQgBgWgUAAQgIAAgJAHQgIAIgBAIQgBAIAAAkIABAZIAAAaQAAAGgFAAIg2AAQgFAAAAgHIABgaIAAgZIAAgVIAAgTQAAgagUAAQgIAAgJAGQgKAHAAAHIAAAxIAAAxQAAAEgBABIgGACIgZAAIgagBIgFgBQgBgBAAgEIAAgsIAAgqQAAgegEglIAAgDQAAgDACgBQAEgCALgBIAQgBIAOgEQAJgDAGAAQADAAAAANQABAMABAAIAEgCQAQgNAKgEQAOgHAQAAQAQAAAMAHQAPAJAEAPQAKgNARgJQARgJAPAAQAYAAAPALQARAMAAAXIAAAdIgBAcIABAiIAAAjQAAAGgFABIgbAAQgWAAgFgBg");
	this.shape_3.setTransform(34.825,1.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhLBAQgVgagBgkQABgpAWgZQAXgbApAAQAcAAAQAUIABABQACAAACgJQACgIADAAQAGAAAUADIAZAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhAAAkIACApIACApQgBAHgGABQgWABgdAAQgDAAgBgKQgBgKgDgBIgDADQgVAVgWAAQgiAAgYgcgAgagaQgKAKAAAQQAAANALALQAKAKAPAAQANAAALgKQAKgKAAgOQAAgQgKgKQgKgKgOAAQgQAAgKAKg");
	this.shape_4.setTransform(7.8,1.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIABgrIAAgrQAAgqgIgcIAAgCQAAgBAAgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAegGQACAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKARAAQAKAAgBAFIAAAOIgCAPIABAOIAAAOQAAAHgIAAIgKAAIgKgBQgPAAgGAFQgFAFAAANIABAYIAAAXIAAAQIABAPQAAAFgGAAIgaABIgbgBg");
	this.shape_5.setTransform(-9.5,1.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgqBuQgigGAAgJIAIgjQABgFACAAIADABQAcANAXAAQAMAAANgGQAQgIAAgMIAAgMQgTARgcAAQgiAAgWgYQgVgXAAgiQAAgiAUgXQAWgYAhAAQAbAAAOAUIAFAEQABAAAAgHQAAgOADAAIAgADIAdADQADABAAAEIgBAlIgBAlIAAAXIABAVQAAAzgWAXQgXAXgzAAQgOAAgagFgAgVg2QgIAKAAANQAAANAJAKQAIAIANAAQANAAAIgIQAKgKgBgNQABgNgKgKQgIgKgNAAQgMAAgKAKg");
	this.shape_6.setTransform(-27.8,3.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_7.setTransform(-47.725,1.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AguBPIABgkIABgkQAAgHgKAAIgCAAIgCAAQgHAAAAgFIAAgJIABgIIgBgMIAAgLQAAgEALgBQAHAAAAgDQACgHgBgOIgBgXQAAgVAEAAQAFAAAJACIAPADIAaAEQAFAAAAACIgBAXIgBAVQAAAKAFgBIATAAIATgBQAEAAAAADIgBANIAAAMIAAAMIAAANQAAADgFAAIgMAAIgNgBIgNAAQgDAAAAAIIAAANIAAANQAAAPAEAGQAFAHAOAAIANgBIAMgCQADAAAAADIgBARIgBARQAAAFgBABIgGAEQgYANgcAAQgzAAAAgog");
	this.shape_8.setTransform(-64.525,-1.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_9.setTransform(-81.275,1.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpCBQgiAAgKgCQgFgCAAgEIACg8IABg8QAAgXgCgkIgEg8IAAgCQAAgFAFAAIApABIAoAAQAOAAAdgCIAsgCQAIAAACAHIAAAXIACAQIACAPQAAABAAAAQAAABgBAAQAAAAgBAAQgBAAAAAAQgOAAgcgCQgbgDgNAAQgRAAgDACQgGADAAAOQAAARAIADIAKAAIAlgBIAlgBQAHAAAAAgQAAAagCAFQgCADgEAAIgKgBQgUgCgnAAIgNAAQgKACABAGQAAAaABAhIACAbQAAAFgLAAg");
	this.shape_10.setTransform(-100.95,-2.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_11.setTransform(0.5,-2.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_12.setTransform(0.5,-2.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_13.setTransform(0.5,-2.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_14.setTransform(0.5,-2.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_15.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11}]}).to({state:[{t:this.shape_13},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_11}]},1).to({state:[{t:this.shape_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.boton2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhNBQQgegiAAguQAAguAeghQAggiAtAAQAuAAAgAiQAeAhAAAuQAAAugeAiQggAiguAAQgtAAgggigAgdggQgLANAAATQAAASALAOQAMAPARAAQASAAALgPQALgOAAgSQABgSgLgOQgLgOgTAAQgRAAgMAOg");
	this.shape.setTransform(103.45,-0.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUBsIAAgCIADhTIAAg1QgBgFgCAAQgDAAgIACIgLACQgGAAABgGIAAgTIgBgSQAAgEAEgCQAbgLAQgSQABgEACAAIADAAIAUAFIAVADQABAAABAAQAAABAAAAQABABAAAAQAAABAAABIgBAEQgCAQAAA+IABA9IAAA/QAAADgDADQgDADgEAAIgaAAIgZAAQgGAAAAgGg");
	this.shape_1.setTransform(85,-1.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhLBAQgWgaABgkQgBgpAXgZQAYgbAoAAQAcAAAQAUIABABQACAAACgJQACgIADAAQAGAAATADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhABAkIABApIABApQABAHgHABQgWABgdAAQgEAAgBgKQgBgKgBgBIgEADQgVAVgVAAQgkAAgXgcgAgZgaQgKAKAAAQQgBANALALQAKAKAOAAQAPAAAJgKQAKgKAAgOQAAgQgKgKQgJgKgPAAQgPAAgJAKg");
	this.shape_2.setTransform(59.5,1.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("ABWBZQgGgBAAgIIABgYIAAgZIAAgsQgBgWgUAAQgIAAgJAHQgIAIgBAIQgBAIAAAkIABAZIAAAaQAAAGgFAAIg2AAQgFAAAAgHIABgaIAAgZIAAgVIAAgTQAAgagUAAQgIAAgJAGQgKAHAAAHIAAAxIAAAxQAAAEgBABIgGACIgZAAIgagBIgFgBQgBgBAAgEIAAgsIAAgqQAAgegEglIAAgDQAAgDACgBQAEgCALgBIAQgBIAOgEQAJgDAGAAQADAAAAANQABAMABAAIAEgCQAQgNAKgEQAOgHAQAAQAQAAAMAHQAPAJAEAPQAKgNARgJQARgJAPAAQAYAAAPALQARAMAAAXIAAAdIgBAcIABAiIAAAjQAAAGgFABIgbAAQgWAAgFgBg");
	this.shape_3.setTransform(32.525,1.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhLBAQgWgaABgkQgBgpAXgZQAYgbAoAAQAcAAAQAUIABABQACAAACgJQACgIADAAQAGAAATADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhABAkIABApIABApQABAHgHABQgWABgdAAQgEAAgBgKQgBgKgBgBIgEADQgVAVgVAAQgkAAgXgcgAgZgaQgKAKAAAQQgBANALALQAKAKAOAAQAPAAAJgKQAKgKAAgOQAAgQgKgKQgJgKgPAAQgPAAgJAKg");
	this.shape_4.setTransform(5.5,1.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIAAgrIAAgrQAAgqgHgcIgBgCQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAdgGQADAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKAQAAQAKAAAAAFIgBAOIgBAPIAAAOIAAAOQAAAHgHAAIgKAAIgKgBQgPAAgFAFQgGAFAAANIAAAYIAAAXIABAQIABAPQAAAFgGAAIgZABIgcgBg");
	this.shape_5.setTransform(-11.8,1.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgrBuQghgGAAgJIAHgjQACgFADAAIABABQAcANAYAAQAMAAANgGQAPgIAAgMIAAgMQgSARgcAAQgiAAgVgYQgWgXAAgiQAAgiAVgXQAUgYAjAAQAaAAAPAUIADAEQACAAAAgHQAAgOAEAAIAeADIAeADQADABAAAEIAAAlIgCAlIAAAXIABAVQAAAzgWAXQgWAXgzAAQgPAAgbgFgAgUg2QgJAKAAANQAAANAJAKQAJAIALAAQAOAAAJgIQAIgKABgNQgBgNgIgKQgJgKgOAAQgMAAgIAKg");
	this.shape_6.setTransform(-30.1,3.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_7.setTransform(-50.025,1.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AguBPIABgkIABgkQAAgHgKAAIgCAAIgCAAQgHAAAAgFIAAgJIABgIIgBgMIAAgLQAAgEALgBQAHAAAAgDQACgHgBgOIgBgXQAAgVAEAAQAFAAAJACIAPADIAaAEQAFAAAAACIgBAXIgBAVQAAAKAFgBIATAAIATgBQAEAAAAADIgBANIAAAMIAAAMIAAANQAAADgFAAIgMAAIgNgBIgNAAQgDAAAAAIIAAANIAAANQAAAPAEAGQAFAHAOAAIANgBIAMgCQADAAAAADIgBARIgBARQAAAFgBABIgGAEQgYANgcAAQgzAAAAgog");
	this.shape_8.setTransform(-66.825,-1.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_9.setTransform(-83.575,1.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpCBQgiAAgJgCQgGgCAAgEIABg8IACg8QAAgXgDgkIgDg8IAAgCQAAgFAFAAIApABIAoAAQAOAAAdgCIArgCQAKAAAAAHIABAXIADAQIABAPQAAABAAAAQAAABgBAAQAAAAgBAAQgBAAgBAAQgNAAgbgCQgcgDgOAAQgQAAgDACQgGADgBAOQAAARAJADIAKAAIAmgBIAlgBQAFAAAAAgQAAAagCAFQgBADgDAAIgMgBQgTgCgnAAIgOAAQgIACgBAGQAAAaACAhIADAbQAAAFgMAAg");
	this.shape_10.setTransform(-103.25,-2.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(4));

	// Rectangulos
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_11.setTransform(0.5,-2.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_12.setTransform(0.5,-2.95);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00FFCC").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_13.setTransform(0.5,-2.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_14.setTransform(0.5,-2.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_15.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11}]}).to({state:[{t:this.shape_13},{t:this.shape_11}]},1).to({state:[{t:this.shape_14},{t:this.shape_11}]},1).to({state:[{t:this.shape_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135,-40.9,271,76);


(lib.boton1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Titulos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgzBuQgggDgCgGIAAgQIABgUQADgRADAAIADABQAWAMAcAAQAnAAgBgaQABgPgOgHQgLgGgQAAIgVACIgUABQgGABAAgHIACg0IACg0QgBgEADgDQADgEADgBIAygBIBFABQAFAAABAEQAAALgDARQgDAXgDAAIgCAAIgzgEQgTAAgCACQgDAGAAAPIABAEIAPgBIANgBQAhgBAXATQAYASAAAhQAABQhjAAQgOAAgYgDg");
	this.shape.setTransform(97.4,-0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhLBAQgVgagBgkQABgpAWgZQAYgbAoAAQAbAAARAUIABABQACAAACgJQACgIADAAQAHAAASADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhAAAkIACApIACApQAAAHgHABQgWABgdAAQgDAAgBgKQgBgKgCgBIgEADQgVAVgWAAQgiAAgYgcgAgagaQgJAKgBAQQAAANALALQAKAKAOAAQAOAAALgKQAKgKgBgOQABgQgKgKQgKgKgPAAQgPAAgKAKg");
	this.shape_1.setTransform(67.75,1.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABWBZQgGgBAAgIIABgYIAAgZIAAgsQgBgWgUAAQgIAAgJAHQgIAIgBAIQgBAIAAAkIABAZIAAAaQAAAGgFAAIg2AAQgFAAAAgHIABgaIAAgZIAAgVIAAgTQAAgagUAAQgIAAgJAGQgKAHAAAHIAAAxIAAAxQAAAEgBABIgGACIgZAAIgagBIgFgBQgBgBAAgEIAAgsIAAgqQAAgegEglIAAgDQAAgDACgBQAEgCALgBIAQgBIAOgEQAJgDAGAAQADAAAAANQABAMABAAIAEgCQAQgNAKgEQAOgHAQAAQAQAAAMAHQAPAJAEAPQAKgNARgJQARgJAPAAQAYAAAPALQARAMAAAXIAAAdIgBAcIABAiIAAAjQAAAGgFABIgbAAQgWAAgFgBg");
	this.shape_2.setTransform(40.775,1.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhLBAQgVgagBgkQABgpAWgZQAYgbAoAAQAbAAARAUIABABQACAAACgJQACgIADAAQAHAAASADIAaAHQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAAAIAAAEQgGAhAAAkIACApIACApQAAAHgHABQgWABgdAAQgDAAgBgKQgBgKgCgBIgEADQgVAVgWAAQgiAAgYgcgAgagaQgJAKgBAQQAAANALALQAKAKAOAAQAOAAALgKQAKgKAAgOQAAgQgKgKQgKgKgPAAQgPAAgKAKg");
	this.shape_3.setTransform(13.75,1.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgxBZQgGgBAAgFIABgrIAAgrQgBgqgHgcIgBgCQABgBAAgBQAAAAAAgBQAAAAABAAQAAgBABAAIAdgEIAegGQACAAABAMQAAALADAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCAAARgJQARgKAQAAQALAAgBAFIAAAOIgCAPIABAOIAAAOQgBAHgHAAIgKAAIgKgBQgPAAgFAFQgGAFAAANIAAAYIAAAXIABAQIABAPQAAAFgGAAIgZABIgcgBg");
	this.shape_4.setTransform(-3.55,1.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBuQgigGAAgJIAHgjQACgFACAAIADABQAbANAYAAQAMAAANgGQAPgIAAgMIAAgMQgSARgcAAQgiAAgVgYQgWgXAAgiQAAgiAUgXQAVgYAjAAQAaAAAOAUIAFAEQABAAAAgHQAAgOADAAIAgADIAdADQADABAAAEIgBAlIgBAlIAAAXIABAVQAAAzgWAXQgWAXg0AAQgPAAgZgFgAgVg2QgIAKAAANQAAANAJAKQAJAIAMAAQANAAAIgIQAKgKgBgNQABgNgKgKQgIgKgNAAQgMAAgKAKg");
	this.shape_5.setTransform(-21.85,3.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_6.setTransform(-41.775,1.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AguBPIABgkIABgkQAAgHgKAAIgCAAIgCAAQgHAAAAgFIAAgJIABgIIgBgMIAAgLQAAgEALgBQAHAAAAgDQACgHgBgOIgBgXQAAgVAEAAQAFAAAJACIAPADIAaAEQAFAAAAACIgBAXIgBAVQAAAKAFgBIATAAIATgBQAEAAAAADIgBANIAAAMIAAAMIAAANQAAADgFAAIgMAAIgNgBIgNAAQgDAAAAAIIAAANIAAANQAAAPAEAGQAFAHAOAAIANgBIAMgCQADAAAAADIgBARIgBARQAAAFgBABIgGAEQgYANgcAAQgzAAAAgog");
	this.shape_7.setTransform(-58.575,-1.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhABDQgagZAAgoQAAgpAZgaQAYgaApAAQApAAAZAaQAZAZAAAoQAAApgZAaQgZAZgpAAQgnAAgZgZgAgWgYQgJAKAAAOQAAAOAJALQAJALANAAQAOAAAKgLQAIgLAAgOQAAgNgJgLQgJgLgOAAQgNAAgJALg");
	this.shape_8.setTransform(-75.325,1.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgpCBQgiAAgKgCQgFgCAAgEIABg8IACg8QAAgXgCgkIgEg8IAAgCQAAgFAFAAIApABIAoAAQAOAAAdgCIAsgCQAIAAACAHIAAAXIACAQIACAPQAAABAAAAQAAABgBAAQAAAAgBAAQgBAAgBAAQgNAAgcgCQgbgDgNAAQgRAAgDACQgGADAAAOQAAARAIADIAKAAIAlgBIAlgBQAHAAgBAgQAAAagBAFQgBADgFAAIgLgBQgTgCgnAAIgNAAQgKACABAGQAAAaABAhIACAbQAAAFgLAAg");
	this.shape_9.setTransform(-95,-2.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhKCeQgtgFgCgIQgBgEAAgTQAAgLACgSQAEgYAEAAIAFACQAfAPAnAAQA4AAAAglQAAgUgUgLQgQgIgXAAIgcACQgTADgKAAQgJAAAAgJIAChKQADgzAAgZQAAgFADgFQAEgGAFgBQAFgBBDAAIBkABQAHAAAAAGQAAAOgDAaQgEAhgGAAIgCAAQg7gGgOAAQgcAAgCAEQgEAHAAAWIABAFIAUgBIAUgCQAwAAAgAaQAiAbAAAvQAAB0iNAAQgVAAgjgFg");
	this.shape_10.setTransform(138.975,-0.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhsBcQgfglAAg0QAAg7AgglQAigmA6AAQAoABAYAcIACABQACAAADgMQADgNAEAAQAJAAAbAFIAlAJQAEACAAADIAAAFQgJAvAAA0QAAATACAoIACA6QABAKgKACQgfACgqAAQgFAAgCgPQgBgPgCAAIgGAEQgdAegggBQgyABgigogAglgmQgOAPAAAVQAAAVAOAOQAPAPAVABQAVgBAOgOQAOgOAAgWQAAgVgOgPQgOgOgVAAQgWAAgOAOg");
	this.shape_11.setTransform(96.45,2.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AB7CAQgIgCAAgLIABgjIABgkIgBhAQgCgegcAAQgMAAgMAKQgMAKgBANQgBAKAAA0IABAlIAAAlQAAAJgHAAIhOAAQgHAAAAgLIABgkIABglIgBgdIAAgcQAAglgcAAQgMAAgNAIQgPAKAAALIABBFIAABGQAAAHgCABQgBACgHAAIgkABIglgBQgHgBgBgBQgBgBAAgHIAAg+IABg9QAAgqgHg1IAAgFQAAgEAEgCQAFgCAQgCIAXgCIAUgGQANgDAIAAQAFAAAAASQAAASACAAIAGgEQAXgSAOgHQAUgJAXAAQAYAAASAKQAUAMAHAWQANgTAYgNQAZgMAWAAQAiAAAWAQQAYARAAAiIAAApIgBAoIABAxIAAAxQAAAJgHABQgIABgfAAQgfAAgIgBg");
	this.shape_12.setTransform(57.825,2.575);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhsBcQgfglAAg0QAAg7AgglQAigmA6AAQAoABAYAcIACABQACAAADgMQADgNAEAAQAJAAAbAFIAlAJQAEACAAADIAAAFQgJAvAAA0QAAATACAoIACA6QABAKgKACQgfACgqAAQgFAAgCgPQgBgPgCAAIgGAEQgdAegggBQgyABgigogAglgmQgOAPAAAVQAAAVAPAOQAOAPAVABQAVgBAOgOQAOgOAAgWQAAgVgOgPQgOgOgVAAQgWAAgOAOg");
	this.shape_13.setTransform(19.05,2.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhGB/QgIgBAAgIIAAg+IAAg9QAAg8gLgoIgBgDQAAgFAEgBIAqgFIAqgIQADAAACAQQABAQADAAIAAAAIAAAAQgCAAAYgNQAYgOAXAAQAPAAAAAGIgBAVIgCAWIAAAUIAAAUQAAAKgLAAIgOgBIgOgBQgWAAgHAIQgIAGAAAUIAAAiIAAAhIACAXIABAVQAAAHgJAAIglABQgZABgOgCg");
	this.shape_14.setTransform(-5.75,2.65);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag9CdQgxgJAAgMQABgEAKguQADgHADAAIADABQAoATAiAAQARAAATgJQAWgLAAgRIAAgRQgaAYgoAAQgyAAgegiQgfgiAAgwQAAgyAdggQAegiAxAAQAmAAAVAcQAEAFACAAQACAAAAgJQAAgVAEAAIAtAFIAqAEQAFACAAAFIgBA1IgCA2IABAgIAAAeQABBKggAgQggAhhKAAQgVAAglgHgAgehOQgMAOAAATQAAATAMAOQANANASAAQASAAANgNQAMgOAAgTQAAgTgMgOQgNgOgSAAQgSAAgNAOg");
	this.shape_15.setTransform(-31.95,6.075);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhdBgQglglAAg4QAAg8AkglQAjglA7AAQA6AAAkAkQAlAlAAA6QAAA6gkAmQgkAkg7AAQg4AAglgkgAgggjQgNAPAAAUQAAAUANAQQANAQATAAQAUAAAOgQQAMgQAAgUQAAgUgNgPQgNgQgUAAQgTAAgNAQg");
	this.shape_16.setTransform(-60.525,2.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhDBxIABg0IACgzQAAgKgNAAIgEAAIgDAAQgKAAAAgHIABgMIAAgNIAAgRIgBgQQAAgGARAAQAJgBABgEQACgKgBgWIgBgfQAAgeAGAAQAGAAAOADIAUAEIAmAFQAHAAAAAEIgCAgIgBAfQAAAMAIAAIAbAAIAcgBQAFAAAAAEIgBASIgCASIABASIAAASQAAAFgIgBIgRAAIgRgBIgUAAQgDAAAAAMIAAATIAAASQAAAWAFAIQAHALAUAAQAGAAANgDQAMgDAEAAQAGAAAAAFIgBAYQgDAQAAAHQAAAIgCACQgBACgHAEQghASgpAAQhKAAAAg5g");
	this.shape_17.setTransform(-84.6,-1.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhdBgQglglAAg4QAAg8AkglQAjglA7AAQA6AAAkAkQAlAlAAA6QAAA6gkAmQgkAkg7AAQg4AAglgkgAgggjQgNAPAAAUQAAAUANAQQANAQATAAQAUAAAOgQQAMgQAAgUQAAgUgNgPQgNgQgUAAQgTAAgNAQg");
	this.shape_18.setTransform(-108.625,2.65);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag7C5QgxAAgOgDQgHgDAAgFIAChXIAChWQAAgigEgzIgFhWIAAgDQAAgHAIAAIA6ABIA6ABQAUAAApgDQAqgDAUAAQANAAACAKIABAiIADAWQADAOAAAIQAAACgFABQgUAAgngDQgogEgTAAQgYAAgEABQgKAFAAAUQAAAZANADQAFACAJAAIA2gCIA1gCQAJAAAAAtQAAAngDAGQgCAFgFAAIgQgCQgcgCg4AAIgUAAQgNACAAAJQAAAlADAwIADAnQgBAGgPABg");
	this.shape_19.setTransform(-136.8265,-2.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).wait(1));

	// Rectangulos
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ax4lxMAjxAAAQDIAAAADIIAAFTQAADIjIAAMgjxAAAQjIAAAAjIIAAlTQAAjIDIAAg");
	this.shape_20.setTransform(0.5,-2.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#0123FF","#D3A3E7"],[0,1],-134.5,0,134.5,0).s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_21.setTransform(0.5,-2.95);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(1,1,1).p("A2enQMAs9AAAQD8AAAAD7IAAGrQAAD7j8AAMgs9AAAQj8AAAAj7IAAmrQAAj7D8AAg");
	this.shape_22.setTransform(0.525,-2.95);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00FFCC").s().p("A2eHRQj8AAAAj8IAAmqQAAj7D8AAMAs9AAAQD8AAAAD7IAAGqQAAD8j8AAg");
	this.shape_23.setTransform(0.525,-2.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FF6600").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_24.setTransform(0.5,-2.95);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFF33").s().p("Ax4FyQjIAAAAjIIAAlTQAAjIDIAAMAjxAAAQDIAAAADIIAAFTQAADIjIAAg");
	this.shape_25.setTransform(0.5,-2.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20}]}).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_24},{t:this.shape_20}]},1).to({state:[{t:this.shape_25}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-169.5,-50.4,340.1,95);


(lib.Avion = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.avion();
	this.instance.setTransform(0,86.25,0.2939,0.2939,-14.9971);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Avion, new cjs.Rectangle(0,0,352.2,199), null);


(lib.mc_escenario6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {msg1:55,msg2:56,msg3:57,msg4:58,msg5:59};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_14 = function() {
		this.stop();
		
		this.botoniniciar2.on("click", iniciar2.bind(this));
		
		function iniciar2(e){
			this.gotoAndPlay(15);
		}
	}
	this.frame_55 = function() {
		this.stop();
		
		this.botoncontinuar.on("click", continuar1.bind(this));
		
		function continuar1(e){
			this.gotoAndStop("msg2");
		}
	}
	this.frame_56 = function() {
		this.botoncontinuar.on("click", continuar2.bind(this));
		
		function continuar2(e){
			this.gotoAndStop("msg3");
		}
	}
	this.frame_57 = function() {
		this.botoncontinuar.on("click", continuar3.bind(this));
		
		function continuar3(e){
			this.gotoAndStop("msg4");
		}
	}
	this.frame_58 = function() {
		this.botoniniciar1.on("click", continuar4.bind(this));
		
		function continuar4(e){
			this.gotoAndPlay("msg5");	
		}
	}
	this.frame_68 = function() {
		this.stop();
		
		this.parent.cambiarEscenario(new lib.mc_escenario5(),0);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(14).call(this.frame_14).wait(41).call(this.frame_55).wait(1).call(this.frame_56).wait(1).call(this.frame_57).wait(1).call(this.frame_58).wait(10).call(this.frame_68).wait(1));

	// Chico
	this.instance = new lib.Interpolación2("synched",0);
	this.instance.setTransform(-227.05,752.8,0.7256,0.7256);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(51).to({_off:false},0).to({regY:0.1,x:-164.65,y:717.8},1).to({regY:0,x:-102.35,y:682.7},1).to({scaleX:0.7068,scaleY:0.7068,x:61,y:630.95},1).to({regX:0.1,regY:0.1,scaleX:0.688,scaleY:0.688,x:224.3,y:579.2},1).to({startPosition:0},1).to({startPosition:0},1).to({startPosition:0},1).to({x:205.85},1).to({x:-2.5,y:622.35},1).to({x:-141.1,y:673.7},1).to({_off:true},1).wait(7));

	// Textos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgtCrQgPgOAAgUQAAgUAPgOQANgOAUAAQATAAAOAOQAOAOAAAUQAAAUgOAOQgOAPgTAAQgUAAgNgPgAgyAyQAAgWAaggQAZgggBgWQAAgigiAAQgXAAgjASQgMAAAAhCIABgLQADgRAogKQAdgHAaAAQAvAAAeAaQAhAcAAAuQAABBg0AdQgnAWgEAXIgBAMQgCAFgHAAQgZAAgLADIgFABQgIAAgBgZg");
	this.shape.setTransform(916.7,159.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhUBjQgngkAAg9QAAg7AjgmQAjgnA6AAQAyAAAjAkQAiAkAAAyQAAAZgRAEIg1AGQgfADg7AFQADARATAIQAOAIATAAQAXAAAXgNIAUgMQAFACANAYQANAYAAAGQAAACgEAEQgfAihDAAQg9AAglgkgAgfg2QgKAMAAASQAAAHAIAAQATAAAngGQAJgCAAgDQAAgQgMgMQgLgMgPAAQgQAAgLAOg");
	this.shape_1.setTransform(892.425,164.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AiDC5QgHgBAAgJIAAifQAAgfgDg/IgChfQABgGAGAAIAqgBIAYgDIAZgCQAEAAABAHIgCAbIgCAbQgDA3ABAfQAAAHABAAIAHgFQAhgjAwAAQAsAAAcAUQAcAYAAArQAAA5g3AeQgGACAAADQAAAFAYAgQAZAgAAACQAAAHhGAAQgaAAgEgHQgKgSgVggQgCgBgsgDIAAAaIAAAaQAAAIgIABIgoAAQggAAgFgBgAgcANQgSANAAAPQgBAVAHAFQAEADAZAAQA0AAAAglQAAgggjAAQgPAAgTAMg");
	this.shape_2.setTransform(863.7,158.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgmCxQgGgBgBgCIgBgIIABg1IABg3QAAhIgGgsIgBgFQAAgFAHAAIAXABIAVACIAWgBIAXgCQAGAAAAAGIAAAEQgGAzAABBIABA5IABA4QAAAFgHABQgJACgfAAQgeAAgIgCgAgihjQgPgNAAgVQAAgUAQgNQAOgMAUAAQAUAAAPAMQAQANAAAUQAAAtgzAAQgVAAgOgLg");
	this.shape_3.setTransform(839.825,159.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAAC5QgNAAgDgFQgOgcgXg3IgkhTIgDgCQgBACAAAFIABBMIABBMQAAAJgHAAIhWAAQgGAAgBgBIgBgGQAAgcADg5QACg5AAgcIgChvIgChAIgBgFQAAgFALAAIArgBIArgBQACAAAGALIBLCmQAIAQAFAAQACAAAKgSIBNikQAFgKAFAAIAXAAIAWABIAUgBIAUgBQAIAAAAAGIgCBbQgDA9AAAdQAAAcADA5IACBUQAAAIgIAAIhbAAQgIAAAAgJIAChOIAChPQAAgHgCgBQgDACggBOIglBcQgDAGgEABIgJAAg");
	this.shape_4.setTransform(810.825,158.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgnC1QgGgCgBgFIAAgLIABhFIAAhFIAAhiQAAg5gGgqIgBgEQAAgGAHAAIBbAAQAHAAgBAGIAAAEQgHBwAABVIABBsIABAVIABAUQAAAGgHABQgMACgdAAQgfAAgIgCg");
	this.shape_5.setTransform(768.8018,158.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhsBcQgfgmAAg0QAAg6AgglQAiglA6gBQAoABAYAcIACABQACAAADgMQADgNAEAAQAJAAAbAFIAlAJQAEACAAADIAAAFQgJAvAAA0QAAATADAoIABA6QABALgKABQggACgpAAQgFAAgCgPQgBgPgCAAIgGAEQgdAdggAAQgzAAghgngAglgmQgOAPAAAVQAAAUAPAPQAOAQAVgBQAVABAOgOQAOgPAAgWQAAgWgOgOQgOgOgVAAQgWAAgOAOg");
	this.shape_6.setTransform(745.7,164.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhDBxIABg0IACgzQAAgKgNAAIgDAAIgEAAQgKAAAAgHIABgNIAAgMIAAgRIgBgQQAAgFARgBQAJAAABgFQACgKgBgWIgBgfQAAgeAGAAQAGAAAOADIAUAEIAnAFQAGAAAAAEIgCAgIgBAfQAAANAIAAIAbgBIAcgBQAFAAAAAEIgBASIgCASIABASIAAASQAAAFgIgBIgQAAIgSgBIgUAAQgEAAABAMIAAATIAAASQAAAWAFAIQAHALAUAAQAHAAAMgDQAMgDAFAAQAFAAAAAFIgCAYQgCAQAAAHQAAAIgBACQgCACgHAEQghASgpAAQhKAAAAg5g");
	this.shape_7.setTransform(720.55,160.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhUBjQgngkAAg9QAAg7AjgmQAjgnA6AAQAyAAAjAkQAiAkAAAyQAAAZgRAEIg1AGQgfADg7AFQADARATAIQAOAIATAAQAXAAAXgNIAUgMQAFACANAYQANAYAAAGQAAACgEAEQgfAihDAAQg9AAglgkgAgfg2QgKAMAAASQAAAHAIAAQATAAAngGQAJgCAAgDQAAgQgMgMQgLgMgPAAQgQAAgLAOg");
	this.shape_8.setTransform(684.225,164.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAtB7QgFAAgBgGIgCgPQgBgMgCAAIAAAAIAAAAQABABgbAQQgdARgZAAQhEAAgNg9QgGgdAAg2QAAg6AKgjQADgKAIAAIAkAAIAkAAQAIAAAAAHIAAAFQgGAjAAAkQAAAtADAQQAFAdAdAAQAKAAAOgLQANgKAAgKQABgKAAh3QAAgJABgCQACgCAIAAIAmABIAmAAQAIAAABADIABAHIgCA5IgCA5IABA4IACA3QAAAHgHACQgKACggAAQgcAAgLgBg");
	this.shape_9.setTransform(655.325,164.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AglDXQgGgCgCgHQgDgPABgkQg/gPglgzQglgyAAhBQAAhQA0g4QA1g3BPAAQBPgBA2A5QA0A3AABQQAABEgmAxQgmAzhDAOQANAbAaAWIACADQAAAKg/AAQguABgLgEgAg/hdQgWAZAAAqQAAApAWAZQAXAbAoAAQAoAAAYgcQAWgaAAgoQAAgogXgaQgYgcgnAAQgnAAgYAcg");
	this.shape_10.setTransform(619.925,161.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhHCgQghgcAAguQAAhBA0gdQAngWADgXIACgMQACgFAGAAQAaAAAMgEIADAAQAKAAAAAZQAAAWgaAgQgZAgAAAWQAAAiAjAAQAPAAAXgJQAXgJgCAAQALAAAABCIgBALQgDARgoAKQgdAHgaAAQgvAAgegagABeBLIAAAAIAAAAgAgUhmQgOgOAAgUQAAgUAOgOQAOgPATAAQAUAAAOAPQAOAOAAAUQAAAUgOAOQgOAOgUAAQgTAAgOgOg");
	this.shape_11.setTransform(589.025,159.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgiCqQgOgOAAgWQAAgVAOgOQANgOAVAAQAWAAANAOQAOAOAAAVQAAAWgOAOQgNAPgWAAQgVAAgNgPgAgXA0QgZhSAAgLIABggIACgfIgBgjIgBgjQAAgKAFAAIAVABIAVABIAWgBIAWgBQAFAAAAA/QAAAvgJApIgUBUQgDAKgRAAQgVAAgCgJg");
	this.shape_12.setTransform(800.275,97.675);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhrCkIgJgaIgIgSQgGgNAAgFQAAgEAEAAQBIAAAAgiQABgCgkgxQgkgxgEgNQgCgIAAguIAAgcIABgcQAAgGAIgBIApACIAnAAQAGAAAAAIIAAAWIgBAWIABAsQAAAJAPAZQAQAZAFABQAHgBAOgZQANgYABgJQADgWgBgbIgBgVIgBgWQAAgEAGAAIAngBIAngCQAHABACAGQAEAMAAArQAAAygDALQgEANg1BQQgIANgjAuQgkAygFAEQgHADhJAAQgLAAgEgCg");
	this.shape_13.setTransform(778.55,107.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AhUBjQgngkAAg9QAAg7AjgmQAjgnA6AAQAyAAAjAkQAiAkAAAyQAAAZgRAEIg1AGQgfADg7AFQADARATAIQAOAIATAAQAXAAAXgNIAUgMQAFACANAYQANAYAAAGQAAACgEAEQgfAihDAAQg9AAglgkgAgfg2QgKAMAAASQAAAHAIAAQATAAAngGQAJgCAAgDQAAgQgMgMQgLgMgPAAQgQAAgLAOg");
	this.shape_14.setTransform(751.075,102.725);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("ABIC1QgHgCAAgFIABg+IACg9QAAgKgFgCQgJgCg2AAQg1AAgJACQgFABgBALIABA8IACA9QAAAHgHACQgJABgoAAQgjAAgJgBQgIgCAAgGQAAgcADg5QACg4ABgcQgBgdgCg8QgDg9AAgeQAAgFAGAAIAZAAIAXABIAZgBIAaAAQADAAAAAEQAAAUgCAnQgDAmAAAUQAAAJAFABQAHACA6AAQA3AAAKgCQAFgBAAgJIgBg5IgCg4QAAgIAHAAIAWAAIAYABIAWgBIAXAAQAIAAAAAGIgCBaQgDA8AAAdQAAAcADA4QACA5ABAcQAAAFgCABIgIACQgQABgcAAQgpAAgHgBg");
	this.shape_15.setTransform(717.85,97.425);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("EAjeAM0QiphrgcAAMhEOAAAQhHAAgyhGQgxhGAAhkIAAyaQAAhjAxhGQAyhHBHAAMBEOAAAQBGAAAyBHQAxBGABBjIAASaQAAAmBeC2QBzDeAMAfQhshHhWg3g");
	this.shape_16.setTransform(769.15,140.1);

	this.botoncontinuar = new lib.BotonContinuar();
	this.botoncontinuar.name = "botoncontinuar";
	this.botoncontinuar.setTransform(835.1,653.15,1,1,0,0,0,55.1,55.1);
	new cjs.ButtonHelper(this.botoncontinuar, 0, 1, 2, false, new lib.BotonContinuar(), 3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("Ag2BiQgHgBAAgFIABgwIAAgvQAAgvgJgfIAAgDQAAgDADgBIAggEIAhgGQACAAABAMQABAMADABIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCgBASgKQATgKASAAQALAAAAAFIgBAQIgBAQIAAAQIAAAQQAAAHgIAAIgLAAIgLgBQgRAAgGAGQgGAFAAAPIABAaIAAAaIABARIAAARQAAAFgGABIgdAAIgegBg");
	this.shape_17.setTransform(736.075,180.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AhTBHQgYgdAAgoQAAgtAZgcQAageAtAAQAfAAASAWIABABQACAAACgJQADgKADAAQAHAAAVAEQAUAEAIADQABABABAAQAAAAAAABQABAAAAAAQAAABAAAAIAAAEQgHAlAAAoIACAtIACAuQAAAIgHAAQgZACggAAQgEAAgBgLQgBgMgCAAIgEADQgXAXgYAAQgnAAgagfgAgcgdQgLALAAARQAAAQALALQALAMAQAAQAQAAALgLQALgLAAgRQAAgRgLgLQgKgLgRAAQgRAAgKALg");
	this.shape_18.setTransform(715.575,180.275);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgzCCQAAgRAFgCQAQgEAEgFQAFgGABgQIABg4QAAgzgHgrIgBgDQAAgFAGAAQAUAAAKgBIAjgEQAEAAABAGQABAJAABEIAABFQAAAqgOAUQgQAYgmAIQgLACgOAAQgIAAAAgjgAgPhoQgLgKAAgQQAAgPAMgLQALgIAPAAQAQAAALAIQANAKAAAQQAAAhgoABQgQAAgLgIg");
	this.shape_19.setTransform(697.075,178.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AhTBHQgYgdAAgoQAAgtAZgcQAageAtAAQAfAAASAWIABABQACAAACgJQADgKADAAQAHAAAVAEQAUAEAIADQABABABAAQAAAAAAABQABAAAAAAQAAABAAAAIAAAEQgHAlAAAoIACAtIACAuQAAAIgHAAQgZACggAAQgEAAgBgLQgBgMgCAAIgEADQgXAXgYAAQgnAAgagfgAgcgdQgLALAAARQAAAQALALQALAMAQAAQAQAAALgLQALgLAAgRQAAgRgLgLQgKgLgRAAQgRAAgKALg");
	this.shape_20.setTransform(680.125,180.275);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgeCJQgEgBgBgBIgBgGIABgqIABgqQgBg3gEgiIAAgEQAAgEAGAAIARABIAQABIARgBIARgBQAGAAAAAEIgBAEQgFAnAAAyIABAsIABArQAAAEgFABQgHABgYAAQgXAAgHgBgAgbhMQgLgKgBgQQAAgQANgKQALgJAQAAQAPAAAMAJQAMAKAAAQQAAAignAAQgRAAgLgIg");
	this.shape_21.setTransform(662.85,176.275);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgYBeQgEAAgDgDQgMgNgXggQgXgkgFgLQgFgOAAgbIAAgYIAAgYQAAgFAHAAIAfAAIAfABQAFAAAAAHIgBARIgBARQAAAUABANQABAHALASQALAUAEAAQAFAAALgUQALgRABgHQABgNAAgVIgBgRIgBgRQAAgHAEAAIAPAAIAOAAIAOgBIAPAAQAFAAABAFQAEALAAAkQAAAigCAGQgFANgXAjQgUAdgOAQQgFAGgbAAQgVAAgHgCg");
	this.shape_22.setTransform(646.175,180.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AhBBNQgegcAAgwQAAgtAbgdQAbgfAtAAQAmAAAbAcQAbAcAAAnQAAATgNADIgpAEQgYADguAEQADANAOAGQALAGAPAAQARAAATgKIAPgJQAEACAKASQAKATAAAFQAAABgDADQgZAbgzAAQgvAAgdgcgAgYgqQgHAKAAANQAAAGAFAAQAPAAAegFQAHgBAAgCQAAgNgJgJQgJgJgLAAQgMAAgJAKg");
	this.shape_23.setTransform(614.825,180.125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AhVB0QgZgcAAgrQAAgsAYgbQAageAqAAQAeAAAQATIAEADQACAAAAgFIgBguIgBguQAAgGADAAIAkgDIAkgFQADAAABAEIgCAOIgEA5QgBAnAAAyQAABSAEAjIABAFQAAABAAAAQAAABgBAAQAAAAgBAAQAAABgBAAQgHABguAAQgLAAgBgFIgBgPIgBgDIgEACQgVAWggAAQgqAAgZgegAgcAQQgJALAAARQAAAQAJALQALAMAPAAQAPAAALgMQALgMAAgQQAAgQgLgLQgLgMgPAAQgQAAgKAMgABriRIAAAAIAAAAg");
	this.shape_24.setTransform(592.1,175.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgwBXQgOgXAAgEQAAgBAAAAQABgBAAAAQAAAAAAAAQABAAAAgBIAdgEQARgHAAgMQAAgJgKgMIgTgUQgKgPAAgPQAAgfAegUQAagTAfAAQAEAAAMAVQANAWAAADQAAACgDAEIgLgBQgMgBgIAGQgKAGAAALQAAAHAKAKQAQARADAEQALAQAAARQAAAKgEALQgFAOgHAFQgPANgUAJQgUAJgSAAQgEAAgOgVg");
	this.shape_25.setTransform(562.525,179.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AhTBHQgYgdAAgoQAAgtAZgcQAageAtAAQAfAAASAWIABABQACAAACgJQADgKADAAQAHAAAVAEQAUAEAIADQABABABAAQAAAAABABQAAAAAAAAQAAABAAAAIAAAEQgHAlAAAoIACAtIACAuQAAAIgHAAQgZACggAAQgEAAgBgLQgBgMgCAAIgEADQgXAXgYAAQgnAAgagfgAgcgdQgLALAAARQAAAQALALQALAMAQAAQAQAAALgLQALgLAAgRQAAgRgLgLQgKgLgRAAQgRAAgKALg");
	this.shape_26.setTransform(543.025,180.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAkBiQgGAAAAgIIAAgcIABgdIgBgWIAAgVQAAgcgYABQgGgBgLAIQgLAHAAAHIAABrQAAAHgGABIgdAAQgXAAgHgBQgGgBgBgFIABgvIAAguQAAgygIgdIAAgCQAAgEADgBIAhgEIAkgHQADAAABAOQABANACAAIAAAAIAAAAQgCAAAYgNQAWgOASgBQAaABARALQASAOAAAZIAAA/IABAnIAAAmQAAAGgGABIgdAAQgZAAgGgBg");
	this.shape_27.setTransform(519.5,180.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AhTBHQgYgdAAgoQAAgtAZgcQAageAtAAQAfAAASAWIABABQACAAACgJQADgKADAAQAHAAAVAEQAUAEAIADQABABABAAQAAAAAAABQABAAAAAAQAAABAAAAIAAAEQgHAlAAAoIACAtIACAuQAAAIgHAAQgZACggAAQgEAAgBgLQgBgMgCAAIgEADQgXAXgYAAQgnAAgagfgAgcgdQgLALAAARQAAAQALALQALAMAQAAQAQAAALgLQALgLAAgRQAAgRgLgLQgKgLgRAAQgRAAgKALg");
	this.shape_28.setTransform(495.725,180.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgwB6QglgHAAgJQAAgEAJgkQABgFADAAIACABQAfAPAbAAQANAAAOgHQARgJAAgNIAAgNQgUATgfAAQgmAAgYgbQgXgaAAglQAAgnAWgZQAYgaAlAAQAeAAAQAWIAEAEQACAAAAgHQAAgQADAAIAjADIAhAEQADABAAAEIgBApIgBApIAAAZIABAYQAAA5gYAZQgZAZg5AAQgRAAgdgFgAgXg8QgKALAAAPQAAAOAKALQAKAJANAAQAPAAAKgJQAJgLAAgPQAAgOgJgLQgKgLgPAAQgNAAgKALg");
	this.shape_29.setTransform(471.925,182.825);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAkBiQgGAAAAgIIABgcIAAgdIAAgWIAAgVQAAgbgYgBQgIAAgJAIQgMAHAAAHIAABrQAAAHgGABIgcAAQgYAAgHgBQgHgBABgFIAAgvIAAgvQAAgxgIgdIAAgDQAAgDADgBIAhgFIAkgGQACAAABAOQACANACAAIAAAAIAAAAQgCAAAXgNQAYgOARgBQAZABARAMQAUAOAAAYIAAA/IAAAnIAAAnQAAAFgFABIgeAAQgZAAgGgBg");
	this.shape_30.setTransform(746.35,132.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AhHBKQgdgcAAgsQAAgtAbgdQAcgdAtAAQAtAAAcAcQAcAdAAAsQAAAtgbAdQgdAcgtAAQgrAAgcgcgAgZgbQgJAMAAAPQAAAQAJAMQALAMAOAAQAQAAAKgMQAKgMAAgQQAAgPgLgMQgJgMgQAAQgOAAgLAMg");
	this.shape_31.setTransform(724.15,132.125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgyBKQgdgeAAgsQAAgrAdgeQAdgdArAAQAdAAAXAMQAFADAAADIgGAXIgHAYQgCAFgCAAIgLgEQgMgCgIAAQgSAAgKAKQgKALAAARQAAASALAKQAMALASAAQAIAAALgFIALgEQADAAAGAZQAEAXABAJQAAAHgaAFQgSAFgMAAQgsgBgcgdg");
	this.shape_32.setTransform(704.95,132.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgpA0QgLgNAAgEQgBgCAIgIQAJgLAFgIQAHgNAAgQIAAgIIgBgHQAAgFADgDQACgDAfgHQAdgIAGAAQAHAAABAJQAAA2gpAmIgSAQQgRAMgFAAQgDAAgLgNg");
	this.shape_33.setTransform(679.6,140.825);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AAkBiQgGAAAAgIIABgcIAAgdIAAgWIAAgVQAAgbgZgBQgHAAgKAIQgLAHAAAHIAABrQAAAHgGABIgcAAQgYAAgHgBQgGgBAAgFIAAgvIAAgvQAAgxgIgdIAAgDQAAgDADgBIAhgFIAlgGQABAAABAOQACANACAAIAAAAIAAAAQgCAAAXgNQAYgOARgBQAZABARAMQAUAOAAAYIAAA/IAAAnIAAAnQAAAFgGABIgdAAQgZAAgGgBg");
	this.shape_34.setTransform(662.65,132.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AhBBNQgegcAAgwQAAgtAbgdQAbgfAtAAQAmAAAbAcQAbAcAAAnQAAATgNADIgpAEQgYADguAEQADANAOAGQALAGAPAAQARAAATgKIAPgJQAEACAKASQAKATAAAFQAAABgDADQgZAbgzAAQgvAAgdgcgAgYgqQgHAKAAANQAAAGAFAAQAPAAAegFQAHgBAAgCQAAgNgJgJQgJgJgLAAQgMAAgJAKg");
	this.shape_35.setTransform(641.125,132.075);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgdCJQgFgBgBgBIAAgGIAAgqIAAgqQAAg3gDgiIgBgEQAAgEAFAAIARABIARABIARgBIASgBQAEAAAAAEIAAAEQgEAnAAAyIAAAsIABArQAAAEgFABQgHABgYAAQgXAAgGgBgAgbhMQgLgKAAgQQAAgQAMgKQALgJAPAAQAQAAALAJQANAKAAAQQAAAigoAAQgPAAgMgIg");
	this.shape_36.setTransform(625.1,128.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgcCAIgCgBQgCAAgCAHQgCAIgCAAQgDABg2AAQgMAAAAgEIAAgDQADggAAhaQABhUgHg/IAAgDQABgDAFAAIAjgDQAWgCAOAAQADAAAAAGIgBAVIgBAVIgBA2QAAAGADAAIADgBQASgUAcAAQAsAAAYAeQAXAbAAAtQAAAqgYAcQgZAegpAAQgeAAgSgRgAgYAPQgKALAAARQAAASAKAKQAKAMAQAAQAQAAALgMQAJgLAAgRQAAgRgKgLQgKgMgRAAQgQAAgJAMg");
	this.shape_37.setTransform(607.7,127.675);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AhTB/IgHgUIgFgOQgGgKAAgEQABgEADAAQA4AAAAgZQAAgCgbgmQgcgmgEgKQgBgGAAgjIAAgWIAAgWQAAgFAHAAIAfABIAfAAQAFAAgBAHIAAARIgBAQIABAjQAAAHAMATQAMATAFAAQAEAAALgTQAKgTABgGQACgSAAgUIgBgRIgBgQQAAgEAEAAIAfgBIAfgBQAEAAADAFQACAKAAAhQAAAngCAIQgEAKgoA+IghAtQgdAngEADQgFADg4AAQgJAAgDgCg");
	this.shape_38.setTransform(574.2,135.775);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AAjBfQgEgBgBgEIgBgMQgBgIgCgBIAAAAIAAAAQACABgWANQgWANgTAAQg1AAgKgwQgEgWAAgpQAAguAHgaQACgIAGAAIAcAAIAcAAQAHAAAAAFIgBAEQgEAcAAAcQAAAiACAMQAEAWAWAAQAIAAALgHQAKgIAAgJIABhjQAAgHABgBQABgCAGAAIAdAAIAeAAQAGAAABADIAAAFIgBAtIgCArIABArIABArQAAAGgFABQgHACgZAAIgegBg");
	this.shape_39.setTransform(551.175,132.525);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("ABfBjQgGgBAAgJIAAgbIABgcIgBgxQgBgYgVAAQgKABgJAHQgJAJgBAJIgBAwIABAdIAAAdQAAAGgGAAIg8AAQgFAAAAgIIABgcIAAgdIAAgXIAAgVQAAgdgXAAQgIABgLAGQgLAIABAIIAAA2IAAA2QAAAEgBACIgHACIgcAAIgdgBIgGgBQAAgCAAgEIAAgwIAAgwQAAgggFgpIAAgEQAAgDADgCIAQgCIASgCIAQgFQAKgCAFAAQAEAAABAOQAAAOACAAIAEgDQASgOAKgGQAQgHASAAQASAAAOAJQAQAIAEARQALgOATgKQATgKARAAQAaAAARAMQATAOAAAaIgBAgIgBAeIABAnIABAmQAAAGgGACIgeAAQgYAAgGgBg");
	this.shape_40.setTransform(521,132.05);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AhHBKQgdgcAAgsQAAgtAbgdQAbgdAuAAQAtAAAcAcQAcAdAAAsQAAAtgcAdQgbAcguAAQgrAAgcgcgAgZgbQgKAMAAAPQAAAQAKAMQAKAMAPAAQAQAAAKgMQAKgMAAgQQAAgPgKgMQgKgMgQAAQgPAAgKAMg");
	this.shape_41.setTransform(482.35,132.125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgkCMQgHgBABgFIABggIACggQAAgHgEgIQgZghgthGQgFgIABgFIgCgkIgBglQAAgGAEAAIAlABIAlABQAFAAAAADIgBAfIgBAfQAAAFASAYQAOAUAIAJIAVgcQASgYAAgFIgBgeIgCgfQAAgBAAgBQAAgBAAAAQABgBAAAAQABAAAAAAIAFAAIAkgBIAkgCQAEAAAAAIIAAAhIABAgQAAAIgDAHQgbA0gsA4QgHAJAAAGIABAgIABAfQAAABAAABQAAABAAAAQAAABAAAAQgBABAAAAIgFABQgIABgcAAQgcAAgIgBg");
	this.shape_42.setTransform(458.75,127.95);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgaCEQgKgLAAgRQAAgRAKgKQAKgMAQABQAQgBALAMQALAKAAARQAAARgLALQgKALgRAAQgQAAgKgLgAgSApQgShAAAgIIAAgZIABgZIAAgbIgBgbQAAgHADAAIARABIAQABIARgBIAQgBQAFAAAAAxQgBAkgGAgIgQBBQgCAHgNAAQgQAAgCgGg");
	this.shape_43.setTransform(681.95,80.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AhWB0QgXgcAAgrQAAgsAXgbQAageAqAAQAdAAARATIAEADQACAAAAgFIgBguIAAguQAAgGADAAIAjgDIAkgFQADAAAAAEIgBAOIgDA5QgCAnAAAyQAABSAEAjIABAFQAAABAAAAQAAABgBAAQAAAAgBAAQAAABgBAAQgHABguAAQgKAAgDgFIAAgPIgCgDIgCACQgWAWggAAQgqAAgagegAgbAQQgKALAAARQAAAQAKALQAJAMARAAQAPAAALgMQAKgMABgQQAAgQgMgLQgLgMgOAAQgRAAgJAMgABriRIAAAAIAAAAg");
	this.shape_44.setTransform(663.7,79.575);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AAjBfQgEgBgBgEIgBgMQgBgIgCgBIAAAAIAAAAQACABgWANQgWANgTAAQg1AAgKgwQgEgWAAgpQAAguAHgaQACgIAGAAIAcAAIAcAAQAHAAAAAFIgBAEQgEAcAAAcQAAAiACAMQAEAWAWAAQAIAAALgHQAKgIAAgJIABhjQAAgHABgBQABgCAGAAIAdAAIAeAAQAGAAABADIAAAFIgBAtIgCArIABArIABArQAAAGgFABQgHACgZAAIgegBg");
	this.shape_45.setTransform(639.975,84.475);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgICiIgWgZIgZgWQgBgBAAAAQgBgBAAAAQAAgBAAAAQAAgBgBAAQABAAAAgBQAAAAAAgBQAAgBABAAQAAgBABAAQAPgNADgFQAIgJAFgPQAFgTAAgtQAAhlgHg5IgBgDQAAgEAHABIATAAIASABIARgBIASAAQAHAAAAAEIgBBUIAABTQAAAxgJAcQgPAwggAcQgDAEgDgBQgCABgCgDg");
	this.shape_46.setTransform(620.1,82.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AhTBHQgYgdAAgoQAAgtAZgcQAageAtAAQAfAAASAWIABABQACAAACgJQADgKADAAQAHAAAVAEQAUAEAIADQABABABAAQAAAAAAAAQABABAAAAQAAABAAAAIAAAEQgHAlAAAoIACAtIACAuQAAAIgHAAQgZACggAAQgEAAgBgLQgBgMgCAAIgEADQgXAXgYAAQgnAAgagfgAgcgdQgLALAAARQAAAQALALQALAMAQAAQAQAAALgLQALgLAAgRQAAgRgLgLQgKgLgRAAQgRAAgKALg");
	this.shape_47.setTransform(591.575,84.175);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgeCMQgFgBAAgFIAAgIIAAg2IAAg1IABhLQgBgsgEghIgBgDQAAgFAFABIBHAAQAFgBAAAFIgBADQgFBXAABBIABBVIAAAPIABAQQAAAEgFABQgJABgXAAQgYAAgGgBg");
	this.shape_48.setTransform(574.425,79.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AhIBKQgcgcAAgsQAAgtAbgdQAbgdAuAAQAtAAAcAcQAcAdAAAsQAAAtgcAdQgcAcgtAAQgrAAgdgcgAgZgbQgKAMAAAPQAAAQAKAMQAKAMAPAAQAQAAAKgMQAJgMAAgQQABgPgKgMQgKgMgQAAQgOAAgLAMg");
	this.shape_49.setTransform(558.15,84.075);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AA4CMQgGgBAAgFIACgvIABgvQAAgJgEAAQgHgCgqAAQgpAAgHACQgEAAAAAJIABAvIABAuQAAAGgFABQgHABgfAAQgbAAgIgBQgFgBAAgFIAChBIAChCIgChEIgChHQAAgEAEAAIATABIATABIATgBIATgBQABAAABAAQAAAAABABQAAAAABABQAAABAAABQAAAOgDAfIgCAtQAAAHAEABQAFACAtgBQArABAHgCQAFgBAAgHIgCgsIgBgsQAAgGAFAAIASABIARABIASgBIASgBQAGAAAAAFIgCBGIgCBEIACBCIACBBQAAAEgBABIgGABIgjABQgfAAgFgBg");
	this.shape_50.setTransform(532.025,79.9);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("EgkgAK1QBei2AAgmIAAyaQABhjAxhGQAyhHBGAAMBEPAAAQBGAAAyBHQAyBGgBBjIAASaQABBkgyBGQgyBGhGAAMhEPAAAQgcAAipBrQhWA3hsBHQAMgfBzjeg");
	this.shape_51.setTransform(586.45,140.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgiCBQgLgLAAgPQAAgPALgKQALgLAOAAQAPAAAKALQAKAKAAAPQAAAPgKALQgKALgPAAQgOAAgLgLgAglAlQAAgQATgYQASgYAAgRQAAgZgaAAQgRAAgbANQgIAAAAgyIAAgIQADgNAegHQAWgFAUAAQAiAAAXATQAZAVAAAjQAAAxgnAWQgdAQgDASIgBAJQgCAEgFAAQgTAAgJACIgCABQgHAAAAgUg");
	this.shape_52.setTransform(763.35,218.125);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AhGBIQgcgbAAgrQAAgsAbgcQAbgdAsAAQAsAAAbAcQAcAcAAArQAAAsgbAcQgcAcgsAAQgqAAgcgcgAgYgaQgJALAAAPQAAAPAJAMQAKAMAOAAQAQAAAKgMQAJgMAAgPQAAgPgKgLQgJgMgQAAQgOAAgKAMg");
	this.shape_53.setTransform(744.325,222.075);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AhTBxQgYgbAAgqQAAgrAYgaQAYgeAqAAQAdAAAQATIADADQADAAAAgFIgBgtIgBgtQAAgFADgBIAjgCIAigFQAEAAAAAEIgBANQgCAWgCAiQgCAmAAAwQABBRAEAiIABAFQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAgBAAQgGABgtAAQgLAAgBgEIgBgPIgCgDIgCACQgVAVgfAAQgqAAgYgdgAgaAPQgKAMAAAQQAAAQAKALQAJALAQAAQAOAAALgLQALgMAAgQQAAgPgLgMQgLgMgOAAQgQAAgJAMg");
	this.shape_54.setTransform(721.75,217.675);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AAkBgQgHgBAAgHIABgcIAAgcIAAgVIAAgVQAAgagYAAQgGgBgKAHQgLAHAAAIIAABoQAAAHgGAAIgcABQgXAAgHgBQgGgBAAgFIABguIAAguQAAgwgIgcIAAgCQAAgEADgBIAhgEIAigHQACAAACAOQAAANADAAIAAAAIAAAAQgCAAAXgOQAWgNARAAQAZAAARALQATAOAAAYIAAA9IAAAnIAAAmQAAAEgGABIgcABQgZAAgFgBg");
	this.shape_55.setTransform(698.6,222.05);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AAiBdQgEgBgBgEIgBgLQgBgJgBAAIgBAAIABAAQABAAgVAMQgWAOgSAAQg0AAgJgvQgFgVAAgpQAAgsAHgaQADgIAGAAIAbABIAbAAQAGAAAAAEIAAAFQgEAaAAAcQAAAhACAMQADAVAWAAQAIABAKgIQAKgIABgIIAAhhQAAgGABgBQABgCAGAAIAdAAIAdAAQAFAAABADIABAFIgCArIgBAqIABArIABAqQAAAFgFABQgHACgYAAIgegBg");
	this.shape_56.setTransform(675.875,222.45);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("ABdBhQgGgBAAgJIABgbIAAgbIAAgwQgCgWgVAAQgJAAgJAHQgJAIgBAJQgBAJAAAmIAAAcIABAcQAAAGgFABIg7AAQgFAAAAgJIABgbIAAgcIAAgWIAAgVQgBgbgVAAQgJAAgKAGQgLAHAAAIIABA0IAAA1IgBAHIgGABIgcABIgcgBIgGgCQgBgBAAgFIABguIAAguQAAghgEgnIgBgEQAAgDACgBIARgEIASgBIAPgEQAJgDAGAAQAEAAAAAOQAAAOACAAIAEgEQARgNALgFQAPgIARAAQASABAOAHQAQAJAEARQALgPARgJQASgKASAAQAZAAARANQASANAAAZIAAAfIgBAfIABAlIAAAkQAAAHgGABIgcABQgZAAgFgBg");
	this.shape_57.setTransform(646.45,222);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgdCJQgFgBAAgFIAAgIIAAg0IABg0IAAhKQgBgrgEggIgBgCQAAgFAGAAIBEAAQAFAAAAAEIAAADQgGBVAABAIABBSIAAAPIABAPQAAAFgFABQgJABgWAAQgXAAgGgBg");
	this.shape_58.setTransform(953.2773,171.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAlQAAATgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEACAKASQAKASAAAFQAAABgDAEQgYAZgyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegFQAGAAAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_59.setTransform(938.075,175.1);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AAjBgQgFgBAAgHIAAgcIABgcIgBgVIAAgVQAAgbgYAAQgGAAgKAHQgLAHAAAIIAABoQAAAGgGABIgcABQgXAAgHgBQgGgBAAgFIAAgvIAAgtQABgwgIgcIgBgCQABgEADgBIAggEIAjgGQADAAABANQAAANADAAIAAAAIAAAAQgCAAAXgOQAWgNASAAQAYAAARALQASAOABAYIAAA9IAAAmIAAAnQgBAEgEABIgdABQgZAAgGgBg");
	this.shape_60.setTransform(906.3,175.15);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAlQAAATgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEACAKASQAKASAAAFQAAABgDAEQgYAZgyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegFQAGAAAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_61.setTransform(885.325,175.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AhRBFQgXgcAAgnQAAgsAYgcQAZgcAsAAQAeAAASAVIABABQACAAACgJQACgKAEAAQAHAAAUAEQAUAEAIADQABAAAAABQABAAAAABQAAAAAAAAQAAABAAAAIAAAEQgGAkAAAnIACAsIACAsQgBAIgHABQgXACggAAQgDAAgCgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPAKALQAMAMAPAAQAQAAAKgLQALgLAAgQQAAgQgLgLQgKgLgQAAQgRAAgKALg");
	this.shape_62.setTransform(853.1,175.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AhTBxQgYgbAAgqQAAgrAXgaQAZgeAqAAQAcAAAQATIAFADQABAAAAgFIAAgtIgBgtQAAgFADgBIAigCIAjgFQAEAAAAAEIgCANQgBAWgBAiQgCAmAAAwQgBBRAFAiIAAAFQAAAAAAABQAAAAAAAAQgBABAAAAQgBAAAAAAQgIABgsAAQgLAAgBgEIgBgPIgBgDIgEACQgUAVgfAAQgqAAgYgdgAgbAPQgJAMAAAQQAAAQAJALQAKALAQAAQAPAAAKgLQAKgMAAgQQAAgPgKgMQgLgMgOAAQgQAAgKAMgABoiNIAAAAIAAAAg");
	this.shape_63.setTransform(829.7,170.775);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgdCGQgEgBgBgCIgBgGIABgoIAAgpQAAg2gDghIgBgEQAAgEAFAAIARABIAQABIARgBIARgBQAFAAgBAEIAAAEQgEAmAAAxIABArIAAAqQAAAEgFABQgHABgWAAQgXAAgHgBgAgZhLQgMgJAAgQQAAgPAMgKQALgJAPAAQAPAAALAJQAMAKAAAPQAAAigmAAQgPAAgLgJg");
	this.shape_64.setTransform(812.65,171.375);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgXBcQgFgBgCgDQgMgMgWggQgXgigFgLQgEgOAAgbIAAgWIAAgYQAAgFAHAAIAeABIAeAAQAFAAAAAHIgCAQIgBARQAAAUACANQAAAHALARQALATAFAAQAEAAALgTQALgQAAgHQACgOAAgTIgBgRIgCgRQABgHAEAAIANABIAOAAIAPgBIANgBQAFAAACAFQAEAMgBAiQAAAhgBAGQgFANgWAhQgUAdgOAQQgFAGgZAAQgWAAgGgCg");
	this.shape_65.setTransform(796.4,175.525);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AhRBFQgYgcABgnQgBgsAZgcQAZgcAsAAQAeAAASAVIABABQACAAACgJQADgKADAAQAHAAAUAEQAUAEAIADQABAAAAABQABAAAAABQAAAAAAAAQAAABAAAAIAAAEQgGAkAAAnIACAsIACAsQAAAIgIABQgXACggAAQgEAAgBgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPAKALQALAMAQAAQAQAAAKgLQALgLAAgQQAAgQgLgLQgKgLgQAAQgQAAgLALg");
	this.shape_66.setTransform(763.65,175.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgdCJQgFgBAAgFIAAgIIAAg0IABg0IAAhKQgBgrgEggIgBgCQAAgFAGAAIBEAAQAFAAAAAEIAAADQgGBVAABAIABBSIAAAPIABAPQAAAFgFABQgJABgWAAQgXAAgGgBg");
	this.shape_67.setTransform(746.8773,171.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAlQAAATgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEACAKASQAKASAAAFQAAABgDAEQgYAZgyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegFQAGAAAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_68.setTransform(721.675,175.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AhTBxQgYgbAAgqQAAgrAXgaQAZgeAqAAQAcAAARATIADADQACAAAAgFIgBgtIAAgtQAAgFADgBIAigCIAjgFQAEAAAAAEIgBANQgDAWgBAiQgCAmAAAwQABBRAEAiIABAFQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAgBAAQgGABgtAAQgLAAgBgEIgBgPIgBgDIgDACQgVAVgfAAQgpAAgZgdgAgaAPQgKAMAAAQQAAAQAKALQAJALAQAAQAOAAALgLQALgMAAgQQAAgPgLgMQgLgMgOAAQgQAAgJAMg");
	this.shape_69.setTransform(699.5,170.775);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AguBUQgPgVAAgFQAAAAABAAQAAgBAAAAQAAAAABAAQAAgBABAAIAcgFQARgFAAgNQAAgIgLgMIgSgUQgKgOAAgPQAAgeAegUQAagSAeAAQADAAAMAVQANAVgBADQAAACgCAEIgMgCQgLAAgIAFQgJAGAAALQAAAHAJAKQAQAQADAFQALAOAAARQgBAKgEALQgEANgHAFQgPANgTAIQgTAJgSAAQgEAAgNgVg");
	this.shape_70.setTransform(670.65,174.925);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAlQAAATgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEACAKASQAKASAAAFQAAABgDAEQgYAZgyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegFQAGAAAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_71.setTransform(653.825,175.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AAjBgQgFgBAAgHIAAgcIABgcIgBgVIAAgVQAAgbgXAAQgHAAgKAHQgLAHAAAIIAABoQAAAGgGABIgcABQgXAAgHgBQgGgBAAgFIAAgvIAAgtQAAgwgHgcIgBgCQAAgEAEgBIAggEIAjgGQACAAABANQABANADAAIAAAAIAAAAQgCAAAXgOQAWgNASAAQAYAAARALQASAOAAAYIAAA9IAAAmIAAAnQAAAEgEABIgdABQgZAAgGgBg");
	this.shape_72.setTransform(632.05,175.15);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AhGBIQgcgbAAgrQAAgsAbgcQAbgdAsAAQAsAAAbAcQAcAcAAArQAAAsgbAcQgcAcgsAAQgqAAgcgcgAgYgaQgJALAAAPQAAAPAJAMQAKAMAOAAQAQAAAKgMQAJgMAAgPQAAgPgKgLQgJgMgQAAQgOAAgKAMg");
	this.shape_73.setTransform(610.375,175.175);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgdCGQgEgBgBgCIAAgGIAAgoIAAgpQAAg2gDghIgBgEQAAgEAFAAIARABIAQABIARgBIARgBQAEAAAAAEIAAAEQgEAmAAAxIABArIAAAqQAAAEgFABQgHABgWAAQgXAAgHgBgAgZhLQgMgJAAgQQAAgPAMgKQALgJAPAAQAPAAALAJQAMAKAAAPQAAAigmAAQgPAAgLgJg");
	this.shape_74.setTransform(594.3,171.375);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgxBIQgcgdAAgrQAAgqAdgdQAcgdApAAQAdAAAWAMQAGADAAADIgGAXIgHAYQgCAEgCAAIgMgDQgLgEgIAAQgRAAgKALQgKAKAAARQAAASALAKQALAKASAAQAJAAALgEIAKgFQADAAAFAZQAFAXAAAHQAAAIgYAFQgTAEgMAAQgqAAgcgdg");
	this.shape_75.setTransform(580.625,175.125);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AhRBFQgYgcAAgnQAAgsAZgcQAZgcAtAAQAdAAASAVIABABQACAAADgJQACgKACAAQAIAAAUAEQATAEAJADQABAAAAABQABAAAAABQAAAAAAAAQABABAAAAIgBAEQgGAkAAAnIABAsIACAsQABAIgIABQgXACggAAQgEAAgBgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPALALQAKAMARAAQAPAAALgLQAKgLAAgQQAAgQgKgLQgLgLgPAAQgSAAgKALg");
	this.shape_76.setTransform(560.1,175.275);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("Ag1BgQgGgBAAgFIAAgvIAAguQAAgugIgdIgBgEQAAAAAAgBQABgBAAAAQAAgBABAAQAAAAABAAIAggEIAggHQACAAABAMQABAMADABIAAAAIAAAAQgCgBASgKQASgJASgBQALAAAAAFIgBAQIgCAQIAAAPIABAQQAAAHgJAAIgKAAIgLgBQgQAAgGAFQgGAFAAAOIAAAaIABAZIAAASIABAQQAAAFgGAAIgcABIgegBg");
	this.shape_77.setTransform(541.375,175.15);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgbB9IgCgBQgDAAgBAHQgCAHgCABQgEABgzAAQgNAAAAgFIAAgDQAEgfABhXQgBhSgFg+IgBgCQAAgDAHgBIAhgDQAVgCANAAQAEAAAAAHIgBAUIgCAUIgBA1QAAAGAEAAQAAAAAAAAQABAAAAAAQABgBAAAAQAAAAABgBQARgSAcAAQArAAAXAdQAXAaAAAsQAAApgYAbQgZAegoAAQgcAAgSgRgAgYAOQgJALAAARQAAARAJALQAKALAPAAQARAAAKgMQAJgKAAgRQAAgRgKgLQgKgLgQAAQgPAAgKALg");
	this.shape_78.setTransform(521.95,170.825);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAlQAAATgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEACAKASQAKASAAAFQAAABgDAEQgYAZgyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegFQAGAAAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_79.setTransform(500.025,175.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgdCJQgFgBAAgFIAAgIIAAg0IABg0IAAhKQgBgrgEggIgBgCQAAgFAGAAIBEAAQAFAAAAAEIAAADQgGBVAABAIABBSIAAAPIABAPQAAAFgFABQgJABgWAAQgXAAgGgBg");
	this.shape_80.setTransform(484.4773,171.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAlQAAATgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEACAKASQAKASAAAFQAAABgDAEQgYAZgyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegFQAGAAAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_81.setTransform(469.275,175.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgxBIQgcgdAAgrQAAgqAdgdQAcgdApAAQAdAAAWAMQAGADAAADIgGAXIgHAYQgCAEgCAAIgMgDQgLgEgIAAQgRAAgKALQgKAKAAARQAAASALAKQALAKASAAQAJAAALgEIAKgFQADAAAFAZQAFAXAAAHQAAAIgYAFQgTAEgMAAQgqAAgcgdg");
	this.shape_82.setTransform(450.925,175.125);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AguBUQgPgVAAgFQAAAAABAAQAAgBAAAAQAAAAABAAQAAgBABAAIAbgFQASgFgBgNQABgIgLgMIgSgUQgKgOAAgPQAAgeAegUQAZgSAfAAQADAAAMAVQANAVAAADQAAACgEAEIgLgCQgLAAgIAFQgJAGAAALQAAAHAJAKQAQAQADAFQALAOgBARQAAAKgDALQgFANgHAFQgOANgUAIQgTAJgSAAQgEAAgNgVg");
	this.shape_83.setTransform(882.3,128.025);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAmQAAASgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEADAKARQAKASAAAFQAAACgDACQgYAagyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegEQAGgBAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_84.setTransform(865.475,128.2);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgyBWIABgoIABgmQAAgIgKAAIgDAAIgCAAQgIAAAAgFIABgJIAAgKIAAgNIgBgMQAAgEANgBQAHABAAgEIABgYIgBgXQAAgXAFAAQAFAAAKACIAPADIAdAEQAFAAAAADIgBAXIgCAZQAAAJAGAAIAVAAIAVgBQAEAAAAADIgBANIgBAOIAAANIAAAOQAAADgFAAIgNAAIgNgBIgPAAQgDAAAAAJIAAAOIAAAOQAAAQAEAHQAFAIAQAAIAOgCIAMgDQAFAAAAAFIgCASIgBARQAAAGgCABIgGAFQgZAOgfAAQg3AAAAgrg");
	this.shape_85.setTransform(847.775,125.35);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AAjBgQgFgBgBgHIABgcIABgcIgBgVIAAgVQAAgbgXAAQgHAAgKAHQgLAHAAAIIAABoQAAAGgGABIgcABQgXAAgHgBQgGgBAAgGIABguIAAgtQgBgwgHgcIgBgDQAAgDADgBIAhgFIAjgFQADAAAAANQABANADAAIAAAAIAAAAQgCAAAXgOQAWgNASAAQAYAAARALQASAOAAAYIAAA9IAAAmIAAAnQAAAEgEABIgdABQgZAAgGgBg");
	this.shape_86.setTransform(828.6,128.25);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAmQAAASgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEADAKARQAKASAAAFQAAACgDACQgYAagyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegEQAGgBAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_87.setTransform(807.625,128.2);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("Ag1BgQgGgBAAgGIAAguIAAguQAAgugIgdIgBgEQAAAAAAgBQABgBAAAAQAAgBABAAQAAAAABAAIAggFIAggGQACAAABAMQABAMADABIAAAAIAAAAQgCgBASgKQASgJASgBQALABAAAEIgBAQIgCAQIAAAPIABAQQAAAHgJAAIgKgBIgLAAQgQAAgGAFQgGAFAAAOIAAAaIABAaIAAARIABAQQAAAFgGAAIgcABIgegBg");
	this.shape_88.setTransform(790.125,128.25);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAmQAAASgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEADAKARQAKASAAAFQAAACgDACQgYAagyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegEQAGgBAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_89.setTransform(772.325,128.2);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgiCPQgHgBAAgHIAAhsQAAgGgIAAIgEABIgFAAQgFAAAAgDQgCgRAAggQAAgHAHgBIAOgBIgBgZQAAghANgQQAageA5AAQAEAAABACIAEAaIADALIACALQAAAFgOABQgQACgEAEQgGAHgBAVIABAMIARAAIASgBQAGAAAAAFIAAAbIAAAbQAAAEgFAAIghgBIABApIACAnIABAmQAAAFgFAAIggABQgWAAgHgBg");
	this.shape_90.setTransform(755.1,123.575);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgdCGQgEgBgBgCIgBgGIABgoIAAgpQAAg2gDghIgBgEQAAgEAFAAIARABIAQABIARgBIARgBQAFAAgBAEIAAAEQgEAmAAAxIABArIAAAqQAAAEgFABQgHABgXAAQgWAAgHgBgAgahLQgLgJAAgQQAAgPAMgKQALgJAOAAQAQAAALAJQAMAKAAAPQAAAignAAQgOAAgMgJg");
	this.shape_91.setTransform(742.55,124.475);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AhTBxQgYgbAAgqQAAgrAXgaQAZgeAqAAQAcAAARATIADADQACAAAAgFIgBgtIAAgtQAAgFADgBIAigCIAjgFQAEAAAAAEIgCANQgCAWgBAiQgBAmAAAwQAABRAEAiIAAAFQAAAAAAABQAAAAAAAAQgBABAAAAQgBAAgBAAQgGABgtAAQgLAAgBgEIgBgPIgBgDIgEACQgVAVgeAAQgpAAgZgdgAgaAPQgKAMAAAQQAAAQAKALQAJALAQAAQAOAAALgLQALgMgBgQQABgPgLgMQgLgMgOAAQgQAAgJAMg");
	this.shape_92.setTransform(725.05,123.875);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AguBUQgOgVgBgFQAAAAABAAQAAgBAAAAQAAAAABAAQAAgBABAAIAcgFQAQgFAAgNQAAgIgKgMIgSgUQgKgOAAgPQAAgeAegUQAagSAeAAQADAAAMAVQANAVAAADQAAACgDAEIgMgCQgLAAgIAFQgJAGAAALQAAAHAJAKQAQAQADAFQAKAOAAARQAAAKgEALQgEANgHAFQgOANgUAIQgUAJgRAAQgEAAgNgVg");
	this.shape_93.setTransform(696.2,128.025);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AhRBFQgXgcgBgnQABgsAYgcQAZgcAtAAQAdAAASAVIABABQACAAADgJQACgKACAAQAIAAAUAEQATAEAJADQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAIgBAEQgGAkAAAnIABAsIACAsQAAAIgGABQgZACgfAAQgEAAgBgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPALALQALAMAQAAQAPAAALgLQAKgLAAgQQAAgQgKgLQgLgLgPAAQgRAAgLALg");
	this.shape_94.setTransform(677.2,128.375);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgdCJQgFgBAAgFIAAgIIAAg0IABg0IAAhKQgBgrgEgfIgBgDQAAgFAGAAIBEAAQAFAAAAAEIAAAEQgGBUAABAIABBSIAAAPIABAPQAAAEgFACQgJABgWAAQgXAAgGgBg");
	this.shape_95.setTransform(660.4273,124.2);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("Ag1BgQgGgBAAgGIAAguIAAguQAAgugIgdIgBgEQAAAAAAgBQABgBAAAAQAAgBABAAQAAAAABAAIAggFIAggGQACAAABAMQABAMADABIAAAAIAAAAQgCgBASgKQASgJASgBQALABAAAEIgBAQIgCAQIAAAPIABAQQAAAHgJAAIgKgBIgLAAQgQAAgGAFQgGAFAAAOIAAAaIABAaIAAARIABAQQAAAFgGAAIgcABIgegBg");
	this.shape_96.setTransform(637.775,128.25);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("Ag/BLQgegbAAgvQAAgrAagdQAbgeAsAAQAlAAAbAcQAaAbAAAmQAAASgNADIgoAEIhEAHQADAMANAHQALAFAOAAQASAAARgKIAPgJQAEADAKARQAKASAAAFQAAACgDACQgYAagyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegEQAGgBAAgCQAAgNgIgJQgJgJgLAAQgMAAgIAKg");
	this.shape_97.setTransform(619.975,128.2);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AgxBIQgcgdAAgrQAAgqAdgdQAcgdApAAQAdAAAWAMQAGADAAADIgGAXIgHAYQgCAEgCAAIgMgDQgLgEgIAAQgRAAgKALQgKAKAAARQAAASALAKQALAKASAAQAJAAALgEIAKgFQADAAAFAZQAFAXAAAHQAAAIgYAFQgTAEgMAAQgqAAgcgdg");
	this.shape_98.setTransform(601.625,128.225);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AhGBIQgcgbAAgrQAAgsAbgcQAbgdAsAAQAsAAAbAcQAcAcAAArQAAAsgbAcQgcAcgsAAQgqAAgcgcgAgYgaQgJALAAAPQAAAPAJAMQAKAMAOAAQAQAAAKgMQAJgMAAgPQAAgPgKgLQgJgMgQAAQgOAAgKAMg");
	this.shape_99.setTransform(582.575,128.275);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AAjBgQgFgBgBgHIABgcIABgcIgBgVIAAgVQAAgbgXAAQgHAAgKAHQgLAHAAAIIAABoQAAAGgGABIgcABQgXAAgHgBQgGgBAAgGIAAguIAAgtQAAgwgHgcIgBgDQAAgDADgBIAhgFIAjgFQADAAAAANQABANADAAIAAAAIAAAAQgCAAAXgOQAWgNASAAQAYAAARALQASAOAAAYIAAA9IAAAmIAAAnQAAAEgEABIgdABQgZAAgGgBg");
	this.shape_100.setTransform(560.4,128.25);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AhGBIQgcgbAAgrQAAgsAbgcQAbgdAsAAQAsAAAbAcQAcAcAAArQAAAsgbAcQgcAcgsAAQgqAAgcgcgAgYgaQgJALAAAPQAAAPAJAMQAKAMAOAAQAQAAAKgMQAJgMAAgPQAAgPgKgLQgJgMgQAAQgOAAgKAMg");
	this.shape_101.setTransform(538.725,128.275);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgxBIQgcgdAAgrQAAgqAdgdQAcgdApAAQAdAAAWAMQAGADAAADIgGAXIgHAYQgCAEgCAAIgMgDQgLgEgIAAQgRAAgKALQgKAKAAARQAAASALAKQALAKASAAQAJAAALgEIAKgFQADAAAFAZQAFAXAAAHQAAAIgYAFQgTAEgMAAQgqAAgcgdg");
	this.shape_102.setTransform(519.975,128.225);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AhRBFQgYgcABgnQgBgsAZgcQAZgcAsAAQAeAAASAVIABABQACAAACgJQADgKADAAQAHAAAUAEQAUAEAIADQABAAAAABQABAAAAAAQAAABAAAAQAAABAAAAIAAAEQgGAkAAAnIACAsIACAsQAAAIgIABQgXACggAAQgEAAgBgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPAKALQALAMAQAAQAQAAAKgLQALgLAAgQQAAgQgLgLQgKgLgQAAQgQAAgLALg");
	this.shape_103.setTransform(948.6,81.475);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("Ag/BLQgegcAAguQAAgsAagcQAbgeAsAAQAlAAAbAcQAaAbAAAmQAAASgNADIgoAEIhEAGQADANANAHQALAFAOAAQASAAARgKIAPgJQAEACAKASQAKASAAAFQAAABgDADQgYAagyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegEQAGgBAAgDQAAgLgIgKQgJgJgLAAQgMAAgIAKg");
	this.shape_104.setTransform(917.325,81.3);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("ABdBhQgGgCAAgIIAAgbIABgbIgBgwQgBgXgVABQgJgBgJAIQgJAIgBAJQgBAIAAAnIABAcIABAcQAAAHgHAAIg5AAQgGgBAAgHIAAgcIABgcIAAgWIgBgUQABgcgWAAQgJgBgJAHQgMAHAAAIIABA1IAAA1IgBAFIgGACIgcABIgcgBIgFgCQgBgBAAgEIAAgvIAAgvQAAgggFgoIAAgDQAAgDADgCIAQgDIARgBIAPgEQALgDAFAAQAEAAAAAOQAAANABAAIAFgCQASgOAKgFQAPgHASgBQARAAANAJQARAJAEAQQAKgPATgJQASgKARAAQAZAAARAMQASAOAAAZIgBAfIAAAfIAAAlIABAlQAAAGgFABIgeABQgXAAgGgBg");
	this.shape_105.setTransform(889.4,81.3);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("Ag1BgQgGgBAAgGIAAguIAAguQAAgugIgdIgBgEQAAAAAAgBQABAAAAgBQAAAAABgBQAAAAABAAIAggFIAggGQACAAABANQABALADABIAAAAIAAAAQgCgBASgKQASgKASAAQALABAAAEIgBAQIgCAQIAAAPIABAQQAAAHgJAAIgKgBIgLAAQgQAAgGAFQgGAFAAAOIAAAaIABAaIAAARIABAQQAAAFgGAAIgcABIgegBg");
	this.shape_106.setTransform(864.925,81.35);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AhRBFQgYgcAAgnQABgsAYgcQAZgcAtAAQAdAAASAVIABABQACAAADgJQACgKACAAQAIAAAUAEQATAEAJADQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAIgBAEQgGAkAAAnIABAsIACAsQAAAIgHABQgXACggAAQgDAAgCgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPALALQAKAMARAAQAPAAALgLQAKgLAAgQQAAgQgKgLQgLgLgPAAQgSAAgKALg");
	this.shape_107.setTransform(844.95,81.475);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AAjCHQgFgBAAgHIAAgbIABgcIgBgWIAAgWQAAgagYAAQgGAAgKAGQgLAIAAAHIAABpQAAAHgGABIgcAAQgXAAgHgBQgGgBAAgFIAAguIAAguQAAgwgHgcIgBgCQAAgEAEgBIAggEIAjgGQACAAABANQABANADAAIAAAAIAAAAQgCAAAXgNQAWgOASAAQAYAAARAMQASANAAAYIAAA+IAAAmIAAAmQAAAFgEABIgdAAQgZAAgGgBgAAGhSQgKgIgHAAQgIAAgHAGQgHAHgDAAQgFgCgMgLQgLgLAAgFQACgIASgKQASgLAJAAQAJAAAMAHQAOAHAHAAQAHAAAKgHQAJgGACAAQADAAALANQALAOAAAEIAAABQgZAcgcAAQgHAAgMgIg");
	this.shape_108.setTransform(821.95,77.425);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AhRBFQgXgcgBgnQAAgsAZgcQAZgcAtAAQAdAAASAVIABABQACAAADgJQACgKACAAQAIAAAUAEQATAEAJADQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAIgBAEQgGAkAAAnIABAsIACAsQAAAIgGABQgZACgfAAQgDAAgCgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPALALQALAMAQAAQAPAAALgLQAKgLAAgQQAAgQgKgLQgLgLgPAAQgRAAgLALg");
	this.shape_109.setTransform(798.8,81.475);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AheB+QgGgCAAgGIAAiVQAAgugHgfIAAgDQAAgBAAgBQAAAAABgBQAAAAAAAAQABgBABAAQAHgDAWgDQAUgEAJAAQAJAAAAALQABAJACABIAAAAIAAAAQgBgBASgKQARgLAPAAQArAAAaAcQAYAbAAArQAAApgYAcQgaAcgpAAQgPAAgQgHIgQgIQgCAAAAAGIABAeIABAeQgBAGgGAAIgoABQgOAAgDgBgAgXg3QgJALAAAQQAAARAJAKQAJALAPAAQAjAAgBgmQAAgQgJgLQgKgNgQAAQgOAAgJANg");
	this.shape_110.setTransform(775.7,84.425);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("ABdBhQgGgCAAgIIAAgbIABgbIgBgwQgBgXgVABQgJgBgJAIQgJAIgBAJQgBAIAAAnIAAAcIACAcQgBAHgFAAIg7AAQgFgBAAgHIABgcIAAgcIAAgWIAAgUQgBgcgVAAQgJgBgKAHQgLAHAAAIIABA1IAAA1IgBAFIgGACIgcABIgcgBIgFgCQgCgBAAgEIABgvIAAgvQAAgggFgoIAAgDQAAgDACgCIARgDIASgBIAPgEQAJgDAGAAQAEAAAAAOQAAANABAAIAFgCQARgOALgFQAPgHARgBQATAAANAJQAPAJAFAQQAKgPASgJQATgKARAAQAaAAAQAMQASAOAAAZIAAAfIgBAfIABAlIAAAlQAAAGgGABIgdABQgXAAgGgBg");
	this.shape_111.setTransform(745.55,81.3);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AhGBIQgcgbAAgrQAAgsAbgcQAbgdAsAAQAsAAAbAcQAcAcAAArQAAAsgbAcQgcAcgsAAQgqAAgcgcgAgYgaQgJALAAAPQAAAPAJAMQAKAMAOAAQAQAAAKgMQAJgMAAgPQAAgPgKgLQgJgMgQAAQgOAAgKAMg");
	this.shape_112.setTransform(717.825,81.375);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("AgxBIQgcgdAAgrQAAgqAdgdQAcgdApAAQAdAAAWAMQAGADAAADIgGAXIgHAYQgCAEgCAAIgMgDQgLgEgIAAQgRAAgKALQgKAKAAARQAAASALAKQALAKASAAQAJAAALgEIAKgFQADAAAFAZQAFAXAAAHQAAAIgYAFQgTAEgMAAQgqAAgcgdg");
	this.shape_113.setTransform(699.075,81.325);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AhRBFQgXgcgBgnQABgsAYgcQAZgcAtAAQAdAAASAVIABABQACAAADgJQACgKACAAQAIAAAUAEQATAEAJADQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAIgBAEQgGAkAAAnIABAsIACAsQAAAIgGABQgZACgfAAQgDAAgCgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPALALQALAMAQAAQAPAAALgLQAKgLAAgQQAAgQgKgLQgLgLgPAAQgSAAgKALg");
	this.shape_114.setTransform(678.55,81.475);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AhRBFQgXgcAAgnQAAgsAYgcQAZgcAtAAQAdAAASAVIABABQACAAACgJQACgKAEAAQAHAAAUAEQATAEAJADQABAAAAABQABAAAAAAQAAABAAAAQAAABAAAAIAAAEQgGAkAAAnIABAsIADAsQgBAIgGABQgYACggAAQgDAAgCgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPAKALQAMAMAPAAQAQAAAKgLQALgLAAgQQAAgQgLgLQgKgLgQAAQgRAAgKALg");
	this.shape_115.setTransform(645.1,81.475);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#000000").s().p("AAECPIgOAAIgPAAIgOACQgGAAAAgLIABgoIAAgnQAAgegFg/IAAgDQgBgFAGAAIARABIARADIAQgDIASgBQAGAAAAAFQAAAPgEAfQgDAiAAAQIABApIAAApQAAAHgFABIgPgCgAg2hAQgEABABgFIAAgFIABgEIgBgIIgBgHQAAgDAEgBQAJgEAcgQIAjgZIAEgDIADADIAPANIAQAKQABABAAAAQABAAAAABQABAAAAABQAAAAAAABQAAABgDADQgRAQgiAPQgiAOgXABg");
	this.shape_116.setTransform(629.35,76.5);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("Ag1BgQgGgBAAgGIAAguIAAguQAAgugIgdIgBgEQAAAAAAgBQABAAAAgBQAAAAABgBQAAAAABAAIAggFIAggGQACAAABANQABALACABIABAAIgBAAQgBgBASgKQASgKASAAQALABAAAEIgBAQIgCAQIAAAPIABAQQAAAHgJAAIgKgBIgLAAQgQAAgGAFQgGAFAAAOIAAAaIABAaIAAARIABAQQAAAFgGAAIgcABIgegBg");
	this.shape_117.setTransform(615.375,81.35);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#000000").s().p("AhRBFQgXgcgBgnQAAgsAZgcQAZgcAtAAQAdAAASAVIABABQACAAADgJQABgKADAAQAIAAAUAEQATAEAJADQABAAAAABQABAAAAAAQAAABAAAAQABABAAAAIgBAEQgGAkAAAnIABAsIACAsQAAAIgGABQgZACgfAAQgDAAgCgMQgBgLgCAAIgEADQgWAWgYAAQgmAAgZgegAgcgcQgKAKAAARQAAAPALALQALAMAQAAQAPAAALgLQAKgLAAgQQAAgQgKgLQgLgLgPAAQgRAAgLALg");
	this.shape_118.setTransform(595.4,81.475);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#000000").s().p("AgyBWIABgoIABgmQAAgIgKAAIgDAAIgCAAQgIAAAAgFIABgKIAAgJIAAgNIgBgMQAAgEANgBQAHAAAAgDIABgYIgBgYQAAgWAFAAQAFgBAKADIAPADIAdAEQAFAAAAADIgBAYIgCAYQAAAJAGAAIAVAAIAVgBQAEAAAAADIgBANIgBAOIAAANIAAAOQAAADgFAAIgNAAIgNgBIgPAAQgDAAAAAJIAAAOIAAAOQAAAQAEAHQAFAIAQAAIAOgCIAMgDQAFABAAAEIgCASIgBARQAAAGgCABIgGAFQgZANgfAAQg3AAAAgqg");
	this.shape_119.setTransform(576.475,78.45);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#000000").s().p("AgvBUQgNgVAAgFQAAAAAAAAQAAgBAAAAQAAAAABAAQAAgBABAAIAcgFQAQgFABgNQgBgIgJgMIgTgUQgKgOAAgPQAAgeAegUQAZgSAeAAQAEAAAMAVQAMAVAAADQAAACgCAEIgLgCQgMAAgIAFQgJAGAAALQAAAHAKAKQAPAQAEAFQAJAOABARQAAAKgFALQgEANgHAFQgPANgTAIQgUAJgRAAQgEAAgOgVg");
	this.shape_120.setTransform(561.6,81.125);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#000000").s().p("AAiBdQgEgBgBgEIgBgMQgBgIgCgBIAAAAIAAAAQACABgVANQgWANgSAAQg0AAgJgvQgFgWAAgoQAAgsAHgaQADgIAGAAIAbAAIAbAAQAGABAAAFIAAADQgEAbAAAbQAAAiACAMQADAWAWAAQAIgBAKgHQAKgHABgJIAAhhQAAgGABgBQABgCAGgBIAdAAIAdABQAFAAABADIABAEIgCAsIgBAqIABArIABApQAAAFgFACQgHACgYAAIgegBg");
	this.shape_121.setTransform(543.025,81.75);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#000000").s().p("AguB2QgkgGAAgJQAAgDAIgkQABgEADAAIACAAQAfAPAZAAQANAAAOgHQARgIAAgNIAAgOQgUATgeAAQglABgYgbQgXgZAAglQAAglAWgZQAXgZAlAAQAdAAAPAVQADAFACgBQABAAAAgGQAAgQAEAAIAiADIAfAEQAEABAAADIgBApIgBAoIAAAYIAAAXQAAA4gXAYQgYAZg4AAQgQAAgcgGgAgWg6QgKAKAAAOQAAAPAKAKQAKAJANAAQAOAAAJgJQAKgLAAgOQAAgOgKgKQgJgLgOAAQgOAAgJALg");
	this.shape_122.setTransform(519.475,83.95);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#000000").s().p("Ag/BLQgegcAAguQAAgsAagcQAbgeAsAAQAlAAAbAcQAaAbAAAmQAAASgNADIgoAEIhEAGQADANANAHQALAFAOAAQASAAARgKIAPgJQAEACAKASQAKASAAAFQAAABgDADQgYAagyAAQguAAgcgbgAgXgpQgHAKAAANQAAAFAFAAQAOAAAegEQAGgBAAgDQAAgLgIgKQgJgJgLAAQgMAAgIAKg");
	this.shape_123.setTransform(488.625,81.3);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#000000").s().p("AghCKQgGgCAAgEIAChGIAChEIgChEQgnAEgXAAQAAAAgBAAQgBAAAAAAQgBgBAAAAQAAAAAAgBIADgPIAEgQIABgTQABgOADAAIADAAQAgAEA8AAQASAAAvgEIAagCIAFABQAAAAAAAAQAAAAAAABQAAAAAAABQABABAAAAIgBAPIAAAPIABAOIABAOQAAAEgEAAIg7gDIgBBFIACBEIABBGQAAABAAABQAAAAAAABQAAAAAAABQgBAAAAAAIgGACQgLABgXAAQgYAAgKgBg");
	this.shape_124.setTransform(467.9,77.2);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#000000").s().p("Ag1B5QgZgVAAgjQAAgxAngVQAdgRADgRIABgKQACgEAEAAQAUAAAIgCIADAAQAHAAAAATQAAAQgTAYQgTAYAAARQAAAZAbAAQALAAARgHIAQgGQAIAAAAAyIAAAIQgDANgeAHQgWAFgUAAQgiAAgXgTgABHA5IAAAAIAAAAgAgPhMQgLgLAAgPQAAgPALgLQAKgLAPAAQAPAAAKALQALALAAAPQAAAPgKALQgLAKgPAAQgPAAgKgKg");
	this.shape_125.setTransform(449.05,77.475);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("EArHAPFQjMh9gjAAMhS9AAAQhWAAg8hTQg8hTAAh1IAA1rQAAh0A8hTQA8hTBWAAMBS9AAAQBWAAA8BTQA8BTABB0IAAVrQgBAtB0DWQCLEFAQAkQiEhThqhBg");
	this.shape_126.setTransform(708.6,157.875);

	this.botoniniciar1 = new lib.BotonIniciar();
	this.botoniniciar1.name = "botoniniciar1";
	this.botoniniciar1.setTransform(698.6,668.7,1.3062,1.3062);
	new cjs.ButtonHelper(this.botoniniciar1, 0, 1, 2, false, new lib.BotonIniciar(), 3);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#000000").s().p("AghAiQgNgOAAgUQAAgTANgOQAPgOASAAQATAAAPAOQANAOAAATQAAAUgNAOQgPAOgTAAQgSAAgPgOg");
	this.shape_127.setTransform(670.35,185.625);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#000000").s().p("AghAiQgNgOAAgUQAAgTANgOQAOgOATAAQAUAAAOAOQANAOAAATQAAAUgNAOQgOAOgUAAQgTAAgOgOg");
	this.shape_128.setTransform(658.85,185.625);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("AggAiQgOgOAAgUQAAgTAOgOQANgOATAAQATAAAPAOQANAOAAATQAAAUgNAOQgPAOgTAAQgTAAgNgOg");
	this.shape_129.setTransform(647.35,185.625);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#000000").s().p("AgeCMQgFgBAAgFIAAgIIAAg2IAAg1IABhLQgBgsgEghIgBgDQAAgFAFAAIBHAAQAFAAAAAFIgBADQgFBXAABBIABBVIAAAPIABAQQAAAEgFABQgJABgXABQgYgBgGgBg");
	this.shape_130.setTransform(636.125,176);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#000000").s().p("AgdCJQgFgBgBgBIgBgGIABgqIAAgqQAAg3gDgiIgBgEQAAgEAFAAIARABIARABIARgBIARgBQAFAAABAEIgBAEQgEAngBAyIABAsIABArQAAAEgFABQgHABgYAAQgXAAgGgBgAgbhMQgMgKABgQQAAgQAMgKQAMgJAOAAQAQAAALAJQANAKAAAQQAAAigoAAQgPAAgMgIg");
	this.shape_131.setTransform(601,176.275);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#000000").s().p("AAkBiQgGAAAAgIIAAgcIABgdIgBgWIAAgVQAAgcgXABQgIgBgJAIQgMAHAAAHIAABrQAAAHgGABIgdAAQgXAAgHgBQgHgBAAgFIABgvIAAguQAAgygIgdIAAgCQAAgEADgBIAigEIAkgHQACAAABAOQABANACAAIAAAAIAAAAQgCAAAYgNQAWgOASgBQAaABARALQASAOAAAZIAAA/IABAnIAAAmQAAAGgFABIgeAAQgZAAgGgBg");
	this.shape_132.setTransform(583.5,180.15);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#000000").s().p("AhTBHQgYgdAAgoQAAgtAZgcQAageAtAAQAfAAASAWIABABQACAAACgJQADgKADAAQAHAAAVAEQAUAEAIADQABABABAAQAAAAABABQAAAAAAAAQAAABAAAAIAAAEQgHAlAAAoIACAtIACAuQAAAIgHAAQgZACggAAQgEAAgBgLQgBgMgCAAIgEADQgXAXgYAAQgnAAgagfgAgcgdQgLALAAARQAAAQALALQALAMAQAAQAQAAALgLQALgLAAgRQAAgRgLgLQgKgLgRAAQgRAAgKALg");
	this.shape_133.setTransform(758.575,132.225);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#000000").s().p("Ag0BXIABgnIABgoQAAgIgKAAIgCAAIgDAAQgHAAAAgFIAAgKIABgJIgBgOIAAgMQgBgFANAAQAHAAABgEQACgHgBgRIgBgZQAAgWAFAAIAPABIAQAEIAdAEQAGAAgBADIAAAYIgCAZQAAAJAGABIAVgBIAVgBQAFAAAAADIgBAOIgBAOIAAAOIAAAOQAAADgFAAIgOAAIgNAAIgQAAQgCAAAAAJIAAANIAAAPQAAAQADAHQAGAIAQAAIAOgCIANgCQAEAAAAAEIgBASIgBASQgBAGgBACIgGAFQgaAOgfgBQg6AAAAgsg");
	this.shape_134.setTransform(699.7,129.15);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#000000").s().p("AAkBiQgGAAAAgIIABgcIAAgdIAAgWIAAgVQAAgbgYgBQgIAAgJAIQgMAHAAAHIAABrQAAAHgGABIgcAAQgYAAgHgBQgHgBABgFIAAgvIAAgvQAAgxgIgdIAAgDQAAgDADgBIAigFIAkgGQABAAABAOQACANACAAIAAAAIAAAAQgCAAAYgNQAXgOARgBQAaABAQAMQAUAOgBAYIAAA/IABAnIAAAnQAAAFgFABIgeAAQgZAAgGgBg");
	this.shape_135.setTransform(680.1,132.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#000000").s().p("AgYBeQgEgBgDgCQgMgOgXgfQgXgkgFgLQgFgOAAgbIAAgYIAAgYQAAgFAHAAIAfAAIAfABQAFAAAAAHIgBARIgBARQAAAUABANQABAHALASQALAUAEAAQAFAAALgUQALgRABgGQABgOAAgVIgBgRIgBgRQAAgHAEAAIAPAAIAOAAIAOgBIAPAAQAFAAABAFQAEALAAAkQAAAigCAGQgFANgXAjQgUAdgOAQQgFAGgbAAQgVAAgHgCg");
	this.shape_136.setTransform(637.125,132.5);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#000000").s().p("AhTBHQgYgdAAgoQAAgtAZgcQAageAtAAQAfAAASAWIABABQACAAACgJQADgKADAAQAHAAAVAEQAUAEAIADQABABABAAQAAAAABABQAAAAAAAAQAAABAAAAIAAAEQgHAlAAAoIACAtIACAuQAAAIgHAAQgZACggAAQgEAAgBgLQgBgMgCAAIgEADQgXAXgYAAQgnAAgagfgAgcgdQgLALAAARQAAAQALALQALAMAQAAQAQAAALgLQALgLAAgRQAAgRgLgLQgKgLgRAAQgRAAgKALg");
	this.shape_137.setTransform(613.775,132.225);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#000000").s().p("AhTBHQgYgdAAgoQAAgtAZgcQAageAtAAQAfAAASAWIABABQACAAACgJQADgKADAAQAHAAAVAEQAUAEAIADQABABABAAQAAAAABABQAAAAAAAAQAAABAAAAIAAAEQgHAlAAAoIACAtIACAuQAAAIgHAAQgZACggAAQgEAAgBgLQgBgMgCAAIgEADQgXAXgYAAQgnAAgagfgAgcgdQgLALAAARQAAAQALALQALAMAQAAQAQAAALgLQALgLAAgRQAAgRgLgLQgKgLgRAAQgRAAgKALg");
	this.shape_138.setTransform(579.475,132.225);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#000000").s().p("AAkBiQgGAAAAgIIAAgcIABgdIgBgWIAAgVQAAgbgYgBQgGAAgLAIQgLAHAAAHIAABrQAAAHgGABIgdAAQgXAAgHgBQgHgBAAgFIABgvIAAgvQAAgxgIgdIAAgDQAAgDADgBIAhgFIAkgGQADAAABAOQABANACAAIAAAAIAAAAQgCAAAYgNQAWgOASgBQAaABARAMQASAOAAAYIAAA/IABAnIAAAnQAAAFgGABIgdAAQgZAAgGgBg");
	this.shape_139.setTransform(555.95,132.1);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#000000").s().p("AhTB4QgYgdAAgoQAAgvAZgbQAagdAtAAQAfAAASAWIABABQACAAACgKQADgJADAAQAHAAAVAEQAUAEAIADQABAAABAAQAAABAAAAQABAAAAABQAAAAAAABIAAAEQgHAjAAApIACAtIACAuQAAAIgHABQgZACggAAQgEAAgBgMQgBgLgCgBIgEAEQgXAWgYAAQgnAAgagegAgcATQgLALAAARQAAAQALAMQALALAQAAQAQAAALgLQALgLAAgRQAAgRgLgLQgKgLgRAAQgRAAgKALgAglhIIABgFIAAgFIgBgHIAAgIQAAgDAEgBQAKgEAbgQIAlgaIAEgCIADACIAPANIAQAKQADADAAABQAAACgCADQgSAQgjAPQgiAPgYABIgCAAIgBAAQgBAAAAAAQgBAAAAgBQAAAAgBgBQAAgBAAgBg");
	this.shape_140.setTransform(498.075,127.375);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#000000").s().p("Ag2BiQgHgBAAgFIABgwIAAgvQAAgvgJgfIAAgDQAAgDADgBIAggEIAhgGQACAAABAMQABAMADABIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCgBASgKQATgKASAAQALAAAAAFIgBAQIgBAQIAAAQIAAAQQAAAHgIAAIgLAAIgLgBQgRAAgGAGQgGAFAAAPIABAaIAAAaIABARIAAARQAAAFgGABIgdAAIgegBg");
	this.shape_141.setTransform(478.925,132.125);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#000000").s().p("AhBBNQgegcAAgwQAAgtAbgdQAbgfAtAAQAmAAAbAcQAbAcAAAnQAAATgNADIgpAEQgYADguAEQADANAOAGQALAGAPAAQARAAATgKIAPgJQAEACAKASQAKATAAAFQAAABgDADQgZAbgzAAQgvAAgdgcgAgYgqQgHAKAAANQAAAGAFAAQAPAAAegFQAHgBAAgCQAAgNgJgJQgJgJgLAAQgMAAgJAKg");
	this.shape_142.setTransform(460.675,132.075);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#000000").s().p("Ag5B6QgPgcAAgHQAAAAAAgBQAAAAABgBQAAAAABAAQAAAAABgBQAdgGAJgEQAVgLAAgVQAAgNgNgQIgagcQgOgWAAgYQAAglAigYQAcgUAngHIADAAQADAAACAFQAFAOATAnIAAACQAAABAAABQAAAAAAABQgBAAAAAAQgBAAgBAAIgGgBIgFAAQgOAAgLAHQgOAHAAAOQAAAMAPASIAaAgQAPAWAAAXQAAAogiAdQgeAagqAGIgDABQgEAAgRgcg");
	this.shape_143.setTransform(441.45,128);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#000000").s().p("AgaCEQgKgLAAgRQAAgRAKgKQAKgMAQABQAQgBALAMQALAKAAARQAAARgLALQgKALgRAAQgQAAgKgLgAgSApQgShAAAgIIAAgZIABgZIAAgbIgBgbQAAgHAEAAIAQABIAQABIARgBIAQgBQAFAAAAAxQgBAkgGAgIgQBBQgBAHgOAAQgQAAgCgGg");
	this.shape_144.setTransform(730.55,80.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#000000").s().p("AgbCEQgJgLgBgRQABgRAJgKQALgMAQABQAQgBALAMQALAKAAARQAAARgLALQgKALgRAAQgQAAgLgLgAgSApQgShAgBgIIABgZIABgZIgBgbIgBgbQAAgHAFAAIAQABIAQABIARgBIAQgBQAFAAAAAxQAAAkgHAgIgQBBQgBAHgOAAQgQAAgCgGg");
	this.shape_145.setTransform(719.1,80.1);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#000000").s().p("AgbCEQgKgLAAgRQAAgRAKgKQALgMAQABQAQgBALAMQALAKgBARQABARgLALQgKALgRAAQgQAAgLgLgAgSApQgThAAAgIIABgZIABgZIgBgbIgBgbQAAgHAFAAIAQABIAQABIARgBIARgBQADAAAAAxQABAkgHAgIgQBBQgCAHgNAAQgQAAgCgGg");
	this.shape_146.setTransform(707.65,80.1);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#000000").s().p("AgzBXIABgnIABgoQAAgIgKAAIgEAAIgCAAQgIAAAAgFIABgKIAAgJIAAgOIgBgMQAAgEAOgBQAGAAABgEQABgHAAgRIgBgYQAAgYAEAAIAQACIAQAEIAdADQAFABABADIgCAYIgBAZQAAAKAGAAIAVgBIAWgBQAEAAAAADIgBAOIgBAOIAAAOIAAAOQAAADgGAAIgNAAIgOAAIgOAAQgEAAAAAJIAAANIABAPQAAAQAEAHQAFAJAQgBIAOgCIANgCQAFAAAAAEIgCASIgCASQAAAGgBACIgHAFQgZAOgggBQg4ABAAgtg");
	this.shape_147.setTransform(672.3,81.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#000000").s().p("AgwBXQgOgXAAgEQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAIAdgGQARgFAAgNQAAgJgKgLIgTgVQgKgOAAgQQAAgeAegWQAagSAfAAQAEAAAMAWQANAVAAADQAAACgDAEIgLgBQgMgBgIAGQgKAGAAALQAAAHAKAKQAQARADAFQALAOAAASQAAAKgEAMQgFANgHAFQgPANgUAIQgUAKgSAAQgEAAgOgVg");
	this.shape_148.setTransform(657.075,83.85);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#000000").s().p("AhBBNQgegcAAgwQAAgtAbgdQAbgfAtAAQAmAAAbAcQAbAcAAAnQAAATgNADIgpAEQgYADguAEQADANAOAGQALAGAPAAQARAAATgKIAPgJQAEACAKASQAKATAAAFQAAABgDADQgZAbgzAAQgvAAgdgcgAgYgqQgHAKAAANQAAAGAFAAQAPAAAegFQAHgBAAgCQAAgNgJgJQgJgJgLAAQgMAAgJAKg");
	this.shape_149.setTransform(639.825,84.025);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#000000").s().p("AAjBfQgEgBgBgEIgBgMQgBgIgCgBIAAAAIAAAAQACABgWANQgWANgTAAQg1AAgKgwQgEgWAAgpQAAguAHgaQACgIAGAAIAcAAIAcAAQAHAAAAAFIgBAEQgEAcAAAcQAAAiACAMQAEAWAWAAQAIAAALgHQAKgIAAgJIABhjQAAgHABgBQABgCAGAAIAdAAIAeAAQAGAAABADIAAAFIgBAtIgCArIABArIABArQAAAGgFABQgHACgZAAIgegBg");
	this.shape_150.setTransform(617.525,84.475);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#000000").s().p("AhhCBQgGgCAAgFIABiZQAAgwgHggIgBgDQAAgBAAAAQABgBAAAAQAAgBABAAQAAgBABAAQAHgDAWgDQAWgDAJgBQAIAAABALQABAKACAAIAAAAIAAAAQgCAAATgLQASgLAQAAQArAAAaAdQAaAcAAArQAAAqgaAdQgaAdgqAAQgPAAgRgIQgSgHACAAIAAAAIAAAAQgDAAAAAGIABAfIABAeQAAAHgGAAIgpAAQgOAAgEgBgAgYg5QgJAMAAAQQAAARAJALQAJAMAQAAQAjAAAAgoQAAgPgJgNQgLgMgQAAQgPAAgJAMg");
	this.shape_151.setTransform(593.575,87.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#000000").s().p("AAjBfQgEgBgBgEIgBgMQgBgIgCgBIAAAAIAAAAQACABgWANQgWANgTAAQg1AAgKgwQgEgWAAgpQAAguAHgaQACgIAGAAIAcAAIAcAAQAHAAAAAFIgBAEQgEAcAAAcQAAAiACAMQAEAWAWAAQAIAAALgHQAKgIAAgJIABhjQAAgHABgBQABgCAGAAIAdAAIAeAAQAGAAABADIAAAFIgBAtIgCArIABArIABArQAAAGgFABQgHACgZAAIgegBg");
	this.shape_152.setTransform(568.975,84.475);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#000000").s().p("AgwBXQgOgXAAgEQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAIAdgGQARgFAAgNQAAgJgKgLIgTgVQgKgOAAgQQAAgeAegWQAagSAfAAQAEAAAMAWQANAVAAADQAAACgDAEIgLgBQgMgBgIAGQgKAGAAALQAAAHAKAKQAQARADAFQALAOAAASQAAAKgEAMQgFANgHAFQgPANgUAIQgUAKgSAAQgEAAgOgVg");
	this.shape_153.setTransform(549.525,83.85);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#000000").s().p("Ag2BiQgHgBAAgFIABgwIAAgvQAAgvgJgfIAAgDQAAAAAAgBQAAgBABAAQAAgBAAAAQABAAABgBIAggEIAhgGQACAAABAMQABAMADABIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAQgCgBASgKQATgKASAAQALAAAAAFIgBAQIgBAQIAAAQIAAAQQAAAHgIAAIgLAAIgLgBQgRAAgGAGQgGAFAAAPIABAaIAAAaIABARIAAARQAAAFgGABIgdAAIgegBg");
	this.shape_154.setTransform(524.675,84.075);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#000000").s().p("AhHBKQgdgcAAgsQAAgtAbgdQAbgdAuAAQAtAAAcAcQAcAdAAAsQAAAtgcAdQgbAcguAAQgrAAgcgcgAgZgbQgKAMABAPQgBAQAKAMQAKAMAPAAQAQAAAKgMQAKgMAAgQQAAgPgKgMQgKgMgQAAQgPAAgKAMg");
	this.shape_155.setTransform(505.75,84.075);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#000000").s().p("AhJCNIglgBQgGAAAAgGIABhDIABhDQAAg9gGhGIAAgDQAAgDAGgBQAQgCA1AAIA7ABQAwABAdAdQAeAdAAAvQAAAvgaAeQgbAggwAAIgXgBIgYgBQgJAAAAAIIACAbIACAcQAAAEgEAAIglAAgAglhJQgCADAAArIABATIAAARQAAAEAkAAQArAAAAgrQAAgugtAAQggAAgBADg");
	this.shape_156.setTransform(481.9232,79.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},51).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.botoncontinuar}]},4).to({state:[{t:this.shape_51},{t:this.shape_50},{t:this.shape_49,p:{x:558.15}},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45,p:{x:639.975,y:84.475}},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39,p:{x:551.175}},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35,p:{x:641.125}},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29,p:{x:471.925}},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26,p:{x:543.025}},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23,p:{x:614.825}},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17,p:{x:736.075,y:180.175}},{t:this.botoncontinuar}]},1).to({state:[{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.botoncontinuar}]},1).to({state:[{t:this.shape_51},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_49,p:{x:690.9}},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_45,p:{x:532.675,y:132.525}},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_35,p:{x:658.575}},{t:this.shape_135},{t:this.shape_134},{t:this.shape_39,p:{x:719.425}},{t:this.shape_17,p:{x:739.425,y:132.125}},{t:this.shape_133},{t:this.shape_29,p:{x:539.425}},{t:this.shape_23,p:{x:561.975}},{t:this.shape_132},{t:this.shape_131},{t:this.shape_26,p:{x:618.275}},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.botoniniciar1}]},1).to({state:[]},1).wait(10));

	// Chica
	this.instance_1 = new lib.Interpolación1("synched",0);
	this.instance_1.setTransform(1550.3,782.55,0.7221,0.7221);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).to({x:1454.7,y:740.1},2).to({x:1236.75,y:667.45},2).to({x:1129.65,y:577.95},2).to({x:1083.75},1).to({startPosition:0},1).to({startPosition:0},1).to({startPosition:0},1).to({startPosition:0},1).to({startPosition:0},1).to({startPosition:0},1).to({startPosition:0},1).to({x:1161.6},1).to({x:1349.7,y:568.7},1).to({x:1570.3,y:639.55},1).to({_off:true},1).wait(7));

	// Circulo
	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("EhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMDlmAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBg");
	this.shape_157.setTransform(679.7,365.05);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#FFFFFF").s().p("EhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMDlmAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgAiJjpQgyAzAABIQAABIAyAyQA0AzBHAAQBHAAA0gzQAzgygBhIQABhIgzgzQg0gzhHAAQhHAAg0Azg");
	this.shape_158.setTransform(679.7,365.05);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("EhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMDlmAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgAkal6QiBCBAAC2QAAC1CBCBQCBCAC1ABQC2gBCAiAQCCiBAAi1QAAi2iCiBQiAiBi2AAQi1AAiBCBg");
	this.shape_159.setTransform(679.7,365.05);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("EhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMDlmAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgAnboiQjoDoAAFGQAAFIDoDoQDoDoFHAAQFIAADojoQDojoAAlIQAAlGjojoQjojolIAAQlHAAjoDog");
	this.shape_160.setTransform(679.7,365.05);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("EhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMDlmAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgAp2rvQleFfABHtQgBHuFeFeQFeFeHtAAQHvAAFdleQFeleAAnuQAAntlelfQldldnvAAQntAAleFdg");
	this.shape_161.setTransform(679.7,365.05);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("EhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMDlmAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgAvRxJQnYHZAAKbQAAKdHYHZQHZHZKcABQKegBHZnZQHYnZAAqdQAAqbnYnZQnZnZqegBQqcABnZHZg");
	this.shape_162.setTransform(679.7,365.05);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("EhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMDlmAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgA2J5lQqkKkAAO8QAAO7KkKkQKkKkO7AAQO8AAKkqkQKkqkAAu7QAAu8qkqkQqkqku8AAQu7AAqkKkg");
	this.shape_163.setTransform(679.7,365.05);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFFFFF").s().p("EhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMDlmAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgEghggfUQu7NYAAS5QAAS6O7NYQO8NXVHAAQVHAAO7tXQO8tYAAy6QAAy5u8tYQu7tX1HAAQ1HAAu8NXg");
	this.shape_164.setTransform(679.7,365.05);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("EhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMDlmAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgEgqkgiSQxmPoAAWGQAAWIRmPoQRoPpY6AAQY5AARnvpQRovogB2IQAB2GxovoQxnvp45AAQ46AAxoPpg");
	this.shape_165.setTransform(679.7,365.05);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("EAcSBBXQM8k+KxpuQWCz7AA8KQAA8I2Cz7Q07y69Jg+MBw4gABQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgEhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMBufAABQ9JA+07S6Q2CT7AAcIQAAcKWCT7QKxJuM8E+g");
	this.shape_166.setTransform(679.7,365.05);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("EAuKBBXQH/kcHKmMQZf2CAA/KQAA/J5f2CQp1ogrZlOMBKuAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgEhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMBKRAAAQrZFOp1IgQ5fWCAAfJQAAfKZfWCQHKGMH/Ecg");
	this.shape_167.setTransform(679.7,365.05);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#FFFFFF").s().p("EA5kBBXQGnjsGFkrQdT2gAA/yQAA/z9T2eQrEogszlTMBEaAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgEhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMBDkAAAQszFTrEIgQ9TWeABfzQgBfydTWgQGFErGnDsg");
	this.shape_168.setTransform(679.7,365.05);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("EBFwBBXQCphwCjh6UAgFgX9AAAgh4UAAAgh4ggFgX8Qo2mop3kyMA6kAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgEhyzBBXQiLABhjhkQhjhiAAiMMAAAh4MQAAiLBjhiQBjhkCLABMA1mAAAQp3Eyo3GoUggEAX8AAAAh4UAAAAh4AgEAX9QCkB6CoBwg");
	this.shape_169.setTransform(679.7,365.05);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FFFFFF").s().p("EBRmBBXIA2gmUAjRgZiAABgkIUgABgkIgjRgZiQlEjqlXjJMAqyAAAQCMgBBjBkQBjBiAACLMAAAB4MQAACMhjBiQhjBkiMgBgEhyzBBXQiLABhjhkQhjhiAAiMMAAAgkaQHYXKYxR7IA2AmgEh4Eg8GQAAiLBjhiQBjhkCLABMAlTAAAQlXDJlEDqQ4xR7nYXKg");
	this.shape_170.setTransform(679.7,365.05);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("EgBwB8HMDVlh4AMAAAB4AgEjT0h8HMDVlAAAMjVlB4Bg");
	this.shape_171.setTransform(665.95,381.1);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#FFFFFF").s().p("EgXdBwkMDVlh3/MAAAB3/gEi+HhwkMDVlAAAMjVlB4Ag");
	this.shape_172.setTransform(684.725,365.7);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("EglaBoJMDVlh3/MAAAB3/gEiwKhoIMDVlAAAMjVlB3/g");
	this.shape_173.setTransform(703.2,348.775);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#FFFFFF").s().p("EgypBbZMDVlh3/MAAAB3/gEii7hbYMDVlAAAMjVlB3/g");
	this.shape_174.setTransform(701.675,356.475);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFFFFF").s().p("Eg/4BS+MDVlh3/MAAAB3/gEiVshS+MDVlAAAMjVlB4Ag");
	this.shape_175.setTransform(724.775,354.95);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FFFFFF").s().p("EhLLBO5MDVlh3/MAAAB3/gEiKZhO4MDVlAAAMjVlB3/g");
	this.shape_176.setTransform(726.425,328.775);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFFFFF").s().p("Ehc+BJmMDVlh3/MAAAB3/gEh4mhJlMDVlAAAMjVlB3/g");
	this.shape_177.setTransform(711.025,328.75);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#FFFFFF").s().p("EhqyBG4MDVlh3/MAAAB3/gEhqyhG3MDVlAAAMjVlB3/g");
	this.shape_178.setTransform(682.45,354.425);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFFFFF").s().p("EhqyA8AMAAAh3/MDVlAAAMAAAB3/g");
	this.shape_179.setTransform(682.45,384);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_157}]}).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[]},1).to({state:[{t:this.shape_171}]},15).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[]},1).wait(1));

	// Fondo
	this.botoniniciar2 = new lib.BotonIniciar2();
	this.botoniniciar2.name = "botoniniciar2";
	this.botoniniciar2.setTransform(241.75,337.8);
	new cjs.ButtonHelper(this.botoniniciar2, 0, 1, 2, false, new lib.BotonIniciar2(), 3);

	this.instance_2 = new lib.IntroTitulo1366768();
	this.instance_2.setTransform(24,79,0.2406,0.2406);

	this.instance_3 = new lib.Intro1366768();
	this.instance_3.setTransform(0,0,0.2396,0.24);

	this.instance_4 = new lib.Intro2();
	this.instance_4.setTransform(683,384,1,1,0,0,0,683,384);
	this.instance_4._off = true;
	var instance_4Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_4.filters = [instance_4Filter_1];
	this.instance_4.cache(-2,-2,1370,772);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.botoniniciar2}]}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.botoniniciar2}]},14).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.botoniniciar2}]},1).to({state:[{t:this.instance_4}]},15).to({state:[{t:this.instance_4}]},14).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_4}]},11).to({state:[]},9).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(30).to({_off:false},0).wait(29).to({_off:true},9).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_4Filter_1).wait(30).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 0).wait(14).to(new cjs.ColorFilter(0.94,0.94,0.94,1,15.3,15.3,15.3,0), 0).wait(2).to(new cjs.ColorFilter(0.86,0.86,0.86,1,35.7,35.7,35.7,0), 0).wait(2).to(new cjs.ColorFilter(0.81,0.81,0.81,1,48.45,48.45,48.45,0), 0).wait(12));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_4, startFrame:30, endFrame:30, x:-2, y:-2, w:1370, h:772});
	this.filterCacheList.push({instance: this.instance_4, startFrame:44, endFrame:44, x:-2, y:-2, w:1370, h:772});
	this.filterCacheList.push({instance: this.instance_4, startFrame:46, endFrame:46, x:-2, y:-2, w:1370, h:772});
	this.filterCacheList.push({instance: this.instance_4, startFrame:48, endFrame:48, x:-2, y:-2, w:1370, h:772});
	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-689.7,-413.2,2711.4,1684.1000000000001);


(lib.mc_escenario3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.boton6.addEventListener("click", abrir);
		
		function abrir() {
		    window.open("card.html", "_blank");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Capa_1
	this.boton6 = new lib.boton6();
	this.boton6.name = "boton6";
	this.boton6.setTransform(677.5,372.95);
	new cjs.ButtonHelper(this.boton6, 0, 1, 2, false, new lib.boton6(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9999FF").s().p("AhECkQg4gMAAgJIABgFIALgeIAHgdQACgHAGAAIAYAJQAZAJAQAAQA0AAAAgjQAAgdgyAAIgSABIgOAAIgSAAQgMgBAAgIQAAgoAEgKQACgHAGAAQAJAAATACIAaACQAMAAAHgHQAHgIAAgMQAAgfguAAQgTAAghAKIgDAAQgDAAgCgHIgCgaIgCgNIgBgNQABgOAsgIQAegFAdAAQAsAAAiAUQAqAYAAArQAAAxgtAaQAbAIAQAVQAOAVAAAbQAAAygoAaQgkAYgzAAQgoAAgagGg");
	this.shape.setTransform(485.1,98.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9999FF").s().p("AhgBkQgmgmAAg7QAAg9AkgnQAlgnA9AAQA9AAAlAmQAmAmAAA8QgBA9gkAmQgmAmg9AAQg6AAgmglgAghgkQgOAPAAAVQAAAVAOAQQANARAVAAQAUAAAOgRQAMgQAAgVQABgVgNgQQgOgQgUAAQgVAAgNARg");
	this.shape_1.setTransform(443.45,101.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9999FF").s().p("AgoC4QgGgBgBgCIAAgIIAAg4IABg5QAAhLgGgsIgBgHQAAgEAIAAIAXABIAWABIAYgBIAWgBQAHAAAAAFIAAAGQgGAzgBBEIABA8IACA5QgBAGgGABQgJABghAAQgeAAgKgBgAgkhnQgQgNAAgWQAAgVARgNQAPgNAVAAQAVAAAPANQAQANAAAVQABAvg1AAQgWAAgPgMg");
	this.shape_2.setTransform(421.35,96.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#9999FF").s().p("AhJCEQgJgBAAgIIAAhAIABhAQAAg/gMgpIAAgEQAAgEAEgBIArgGIAsgIQADAAACARQABAQADABIABAAIgBAAQgCgBAZgNQAZgPAYAAQAPAAAAAHIgBAWIgCAWIAAAUIABAVQAAALgMAAIgPgBIgOAAQgXAAgIAHQgIAHAAAUIABAjIAAAjIABAXIABAXQAAAGgJABIgmABQgaAAgPgBg");
	this.shape_3.setTransform(403.775,101.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#9999FF").s().p("AhwBfQgggnAAg1QAAg9AhgmQAjgnA9AAQApAAAZAdIABABQADAAADgMQADgOAEAAQAKAAAcAGQAbAFALAEQAEACAAACIAAAGQgJAxAAA2QAAAUACAoQADApAAAVQAAAKgKABQghADgrAAQgFAAgCgQQgBgPgDAAIgGAEQgeAeghAAQg0AAgjgpgAgngnQgOAOAAAYQAAAUAPAQQAPAPAWAAQAVAAAPgOQAPgPAAgWQAAgXgPgPQgOgPgWAAQgXAAgPAPg");
	this.shape_4.setTransform(376.175,101.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#9999FF").s().p("AAwCEQgIgBAAgKIABgmIAAgnIAAgdIAAgdQAAgkghAAQgJgBgOAKQgPAKAAAJIAACQQAAAKgIAAQgKABgcAAQggAAgKgBQgHgCgBgHIAAg/IABg/QAAhCgLgnIAAgEQAAgEAEgCIAtgFQAqgIAGAAQADgBABATQACARADAAIAAABIAAgBQgDAAAggSQAfgSAYAAQAiAAAXAPQAZATAAAhIAABVIABA0IAAA0QAAAHgHABQgJABgfAAQgiAAgIgBg");
	this.shape_5.setTransform(344.6,101.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9999FF").s().p("AhYBnQgogmAAhAQAAg8AkgnQAlgqA8AAQA0AAAkAmQAkAmAAAzQAAAbgSAEIg3AGIheAIQAEARATAJQAPAIATAAQAZAAAXgNIAVgNQAFADAOAYQANAZAAAHQAAACgEAEQggAkhGAAQg+AAgogmgAggg4QgLANAAARQABAIAHAAQAUAAApgHQAJgBAAgCQAAgSgMgMQgMgNgPAAQgRABgLAOg");
	this.shape_6.setTransform(315.75,101.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9999FF").s().p("AhDBjQgngoAAg7QAAg6AngoQAmgoA7AAQAoAAAdARQAIAEgBADQABAEgJAcIgJAhQgDAGgCAAIgQgFQgQgEgKAAQgYAAgOAOQgOAPAAAXQAAAYAPAPQAPANAZAAQAMAAAPgFIAPgHQAEAAAHAjQAGAfABAKQgBAKghAHQgaAGgPAAQg7AAgmgog");
	this.shape_7.setTransform(290.5,101.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#9999FF").s().p("AhBB0QgSgeAAgGQAAAAAAgBQAAAAAAgBQABAAAAAAQABAAAAAAIAmgIQAYgHAAgSQAAgLgOgQIgZgbQgOgUAAgWQAAgoApgcQAjgZAqAAQAEAAARAdQARAdAAAEQAAADgEAFQgHgCgIAAQgQAAgKAHQgNAIAAAPQAAAJANAPQAVAWAFAGQAOAUAAAYQAAANgGAQQgGARgJAIQgUARgbAMQgcAMgYAAQgFAAgTgdg");
	this.shape_8.setTransform(268.825,100.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9999FF").s().p("ABsC+QgTgDheAAIg+AAIg9AAQgJgBAAgHQAAgeAEg8QADg9AAgdQAAgegDhUIgEhAIAAgEQAAgGAHAAIA8ABIA7ABIA7gBIA7gBQAOAAACAKIAEAmIADAlQAAAHgGgBIgFAAQhHgGg5AAQgOAAgDAHQgCADAAARQAAATAGAFQAFAGANAAIAJAAIANgBQAiAAAigCIAPgBIAOgCQAHAAAAAHIgEApQgDAUAAAWQAAAGgIAAIgYgEQgPgBg3AAIgbAAQgLAAgCAGIgBAQQAAAVAEAGQAEAJAdADIAnAAQAOgBAdgCQAcgDANAAQAGAAAAAKQAAAMgFAeQgEAigEAHQgDAEgGAAIgIAAg");
	this.shape_9.setTransform(244.35,95.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#9999FF").s().p("AglBoQgPgQAAgWQgBgYAPgPQAQgPAXAAQAXAAAPAQQAPAPAAAXQAAAXgQAQQgPAQgXAAQgWAAgPgRgAgmgdQgPgOABgWQAAgXAPgQQAQgQAVAAQAXAAAPAQQAQAQAAAXQAAAXgQAOQgQAOgWAAQgWAAgQgPg");
	this.shape_10.setTransform(207.65,102.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#9999FF").s().p("AhwBfQgggnAAg1QAAg9AhgmQAjgnA9AAQApAAAZAdIABABQADAAADgMQADgOAEAAQAKAAAcAGQAbAFALAEQAEACAAACIAAAGQgJAxAAA2QAAAUACAoQADApAAAVQAAAKgKABQghADgrAAQgFAAgCgQQgBgPgDAAIgGAEQgeAeghAAQg0AAgjgpgAgngnQgOAOAAAYQAAAUAPAQQAPAPAWAAQAVAAAPgOQAPgPAAgWQAAgXgPgPQgOgPgWAAQgXAAgPAPg");
	this.shape_11.setTransform(184.075,101.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#9999FF").s().p("AAwCEQgIgBAAgKIABgmIABgnIgBgdIgBgdQAAgkgfAAQgKgBgOAKQgPAKAAAJIAACQQAAAKgIAAQgKABgdAAQgfAAgJgBQgJgCABgHIAAg/IAAg/QAAhCgKgnIgBgEQAAgEAEgCIAtgFQArgIAFAAQADgBABATQACARADAAIAAABIAAgBQgDAAAggSQAfgSAYAAQAiAAAWAPQAaATAAAhIAABVIAAA0IABA0QAAAHgIABQgHABggAAQgiAAgIgBg");
	this.shape_12.setTransform(152.5,101.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#9999FF").s().p("AhXBnQgpgmAAhAQAAg8AkgnQAlgqA8AAQA0AAAkAmQAkAmAAAzQAAAbgRAEIg4AGIheAIQAEARATAJQAPAIAUAAQAXAAAZgNIAUgNQAFADAOAYQANAZAAAHQAAACgEAEQghAkhFAAQg/AAgmgmgAggg4QgLANABARQgBAIAIAAQAUAAApgHQAJgBAAgCQAAgSgMgMQgMgNgPAAQgRABgLAOg");
	this.shape_13.setTransform(123.65,101.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#9999FF").s().p("AhDBjQgmgogBg7QABg6AmgoQAngoA5AAQApAAAeARQAGAEABADQgBAEgHAcIgKAhQgCAGgDAAIgQgFQgQgEgKAAQgYAAgOAOQgNAPAAAXQAAAYAOAPQAPANAaAAQAMAAAPgFIANgHQAFAAAHAjQAHAfgBAKQABAKgiAHQgaAGgQAAQg6AAgmgog");
	this.shape_14.setTransform(98.4,101.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9999FF").s().p("AhBB0QgSgeAAgGQAAAAAAgBQAAAAAAgBQABAAAAAAQABAAAAAAIAmgIQAYgHAAgSQAAgLgOgQIgZgbQgOgUAAgWQAAgoApgcQAjgZAqAAQAEAAARAdQARAdAAAEQAAADgEAFQgHgCgIAAQgQAAgKAHQgNAIAAAPQAAAJANAPQAVAWAFAGQAOAUAAAYQAAANgGAQQgGARgJAIQgUARgbAMQgcAMgYAAQgFAAgTgdg");
	this.shape_15.setTransform(76.725,100.95);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#9999FF").s().p("ABsC+QgUgDheAAIg9AAIg9AAQgJgBAAgHQAAgeADg8QAEg9AAgdQAAgegEhUIgChAIAAgEQgBgGAHAAIA8ABIA8ABIA5gBIA8gBQAOAAACAKIAEAmIADAlQAAAHgFgBIgGAAQhIgGg4AAQgNAAgEAHQgCADABARQAAATAFAFQAEAGANAAIAKAAIANgBQAhAAAkgCIAOgBIAPgCQAGAAAAAHIgFApQgCAUAAAWQAAAGgHAAIgZgEQgPgBg2AAIgcAAQgLAAgCAGIAAAQQAAAVACAGQAFAJAdADIAnAAQAOgBAcgCQAdgDAOAAQAFAAAAAKQAAAMgEAeQgFAigEAHQgDAEgGAAIgIAAgAB6guIAAAAIAAAAg");
	this.shape_16.setTransform(52.25,95.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#9933CC").s().p("Ai4CcQg1hAAAhXQAAhlA3g+QA5hABkAAQBEAAAoAwQAAABAAAAQABABAAAAQABAAAAAAQAAAAABAAQAEAAAFgVQAFgVAHAAQAQAAAuAJQArAJATAGQAHADAAAEIgCAJQgOBQAABZQAAAgAEBDQAEBDAAAhQAAASgPABQg3AEhGAAQgIAAgDgZQgDgZgEgBQgEACgFAGQgxAxg4AAQhVAAg5hDgAhAhBQgXAYAAAmQAAAjAYAZQAZAaAjAAQAkAAAYgYQAYgZAAglQAAglgYgYQgXgZglAAQgmAAgXAYg");
	this.shape_17.setTransform(794.825,224.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#9933CC").s().p("AhyDAIAChXQACg6AAgdQAAgTgWAAIgGAAIgGABQgQAAAAgNIABgVIABgVIgBgdIgBgcQAAgIAcgCQAPAAACgIQACgRAAgkIgCg2QAAgzAJAAQAMAAAWAFQAZAGAKABIBDAIQALABAAAHQAAASgDAjQgDAjAAATQAAAVANAAIAugBIAvgBQAKAAAAAGIgCAfIgCAdIAAAgIAAAeQAAAIgMAAIgeAAIgdgBIghAAQgHAAAAATIAAAgIABAfQAAAkAIAPQAMATAjAAQALgBAUgEQAVgGAIABQAJAAAAAJQAAAOgDAaQgDAbAAANQAAAMgDADQgDAEgMAGQg4AghFAAQh+AAAAhhg");
	this.shape_18.setTransform(752.175,218.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#9933CC").s().p("AiQCpQhCg/AAhnQAAhkA7hAQA8hEBkAAQBUAAA7A+QA7A9AABWQAAArgcAGIhbAJQg1AHhlAHQAGAdAfAPQAZAMAgAAQAnAAAngVIAigVQAKAEAVAoQAWApAAALQAAADgHAHQg1A5hyAAQhnAAhAg8gAg1hcQgRAVAAAdQAAAMAMgBQAhAABDgKQAPgCAAgEQAAgbgTgWQgUgUgZAAQgcAAgSAYg");
	this.shape_19.setTransform(713,224.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#9933CC").s().p("AhwEeQAAgmALgDQAigLAKgKQAKgMACglQACgXAAhiQAAhzgQheIgBgHQAAgLANAAQAsAAAXgCIBNgIQAJAAABALQADAVAACXIAACYQAABbgfAuQgjAyhUASQgaAGgdAAQgRAAAAhNgAghjnQgagUAAgkQAAgiAagVQAagUAhAAQAjAAAaAUQAbAVAAAiQAABKhYAAQgkAAgXgSg");
	this.shape_20.setTransform(675.15,221.725);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#9933CC").s().p("Ah4DYQgOgDAAgMIAAhpIABhoQgBhogShCIgBgHQAAgHAGgCIBHgJIBHgOQAIAAACAbQACAbAFABIAAAAIAAAAQgEgBAogWQArgXAnAAQAYAAABALQgBANgCAXIgDAkIAAAhIABAiQAAASgTAAIgYgBIgYgBQgkAAgOALQgNALAAAiIABA6IAAA5IACAmIACAlQAAALgOACQgVABgrAAQgqAAgZgCg");
	this.shape_21.setTransform(648.65,224.65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#9933CC").s().p("Ai4CcQg1hAAAhXQAAhlA3g+QA5hABkAAQBEAAAoAwQAAABAAAAQABABAAAAQABAAAAAAQAAAAABAAQAEAAAFgVQAFgVAHAAQAQAAAuAJQArAJATAGQAHADAAAEIgCAJQgOBQAABZQAAAgAEBDQAEBDAAAhQAAASgPABQg3AEhGAAQgIAAgDgZQgDgZgEgBQgEACgFAGQgxAxg4AAQhVAAg5hDgAhAhBQgXAYAAAmQAAAjAYAZQAZAaAjAAQAkAAAYgYQAYgZAAglQAAglgYgYQgXgZglAAQgmAAgXAYg");
	this.shape_22.setTransform(603.575,224.875);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#9933CC").s().p("AhNE1QgMgCAAgLQAAg0AEhoQAFhoAAgzQAAgigEh2QhYAIg0AAQgHAAAAgEQAAgGAGgcIAIglIADgqQADggAIAAIAGAAQBHAJCKAAQAoAABqgIIA6gFQAJAAABACQABABABAHIgBAhIgBAhQAAALADAWQADAVAAAKQAAAJgKAAQgRAAhzgHIgDCbQAAAzAFBpQADBoAAA0QAAAIgDACIgNACQgaAEgzAAQg4AAgXgEg");
	this.shape_23.setTransform(554.075,215.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.boton6}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_escenario3, new cjs.Rectangle(34,62,1224.1,346), null);


(lib.mc_escenario2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {fotograma5:4,fotograma10:9,fotograma15:14,fotograma20:19};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.gotoAndStop(variable1);
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.ibotonvolver.on("click", inicio.bind(this));
		
		function inicio(e){
			this.parent.cambiarEscenario(new lib.mc_escenario1(),1);	
		}
	}
	this.frame_8 = function() {
		this.stop();
		
		this.ibotonvolver.on("click", contenido3.bind(this));
		
		function contenido3(e){
			this.parent.cambiarEscenario(new lib.mc_escenario1());
		}
	}
	this.frame_9 = function() {
		this.ibotonvolver2.on("click", inicio2.bind(this));
		
		function inicio2(e){
			this.parent.cambiarEscenario(new lib.mc_escenario1(),1);	
		}
	}
	this.frame_13 = function() {
		this.stop();
	}
	this.frame_14 = function() {
		this.ibotonvolver3.on("click", inicio3.bind(this));
		
		function inicio3(e){
			this.parent.cambiarEscenario(new lib.mc_escenario1(),1);	
		}
	}
	this.frame_18 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
		this.ibotonvolver4.on("click", inicio4.bind(this));
		
		function inicio4(e){
			this.parent.cambiarEscenario(new lib.mc_escenario1(),1);	
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3).call(this.frame_3).wait(1).call(this.frame_4).wait(4).call(this.frame_8).wait(1).call(this.frame_9).wait(4).call(this.frame_13).wait(1).call(this.frame_14).wait(4).call(this.frame_18).wait(1).call(this.frame_19).wait(1));

	// Objetos
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	this.shape.setTransform(683,384);

	this.ibotonvolver = new lib.Volver();
	this.ibotonvolver.name = "ibotonvolver";
	this.ibotonvolver.setTransform(658.4,481.9);
	new cjs.ButtonHelper(this.ibotonvolver, 0, 1, 2, false, new lib.Volver(), 3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9999FF").s().p("AhhBkQgmgmABg7QAAg9AkgnQAlgnA9AAQA9AAAlAmQAmAmgBA8QABA9glAmQgmAmg9AAQg6AAgnglgAgigkQgMAPAAAVQAAAVAMAQQAOARAUAAQAWAAANgRQAMgQAAgVQABgVgNgQQgNgQgWAAQgUAAgOARg");
	this.shape_1.setTransform(457.6,58.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9999FF").s().p("AhzCcQgggmAAg6QAAg6AfglQAigoA6AAQAnAAAXAaQAEAEABAAQACAAAAgHIgBg+IgBg9QABgJAEAAIAvgEQA1gGgFAAQAFAAABAFIgCATQgEAegBAvQgDA0ABBCQAABvAGAvIABAGQAAAEgFAAQgKABg9ABQgOAAgDgHIgBgUIgCgEIgDAEQgeAbgqAAQg5AAgigngAglAVQgNAQAAAXQAAAVANAPQAOAQAVAAQAUAAAPgQQAPgQAAgWQAAgVgPgQQgQgQgTAAQgWAAgNAQgACPjCIAAAAIAAAAg");
	this.shape_2.setTransform(426.5,52.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#9999FF").s().p("AgoC4QgGgBgBgCIgBgIIABg4IABg5QAAhKgGgtIAAgHQAAgEAHAAIAXABIAWABIAXgBIAXgBQAHAAAAAFIAAAGQgHAzAABEIABA8IABA5QABAGgIABQgIABggAAQggAAgJgBgAgjhnQgQgNgBgWQAAgVARgNQAPgNAVAAQAVAAAPANQAQANABAVQgBAvg0AAQgVAAgPgMg");
	this.shape_3.setTransform(403.05,53.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#9999FF").s().p("AAwCEQgIgBAAgKIABgmIABgnIgBgdIAAgdQAAgkghAAQgJgBgOAKQgPAKAAAJIAACQQAAAKgIAAQgJABgdAAQggAAgKgBQgHgCgBgHIAAg/IABg/QAAhCgLgnIAAgEQAAgEAEgCIAtgFQArgIAFAAQADgBABATQACARADAAIAAABIAAgBQgDAAAggSQAfgSAYAAQAiAAAXAPQAZATAAAhIAABVIAAA0IABA0QAAAHgHABQgJABgfAAQgiAAgIgBg");
	this.shape_4.setTransform(379.6,58.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#9999FF").s().p("AhXBnQgpgmAAhAQAAg8AkgnQAlgqA8AAQA0AAAkAmQAkAmAAAzQAAAbgSAEIg3AGIheAIQAEARATAJQAPAIAUAAQAXAAAYgNIAVgNQAFADAOAYQANAZAAAHQAAACgEAEQghAkhFAAQg+AAgngmgAggg4QgKANAAARQAAAIAHAAQAUAAApgHQAJgBAAgCQAAgSgMgMQgMgNgPAAQgRABgLAOg");
	this.shape_5.setTransform(350.75,58.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9999FF").s().p("AhFB1IABg1IABg1QABgLgOAAIgEAAIgDAAQgKAAAAgHIAAgNIABgNIgBgSIAAgRQgBgFASgBQAJAAABgFQABgKAAgWIgBghQAAggAGAAQAHAAAOAEIAVAEIAoAFQAHAAAAAEIgCAhIgCAhQABANAHAAIAdgBIAcgBQAHAAAAAEIgCATIgBASIAAATIAAATQAAAEgHAAIgSAAIgSAAIgVAAQgEAAAAALIAAAUIAAATQAAAWAGAJQAHALAVAAQAHAAAMgDQANgDAFAAQAGAAAAAGIgDAZIgCAYQABAHgCACIgJAHQgiATgrAAQhNAAABg8g");
	this.shape_6.setTransform(326.35,54.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9999FF").s().p("AAwCEQgIgBAAgKIABgmIAAgnIAAgdIAAgdQAAgkghAAQgJgBgOAKQgPAKAAAJIAACQQAAAKgIAAQgKABgcAAQggAAgKgBQgHgCgBgHIAAg/IABg/QAAhCgLgnIAAgEQAAgEAEgCIAtgFQAqgIAGAAQADgBABATQACARADAAIAAABIAAgBQgDAAAggSQAfgSAYAAQAiAAAXAPQAZATAAAhIAABVIABA0IAAA0QAAAHgHABQgJABgfAAQgiAAgIgBg");
	this.shape_7.setTransform(300.05,58.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#9999FF").s().p("AhgBkQgmgmAAg7QAAg9AkgnQAlgnA9AAQA9AAAlAmQAmAmAAA8QgBA9gkAmQgmAmg9AAQg6AAgmglgAghgkQgOAPAAAVQAAAVAOAQQANARAVAAQAUAAAOgRQAMgQAAgVQABgVgNgQQgOgQgUAAQgVAAgNARg");
	this.shape_8.setTransform(270.2,58.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9999FF").s().p("AhuCMQgzg3AAhVQAAhQAyg5QA0g8BPAAQBXAAAxA2QAFAFAAAFQAAAGgSAgQgTAhgFAEQgCACgDAAQgCAAgMgKQgOgNgOgIQgVgLgXAAQgnAAgXAeQgWAbAAAoQAAAoAWAcQAXAeAnAAQAXAAAVgKQAOgGAOgNQAMgKABAAQADAAADADIAXAiQAUAdAAADQAAAFgGAHQgxA6hSAAQhTABg0g6g");
	this.shape_9.setTransform(239.075,52.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#9999FF").s().p("AglBoQgQgQAAgWQABgYAPgPQAOgPAYAAQAXAAAPAQQAOAPAAAXQAAAXgPAQQgQAQgWAAQgWAAgPgRgAglgdQgPgOgBgWQAAgXAQgQQAQgQAVAAQAWAAAQAQQAPAQAAAXQAAAXgPAOQgPAOgYAAQgWAAgOgPg");
	this.shape_10.setTransform(200.85,60.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#9999FF").s().p("AhwBfQgggnAAg1QAAg9AhgmQAjgnA9AAQApAAAZAdIABABQADAAADgMQADgOAEAAQAKAAAcAGQAbAFALAEQAEACAAACIAAAGQgJAxAAA2QAAAUACAoQADApAAAVQAAAKgKABQghADgrAAQgFAAgCgQQgBgPgDAAIgGAEQgeAeghAAQg0AAgjgpgAgngnQgOAOAAAYQAAAUAPAQQAPAPAWAAQAVAAAPgOQAPgPAAgWQAAgXgPgPQgOgPgWAAQgXAAgPAPg");
	this.shape_11.setTransform(177.275,58.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#9999FF").s().p("AAwCEQgIgBAAgKIABgmIAAgnIAAgdIAAgdQAAgkghAAQgJgBgOAKQgPAKAAAJIAACQQAAAKgIAAQgKABgcAAQggAAgKgBQgHgCgBgHIAAg/IABg/QAAhCgLgnIAAgEQAAgEAEgCIAtgFQAqgIAGAAQADgBABATQACARADAAIAAABIAAgBQgDAAAggSQAfgSAYAAQAiAAAXAPQAZATAAAhIAABVIABA0IAAA0QAAAHgHABQgJABgfAAQgiAAgIgBg");
	this.shape_12.setTransform(145.7,58.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#9999FF").s().p("AhXBnQgpgmAAhAQAAg8AkgnQAlgqA8AAQA0AAAkAmQAkAmAAAzQAAAbgSAEIg3AGIheAIQAEARATAJQAPAIATAAQAZAAAXgNIAVgNQAGADANAYQANAZAAAHQAAACgEAEQggAkhGAAQg+AAgngmgAggg4QgLANABARQAAAIAHAAQAUAAApgHQAJgBAAgCQAAgSgMgMQgMgNgPAAQgRABgLAOg");
	this.shape_13.setTransform(116.85,58.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#9999FF").s().p("AhDBjQgngoAAg7QAAg6AngoQAmgoA7AAQAoAAAdARQAIAEgBADQABAEgJAcIgJAhQgDAGgCAAIgQgFQgQgEgKAAQgYAAgOAOQgOAPAAAXQAAAYAPAPQAPANAZAAQAMAAAPgFIAPgHQAEAAAHAjQAGAfABAKQgBAKghAHQgaAGgPAAQg7AAgmgog");
	this.shape_14.setTransform(91.6,58.475);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9999FF").s().p("AhBB0QgSgeAAgGQAAAAAAgBQAAAAAAgBQABAAAAAAQABAAAAAAIAmgIQAYgHAAgSQAAgLgOgQIgZgcQgOgTAAgWQAAgoApgcQAjgZAqAAQAEAAARAdQARAdAAAFQAAACgEAFQgHgCgIAAQgQAAgKAHQgNAIAAAPQAAAJANAPQAVAWAFAGQAOAUAAAYQAAANgGAQQgGARgJAIQgUARgbAMQgcAMgYAAQgFAAgTgdg");
	this.shape_15.setTransform(69.925,58.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#9999FF").s().p("ABsC+QgTgDheAAIg+AAIg9AAQgJgBAAgHQAAgeAEg8QADg9AAgdQAAgegDhUIgEhAIAAgEQAAgGAHAAIA8ABIA7ABIA7gBIA7gBQAOAAACAKIAEAmIADAlQAAAHgGAAIgFgBQhHgGg5AAQgOAAgDAHQgCADAAARQAAATAGAGQAFAFANAAIAJAAIANgBQAiAAAigCIAPgBIAOgBQAHgBAAAHIgEApQgDAUAAAWQAAAGgIAAIgYgEQgPgBg3AAIgbAAQgLAAgCAGIgBAQQAAAVAEAGQAEAJAdADIAnAAQAOgBAdgCQAcgDANAAQAGAAAAAKQAAAMgFAeQgEAigEAHQgDAEgGAAIgIAAg");
	this.shape_16.setTransform(45.45,53.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#9933CC").s().p("Ah+ENQhMgKgEgNQgCgGAAghQAAgTAEgfQAGgnAIAAIAHACQA0AbBEAAQBgAAAAg/QAAgjgigSQgcgOgnAAQgQAAggAEQghAEgQAAQgPAAAAgOQAAgpADhXQAEhWAAgqQAAgJAGgJQAHgJAIgCQAKgBBwAAICrABQALAAABAKQAAAZgGArQgHA4gIAAIgFAAQhjgJgaAAQguAAgEAFQgIANABAlQAAAFACAEQALAAAYgDIAhgCQBRAAA3AsQA6AuAABQQAADEjxAAQgjAAg7gHg");
	this.shape_17.setTransform(1122.25,297.325);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#9933CC").s().p("Ai4CcQg1hAAAhXQAAhlA3g+QA5hABkAAQBEAAAoAwQAAABAAAAQABABAAAAQABAAAAAAQAAAAABAAQAEAAAFgVQAFgVAHAAQAQAAAuAJQArAJATAGQAHADAAAEIgCAJQgOBQAABZQAAAgAEBDQAEBDAAAhQAAASgPABQg3AEhGAAQgIAAgDgZQgDgZgEgBQgEACgFAGQgxAxg4AAQhVAAg5hDgAhAhBQgXAYAAAmQAAAjAYAZQAZAaAjAAQAkAAAYgYQAYgZAAglQAAglgYgYQgXgZglAAQgmAAgXAYg");
	this.shape_18.setTransform(1050.075,302.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#9933CC").s().p("ADQDZQgMgDAAgSIABg9IABg9QAAhLgBghQgEg0gvAAQgUAAgUARQgVASgCAVQgCASAABZIACA/IABA/QAAAOgNAAIiEAAQgMAAAAgSIABg+IABg/IAAgwIgBgyQAAg+gxAAQgTAAgWAPQgZAQAAASIABB2IAAB3QAAAMgCADQgDACgLABQgUABgrAAQgbAAgkgCQgKgBgCgCQgCgDAAgLIABhoIAAhpQAAhIgKhaIgBgIQAAgHAFgDQALgEAagDIAogDIAigJQAWgHAMAAQAJAAAAAfQABAeADAAQAFgCAFgEQAngfAYgLQAigQAnAAQAogBAfATQAkAUAKAkQAXgfApgWQApgVAnAAQA6AAAlAbQApAegBA4IAABGIgCBFIACBTIAABTQABAQgNACQgOABg0AAQg1AAgOgCg");
	this.shape_19.setTransform(984.45,302);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#9933CC").s().p("Ai4CcQg1hAAAhXQAAhlA3g+QA5hABkAAQBEAAAoAwQAAABABAAQAAABAAAAQABAAAAAAQAAAAABAAQAEAAAFgVQAFgVAHAAQAQAAAuAJQArAJATAGQAHADAAAEIgCAJQgOBQAABZQAAAgAEBDQAEBDAAAhQAAASgPABQg3AEhGAAQgIAAgDgZQgDgZgEgBQgEACgFAGQgxAxg4AAQhVAAg5hDgAhAhBQgXAYAAAmQAAAjAYAZQAZAaAjAAQAkAAAYgYQAYgZAAglQAAglgYgYQgXgZglAAQgmAAgXAYg");
	this.shape_20.setTransform(918.625,302.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#9933CC").s().p("Ah4DYQgPgDAAgMIABhpIAAhoQABhogUhCIgBgHQAAgHAHgCIBHgKIBIgNQAGAAADAcQACAaAFABIABAAIgBAAQgDgBAogWQAqgXAnAAQAZAAAAALQAAANgDAXIgDAkIABAhIAAAiQAAASgTAAIgYgBIgYgBQglAAgNALQgNAMAAAhIABA6IABA5IABAmIACAlQAAALgOACQgVABgrAAQgqAAgZgCg");
	this.shape_21.setTransform(876.5,302.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#9933CC").s().p("AhqELQhRgPAAgUQAAgIAThPQADgMAHAAIAEACQBEAhA6ABQAegBAggQQAlgSAAgdIAAgdQgsAqhGAAQhSAAg2g7Qgzg6AAhSQAAhUAxg3QA0g6BTAAQBBAAAjAvQAHALADAAQAEAAAAgQQAAgkAIABIBMAHIBHAIQAIADAAAIIgCBbQgCA8AAAeIAAA2IABA1QAAB+g1A2Qg2A4h+AAQglAAhAgMgAgziFQgWAYAAAhQAAAfAWAYQAWAWAeAAQAgAAAWgWQAVgYAAghQAAgfgVgYQgWgXggAAQgfAAgVAXg");
	this.shape_22.setTransform(832.025,307.95);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#9933CC").s().p("AifCjQg+g+AAhhQAAhkA8g/QA8hBBlABQBjAAA9A+QA+A+AABjQAABkg9A+Qg+A/hjAAQhgAAg/g+gAg4g8QgVAZAAAjQAAAjAVAZQAXAbAhAAQAjAAAWgbQAVgZAAgjQAAgjgWgaQgVgbgjABQghAAgXAbg");
	this.shape_23.setTransform(783.525,302.15);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#9933CC").s().p("AhyDAIAChXQACg6AAgdQAAgTgWAAIgGAAIgGABQgQgBAAgMIABgVIABgVIgBgcIgBgdQAAgIAcgCQAPAAACgIQACgRAAgkIgCg2QAAgzAJAAQAMAAAWAFQAZAGAKABIBDAIQALABAAAHQAAASgDAjQgDAjAAATQAAAVANAAIAugCIAvAAQAKAAAAAGIgCAeIgCAeIAAAgIAAAeQAAAIgMAAIgeAAIgdgBIghAAQgHAAAAATIAAAgIABAfQAAAkAIAPQAMATAjAAQALgBAUgEQAVgGAIABQAJAAAAAJQAAANgDAbQgDAbAAANQAAAMgDADQgDAEgMAHQg4AfhFAAQh+AAAAhhg");
	this.shape_24.setTransform(742.725,295.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#9933CC").s().p("AifCjQg+g+AAhhQAAhkA8g/QA8hBBlABQBjAAA9A+QA+A+AABjQAABkg9A+Qg+A/hjAAQhgAAg/g+gAg4g8QgVAZAAAjQAAAjAVAZQAXAbAhAAQAjAAAWgbQAVgZAAgjQAAgjgWgaQgVgbgjABQghAAgXAbg");
	this.shape_25.setTransform(701.925,302.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#9933CC").s().p("AhmE6QhSAAgYgGQgMgDAAgKQAAgxADhiQADhiAAgwQAAg5gFhYIgIiSIgBgGQAAgLANAAIBjACIBiABQAiAABHgFQBHgFAjAAQAWAAACASIACA4QABAKAFAcQAEAYAAANQAAAFgJAAQghAAhCgGQhEgGghAAQgpAAgHADQgRAIAAAjQAAApAWAGQAIACARAAQAfAAA8gDQA9gDAeAAQAOAAAABNQAABCgEALQgEAIgIAAIgcgDQgvgEhfAAIgiAAQgXAEAAAPQAAA+AGBSIAEBCQgBALgaABIgoAAg");
	this.shape_26.setTransform(654.0491,292.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#9933CC").s().p("AhEEzQgKgCgBgKIAAgTIABh0IABh1IAAioQgBhhgKhHIAAgHQAAgKALABICcAAQALgBgBAKIgBAHQgLC+AACSIABC3IABAjIACAjQAAAJgLACQgUAEgzAAQg0AAgPgEg");
	this.shape_27.setTransform(592.9542,293);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#9933CC").s().p("AiQCpQhCg+AAhoQAAhkA7hBQA8hCBjAAQBVgBA7A+QA7A9AABWQAAArgcAGIhbAJQg0AHhnAHQAHAdAfAPQAZAMAgAAQAnAAAogVIAhgVQAKAEAWAoQAVApAAALQAAADgHAHQg2A6hxAAQhngBhAg8gAg1hcQgRAVAAAdQAAAMANAAQAgAABDgLQAPgCAAgEQAAgbgTgWQgUgUgaAAQgbAAgSAYg");
	this.shape_28.setTransform(558.8,302);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#9933CC").s().p("ABPDYQgNgDAAgPIACg/IABg/IgBgvIgBgxQAAg7g0AAQgRgBgXAPQgYARAAAQIAADsQAAAPgOACQgPABgvAAQg0AAgPgCQgOgCAAgMIAAhoIABhmQAAhugRg/IgBgGQAAgHAHgCIBJgKQBGgOAJAAQAFAAADAeQACAeAFAAQgFAAA1gfQAzgeAnAAQA3AAAlAaQAqAeABA2IAACMIAABVIAABWQAAALgMACQgNABg0AAQg3AAgNgCg");
	this.shape_29.setTransform(487.4,302.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#9933CC").s().p("AiQCpQhCg+AAhoQAAhkA7hBQA8hCBjAAQBVgBA7A+QA7A9AABWQAAArgdAGIhbAJQg0AHhmAHQAHAdAfAPQAZAMAgAAQAnAAAngVIAigVQAJAEAXAoQAVApAAALQAAADgHAHQg2A6hwAAQhogBhAg8gAg1hcQgRAVAAAdQAAAMANAAQAgAABEgLQAOgCAAgEQAAgbgUgWQgSgUgbAAQgbAAgSAYg");
	this.shape_30.setTransform(440.25,302);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#9933CC").s().p("Ai3EWIgOgqIgOggQgKgXAAgHQAAgIAHAAQB6AAAAg4QAAgFg7hTQg+hTgHgXQgDgNAAhOIABgvIABgwQAAgMAOAAIBEACIBEABQAJAAAAAOIgBAlIgBAlQAAA3ABAUQACAPAZAqQAaAsALAAQAKAAAYgrQAXgpABgOQAFgnAAgtIgCgkQgDgYAAgNQAAgIAKAAIBDgCIBDgCQALAAAEAMQAGAUAABJQAABWgFASQgHAWhZCIQgOAWg7BOQg/BWgJAFQgLAHh8AAQgTAAgHgFg");
	this.shape_31.setTransform(370.875,310.125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#9933CC").s().p("AifCjQg+g+AAhhQAAhkA8g/QA8hBBlABQBjAAA9A+QA+A+AABjQAABkg9A+Qg+A/hjAAQhgAAg/g+gAg4g8QgVAZAAAjQAAAjAVAZQAXAbAhAAQAjAAAWgbQAVgZAAgjQAAgjgWgaQgVgbgjABQghAAgXAbg");
	this.shape_32.setTransform(322.625,302.15);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#9933CC").s().p("AhyDAIAChXQACg6AAgdQAAgTgWAAIgGAAIgGABQgQgBAAgMIABgVIABgVIgBgcIgBgdQAAgIAcgCQAPAAACgIQACgRAAgkIgCg2QAAgzAJAAQAMAAAWAFQAZAGAKABIBDAIQALABAAAHQAAASgDAjQgDAjAAATQAAAVANAAIAugCIAvAAQAKAAAAAGIgCAeIgCAeIAAAgIAAAeQAAAIgMAAIgeAAIgdgBIghAAQgHAAAAATIAAAgIABAfQAAAkAIAPQAMATAjAAQALgBAUgEQAVgGAIABQAJAAAAAJQAAANgDAbQgDAbAAANQAAAMgDADQgDAEgMAHQg4AfhFAAQh+AAAAhhg");
	this.shape_33.setTransform(281.825,295.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#9933CC").s().p("AhqC+QgfgwAAgLQAAgEAFgBIA+gLQAngMAAgdQAAgTgXgZIgpguQgXggAAgjQAAhCBDguQA6gpBFAAQAGAAAcAvQAcAvAAAIQAAAFgHAHQgMgDgNAAQgZAAgSALQgVAOAAAYQAAAPAXAYQAiAkAHALQAXAhAAAmQAAAXgJAZQgKAcgPAMQghAcgrAUQgvAUgnAAQgJAAgegvg");
	this.shape_34.setTransform(248.4,301.625);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#9933CC").s().p("ACwE3QgfgFibAAIhkgBIhlAAQgOAAAAgMQAAgyAGhjQAFhiAAgwQAAgzgFiJIgFhpIgBgFQgBgKANAAIBiABIBhACIBggCIBhgBQAXgBADASQACAJAFA0QAEAzAAALQABAJgKAAIgJAAQh1gKhcAAQgXAAgFALQgDAGAAAcQABAeAIAKQAHAIAWAAIAQgBIAVgBQA3AAA5gCIAZgCQAOgCAJAAQAKAAABAJQgBgGgHBKQgEAiAAAjQAAAJgNAAIgngFQgZgChZAAIguAAQgSAAgDAJIgBAbQAAAiAFAJQAIARAvADIBAAAQAXAAAvgEQAtgEAYgBQAJABAAAPQAAATgHAzQgIA3gHAKQgFAJgJAAIgOgBg");
	this.shape_35.setTransform(208.35,293.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#0099FF").s().p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	this.shape_36.setTransform(683,384);

	this.ibotonvolver2 = new lib.Volver2();
	this.ibotonvolver2.name = "ibotonvolver2";
	this.ibotonvolver2.setTransform(658.4,481.9);
	new cjs.ButtonHelper(this.ibotonvolver2, 0, 1, 2, false, new lib.Volver2(), 3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#9933CC").s().p("Ai7DCQhKhSAAhwQAAhyBKhQQBMhTBvAAQBxAABLBTQBKBQAAByQAABwhJBSQhMBUhxAAQhvAAhMhUgAhIhPQgaAgAAAvQAAAtAaAiQAcAkAsAAQArAAAdglQAbgjAAgrQAAgtgagiQgcgjgtAAQgtAAgbAjg");
	this.shape_37.setTransform(1137,297.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#9933CC").s().p("AgzEIIABgFQAGioAAgkIAAiBQAAgNgGAAQgJAAgRAGQgSAFgJAAQgOAAAAgQIgBgtIAAgtQAAgJALgFQBBgaAlguQAGgJAFAAIAGABIAxALIA0AIQAGACAAAIIgBAJQgFAnAACWIABCXIAACYQAAAJgHAHQgIAHgIAAIhAAAIg+ABQgQAAAAgOg");
	this.shape_38.setTransform(1092.125,296.025);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#9933CC").s().p("ADRDZQgNgDgBgSIABg9IACg9QAAhLgCghQgDg0guAAQgVAAgVARQgUASgCAVQgCASAABZIACA/IABA/QAAAOgNAAIiEAAQgNAAAAgSIACg+IABg/IgBgwIgBgyQABg+gwAAQgUAAgWAPQgZAQAAASIABB2IAAB3QAAAMgDADQgCACgLABQgUABgrAAQgbAAgkgCQgKgBgBgCQgDgDAAgLIAAhoIABhpQAAhIgLhaIgBgIQAAgHAHgDQAJgEAbgDIAngDIAjgJQAVgHANAAQAJAAAAAfQABAeADAAQAFgCAFgEQAogfAWgLQAigQAoAAQApgBAeATQAjAUALAkQAYgfApgWQAogVAnAAQA6AAAkAbQApAeABA4IgBBGIgCBFIACBTIABBTQgBAQgNACQgNABg0AAQg1AAgNgCg");
	this.shape_39.setTransform(964.35,302);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#9933CC").s().p("Ah4DYQgOgDgBgMIABhpIAAhoQAAhogThCIAAgHQgBgHAIgCIBGgKIBHgNQAIAAACAcQACAaAFABIAAAAIAAAAQgEgBAogWQArgXAnAAQAZAAgBALQABANgDAXIgDAkIABAhIAAAiQAAASgSAAIgZgBIgYgBQgkAAgNALQgOAMAAAhIABA6IAAA5IACAmIACAlQAAALgPACQgTABgsAAQgqAAgZgCg");
	this.shape_40.setTransform(856.4,302.15);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#9933CC").s().p("AiQCpQhCg+AAhoQAAhkA7hBQA9hCBiAAQBVgBA7A+QA7A9AABWQAAArgdAGIhbAJQgzAHhnAHQAHAdAfAPQAZAMAgAAQAnAAAngVIAigVQAJAEAXAoQAVApAAALQAAADgHAHQg1A6hxAAQhogBhAg8gAg1hcQgRAVAAAdQAAAMANAAQAgAABEgLQAOgCAAgEQAAgbgUgWQgSgUgbAAQgbAAgSAYg");
	this.shape_41.setTransform(538.7,302);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#9933CC").s().p("ABPDYQgNgDAAgPIABg/IABg/IgBgvIAAgxQAAg7g1AAQgPgBgXAPQgZARAAAQIAADsQAAAPgNACQgQABgvAAQg0AAgQgCQgNgCAAgMIABhoIAAhmQAAhugRg/IgBgGQAAgHAHgCIBKgKQBFgOAJAAQAFAAACAeQADAeAFAAQgFAAA0gfQA0geAnAAQA3AAAmAaQAqAeAAA2IAACMIAABVIAABWQAAALgMACQgMABg1AAQg2AAgOgCg");
	this.shape_42.setTransform(467.3,302.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#9933CC").s().p("AiQCpQhCg+AAhoQAAhkA7hBQA8hCBkAAQBUgBA7A+QA7A9AABWQAAArgdAGIhbAJQg0AHhlAHQAGAdAfAPQAZAMAgAAQAnAAAngVIAigVQAKAEAVAoQAWApAAALQAAADgHAHQg2A6hxAAQhngBhAg8gAg1hcQgRAVAAAdQAAAMAMAAQAhAABEgLQAOgCAAgEQAAgbgUgWQgSgUgaAAQgcAAgSAYg");
	this.shape_43.setTransform(420.15,302);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#9933CC").s().p("AhrC+QgegwAAgLQAAgEAFgBIA+gLQAngMAAgdQgBgTgWgZIgqguQgWggAAgjQAAhCBCguQA8gpBEAAQAGAAAcAvQAcAvAAAIQAAAFgGAHQgNgDgNAAQgZAAgSALQgVAOAAAYQAAAPAWAYQAiAkAIALQAXAhgBAmQABAXgJAZQgKAcgPAMQghAcgsAUQgtAUgoAAQgJAAgfgvg");
	this.shape_44.setTransform(228.3,301.625);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#9933CC").s().p("ACxE3QghgFiaAAIhkgBIhkAAQgPAAAAgMQAAgyAGhjQAFhiAAgwQAAgzgFiJIgFhpIgBgFQgBgKAMAAIBiABIBiACIBggCIBhgBQAWgBAEASQACAJAFA0QAEAzABALQgBAJgIAAIgJAAQh2gKhcAAQgXAAgGALQgCAGAAAcQAAAeAJAKQAIAIAVAAIAQgBIAVgBQA3AAA5gCIAZgCQAOgCAJAAQAKAAAAAJQAAgGgIBKQgDAiAAAjQAAAJgMAAIgogFQgZgChZAAIguAAQgSAAgDAJIgBAbQABAiAEAJQAIARAvADIBBAAQAXAAAugEQAugEAWgBQAKABAAAPQAAATgIAzQgIA3gFAKQgGAJgJAAIgNgBg");
	this.shape_45.setTransform(188.25,293.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#33CC99").s().p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	this.shape_46.setTransform(683,384);

	this.ibotonvolver3 = new lib.Volver3();
	this.ibotonvolver3.name = "ibotonvolver3";
	this.ibotonvolver3.setTransform(658.4,481.9);
	new cjs.ButtonHelper(this.ibotonvolver3, 0, 1, 2, false, new lib.Volver3(), 3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#9933CC").s().p("Ah+ENQhMgKgFgNQgBgGAAghQAAgTAFgfQAFgnAHAAIAIACQA0AbBEAAQBgAAAAg/QAAgjgjgSQgcgOgmAAQgQAAghAEQggAEgQAAQgQAAAAgOQAAgpAFhXQADhWAAgqQAAgJAHgJQAGgJAHgCQAKgBBxAAICqABQAMAAAAAKQAAAZgEArQgIA4gJAAIgFAAQhigJgZAAQgwAAgDAFQgIANAAAlQAAAFACAEQAMAAAXgDIAigCQBSAAA2AsQA6AuAABQQAADEjxAAQgjAAg7gHg");
	this.shape_47.setTransform(1136.7,297.325);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#9933CC").s().p("ADRDZQgOgDAAgSIACg9IABg9QAAhLgBghQgEg0gvAAQgUAAgVARQgUASgCAVQgCASAABZIACA/IABA/QAAAOgNAAIiEAAQgNAAAAgSIACg+IABg/IAAgwIgBgyQAAg+gxAAQgTAAgWAPQgZAQAAASIABB2IAAB3QAAAMgCADQgDACgLABQgUABgrAAQgbAAgkgCQgKgBgBgCQgDgDAAgLIABhoIAAhpQAAhIgKhaIgCgIQABgHAFgDQALgEAagDIAogDIAigJQAVgHANAAQAJAAAAAfQABAeADAAQAEgCAGgEQAngfAYgLQAhgQAoAAQAogBAfATQAkAUAKAkQAXgfApgWQApgVAnAAQA6AAAkAbQApAeAAA4IAABGIgCBFIACBTIAABTQAAAQgMACQgOABg0AAQg1AAgNgCg");
	this.shape_48.setTransform(969.95,302);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#9933CC").s().p("Ah4DYQgPgDAAgMIABhpIAAhoQABhogUhCIgBgHQAAgHAIgCIBGgKIBIgNQAGAAADAcQACAaAFABIABAAIgBAAQgDgBAogWQAqgXAnAAQAYAAAAALQAAANgCAXIgDAkIABAhIAAAiQAAASgSAAIgZgBIgYgBQglAAgNALQgNAMAAAhIABA6IABA5IABAmIACAlQAAALgPACQgTABgsAAQgqAAgZgCg");
	this.shape_49.setTransform(862,302.15);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#9933CC").s().p("AiQCpQhCg+AAhoQAAhkA7hBQA8hCBjAAQBVgBA7A+QA7A9AABWQAAArgcAGIhcAJQgzAHhnAHQAHAdAfAPQAZAMAgAAQAnAAAogVIAhgVQAJAEAXAoQAVApAAALQAAADgHAHQg2A6hwAAQhogBhAg8gAg1hcQgRAVAAAdQAAAMANAAQAgAABDgLQAPgCAAgEQAAgbgUgWQgTgUgaAAQgbAAgSAYg");
	this.shape_50.setTransform(544.3,302);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#9933CC").s().p("ABPDYQgNgDAAgPIABg/IACg/IgCgvIAAgxQAAg7g0AAQgRgBgXAPQgYARAAAQIAADsQAAAPgNACQgQABgvAAQg0AAgQgCQgNgCAAgMIABhoIAAhmQAAhugRg/IgBgGQAAgHAHgCIBJgKQBGgOAJAAQAFAAADAeQACAeAFAAQgFAAA1gfQAzgeAnAAQA3AAAlAaQAqAeABA2IAACMIAABVIAABWQAAALgMACQgNABg0AAQg3AAgNgCg");
	this.shape_51.setTransform(472.9,302.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#9933CC").s().p("AiQCpQhCg+AAhoQAAhkA7hBQA9hCBjAAQBUgBA7A+QA7A9AABWQAAArgdAGIhbAJQgzAHhnAHQAHAdAfAPQAZAMAgAAQAnAAAngVIAigVQAJAEAXAoQAVApAAALQAAADgHAHQg1A6hxAAQhogBhAg8gAg1hcQgRAVAAAdQAAAMANAAQAgAABEgLQAOgCAAgEQAAgbgUgWQgSgUgbAAQgbAAgSAYg");
	this.shape_52.setTransform(425.75,302);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#9933CC").s().p("AhrC+QgegwAAgLQAAgEAFgBIA+gLQAngMAAgdQgBgTgWgZIgpguQgXggAAgjQAAhCBDguQA7gpBEAAQAGAAAcAvQAcAvAAAIQAAAFgGAHQgNgDgNAAQgZAAgSALQgVAOAAAYQAAAPAXAYQAiAkAHALQAXAhAAAmQAAAXgJAZQgKAcgPAMQghAcgsAUQgtAUgoAAQgJAAgfgvg");
	this.shape_53.setTransform(233.9,301.625);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#9933CC").s().p("ACxE3QgggFibAAIhkgBIhkAAQgPAAAAgMQAAgyAGhjQAFhiAAgwQAAgzgFiJIgFhpIgBgFQAAgKAMAAIBhABIBiACIBggCIBhgBQAWgBAEASQACAJAFA0QAEAzAAALQABAJgKAAIgIAAQh2gKhcAAQgXAAgGALQgCAGAAAcQABAeAIAKQAHAIAWAAIAQgBIAVgBQA3AAA5gCIAZgCQAOgCAJAAQAKAAABAJQgBgGgHBKQgEAiAAAjQAAAJgMAAIgogFQgZgChZAAIguAAQgSAAgDAJIgBAbQABAiAEAJQAIARAvADIBAAAQAXAAAvgEQAugEAWgBQAKABAAAPQAAATgHAzQgIA3gHAKQgFAJgJAAIgNgBg");
	this.shape_54.setTransform(193.85,293.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#6699FF").s().p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	this.shape_55.setTransform(683,384);

	this.ibotonvolver4 = new lib.Volver4();
	this.ibotonvolver4.name = "ibotonvolver4";
	this.ibotonvolver4.setTransform(658.4,481.9);
	new cjs.ButtonHelper(this.ibotonvolver4, 0, 1, 2, false, new lib.Volver4(), 3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#9933CC").s().p("Ai7DCQhKhSAAhwQAAhyBKhQQBMhTBvAAQBwAABMBTQBKBQAAByQAABwhJBSQhNBUhwAAQhvAAhMhUgAhIhPQgaAgAAAvQAAAtAaAiQAcAkAsAAQArAAAdglQAbgjAAgrQAAgtgagiQgdgjgsAAQgsAAgcAjg");
	this.shape_56.setTransform(1145.8,297.25);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#9933CC").s().p("ACjEOQgogJhtAAQghAAhEAEQhEADggAAQgMABgBgLIgHgtQgLgsAAgIQAAgJAlgFQArgFAMgKQAtgmAug5QA7hHAAgkQAAgfgXgVQgVgWggAAQgjAAgjAOQgXAJgZARQgWANgCAAQgPAAAAgjQAAgbgCgMIgHgZQgFgOAAgIQAAgGAHgFQAlgaA9gPQA2gNA0AAQBSAAA5AkQBCAsAABPQAABqigCNQBxgGBBAAQANAAAAARQAAAKgCATIgCAgIgBAgIAAAiQAAALgPAAQgFAAgkgIg");
	this.shape_57.setTransform(1094.275,297.25);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#9933CC").s().p("ADRDZQgOgDAAgSIACg9IABg9QAAhLgBghQgEg0guAAQgVAAgVARQgUASgCAVQgCASAABZIACA/IABA/QAAAOgNAAIiEAAQgNAAAAgSIACg+IABg/IAAgwIgBgyQAAg+gxAAQgTAAgWAPQgZAQAAASIABB2IAAB3QAAAMgCADQgDACgLABQgUABgrAAQgbAAgkgCQgKgBgBgCQgDgDAAgLIABhoIAAhpQAAhIgKhaIgCgIQABgHAFgDQALgEAagDIAogDIAigJQAVgHANAAQAJAAAAAfQABAeADAAQAEgCAGgEQAngfAYgLQAhgQAoAAQAogBAfATQAkAUAKAkQAXgfApgWQApgVAnAAQA6AAAkAbQApAeAAA4IAABGIgCBFIACBTIAABTQABAQgNACQgOABg0AAQg1AAgNgCg");
	this.shape_58.setTransform(955.55,302);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#9933CC").s().p("Ah4DYQgPgDAAgMIABhpIAAhoQABhogUhCIgBgHQAAgHAIgCIBGgKIBIgNQAGAAADAcQACAaAFABIABAAIgBAAQgDgBAogWQAqgXAnAAQAYAAAAALQAAANgCAXIgDAkIABAhIAAAiQAAASgSAAIgZgBIgYgBQglAAgMALQgOAMAAAhIABA6IABA5IABAmIACAlQAAALgPACQgTABgsAAQgqAAgZgCg");
	this.shape_59.setTransform(847.6,302.15);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#9933CC").s().p("AhrC+QgegwAAgLQAAgEAFgBIA+gLQAngMAAgdQgBgTgWgZIgpguQgXggAAgjQAAhCBDguQA7gpBEAAQAGAAAcAvQAcAvAAAIQAAAFgHAHQgMgDgNAAQgZAAgSALQgVAOAAAYQAAAPAXAYQAiAkAHALQAXAhAAAmQAAAXgJAZQgKAcgPAMQghAcgsAUQgtAUgoAAQgJAAgfgvg");
	this.shape_60.setTransform(219.5,301.625);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#9933CC").s().p("ACwE3QgfgFibAAIhkgBIhkAAQgPAAAAgMQAAgyAGhjQAFhiAAgwQAAgzgFiJIgFhpIgBgFQAAgKAMAAIBhABIBiACIBggCIBhgBQAWgBAEASQACAJAFA0QAEAzAAALQABAJgJAAIgKAAQh1gKhcAAQgXAAgGALQgCAGAAAcQABAeAIAKQAHAIAWAAIAQgBIAVgBQA3AAA5gCIAZgCQAOgCAJAAQAKAAABAJQgBgGgHBKQgEAiAAAjQAAAJgMAAIgogFQgZgChZAAIguAAQgSAAgDAJIgBAbQABAiAEAJQAIARAvADIBAAAQAXAAAvgEQAugEAWgBQAKABAAAPQAAATgHAzQgIA3gHAKQgFAJgJAAIgOgBg");
	this.shape_61.setTransform(179.45,293.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FF99CC").s().p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	this.shape_62.setTransform(683,384);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33,p:{x:281.825}},{t:this.shape_32,p:{x:322.625}},{t:this.shape_31,p:{x:370.875}},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27,p:{x:592.9542}},{t:this.shape_26,p:{x:654.0491}},{t:this.shape_25,p:{x:701.925}},{t:this.shape_24,p:{x:742.725}},{t:this.shape_23,p:{x:783.525}},{t:this.shape_22,p:{x:832.025}},{t:this.shape_21},{t:this.shape_20,p:{x:918.625}},{t:this.shape_19},{t:this.shape_18,p:{x:1050.075}},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.ibotonvolver}]},4).to({state:[{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_33,p:{x:261.725}},{t:this.shape_32,p:{x:302.525}},{t:this.shape_31,p:{x:350.775}},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:538.7}},{t:this.shape_27,p:{x:572.8542}},{t:this.shape_26,p:{x:633.9491}},{t:this.shape_25,p:{x:681.825}},{t:this.shape_24,p:{x:722.625}},{t:this.shape_23,p:{x:763.425}},{t:this.shape_22,p:{x:811.925}},{t:this.shape_40},{t:this.shape_20,p:{x:898.525}},{t:this.shape_39},{t:this.shape_18,p:{x:1029.975}},{t:this.shape_38,p:{x:1092.125}},{t:this.shape_37},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.ibotonvolver2}]},5).to({state:[{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_33,p:{x:267.325}},{t:this.shape_32,p:{x:308.125}},{t:this.shape_31,p:{x:356.375}},{t:this.shape_52},{t:this.shape_51,p:{x:472.9}},{t:this.shape_50,p:{x:544.3}},{t:this.shape_27,p:{x:578.4542}},{t:this.shape_26,p:{x:639.5491}},{t:this.shape_25,p:{x:687.425}},{t:this.shape_24,p:{x:728.225}},{t:this.shape_23,p:{x:769.025}},{t:this.shape_22,p:{x:817.525}},{t:this.shape_49},{t:this.shape_20,p:{x:904.125}},{t:this.shape_48},{t:this.shape_18,p:{x:1035.575}},{t:this.shape_38,p:{x:1097.725}},{t:this.shape_47},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.ibotonvolver3}]},5).to({state:[{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_33,p:{x:252.925}},{t:this.shape_32,p:{x:293.725}},{t:this.shape_31,p:{x:341.975}},{t:this.shape_41,p:{x:411.35}},{t:this.shape_51,p:{x:458.5}},{t:this.shape_50,p:{x:529.9}},{t:this.shape_27,p:{x:564.0542}},{t:this.shape_26,p:{x:625.1491}},{t:this.shape_25,p:{x:673.025}},{t:this.shape_24,p:{x:713.825}},{t:this.shape_23,p:{x:754.625}},{t:this.shape_22,p:{x:803.125}},{t:this.shape_59},{t:this.shape_20,p:{x:889.725}},{t:this.shape_58},{t:this.shape_18,p:{x:1021.175}},{t:this.shape_57},{t:this.shape_56},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.ibotonvolver4}]},5).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1366,768);


(lib.mc_escenario1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.iboton1.on("click", contenido.bind(this));
		
		function contenido(e){
			var variable1 = 15;
			this.parent.cambiarEscenario(new lib.mc_escenario2(),5);
			//var variable1 = 15;
		}
		
		this.iboton2.on("click", contenido2.bind(this));
		
		function contenido2(e){
			this.parent.cambiarEscenario(new lib.mc_escenario2(),"fotograma10");
			//root.mc_escenario2.gotoAndStop(10);
			//mc_escenario2.parent.gotoAndPlay("fotograma10");
			
		}
		
		this.iboton3.on("click", contenido3.bind(this));
		
		function contenido3(e){
			this.parent.cambiarEscenario(new lib.mc_escenario2(),14);
			//root.mc_escenario2.gotoAndStop(10);
			//mc_escenario2.parent.gotoAndPlay("fotograma10");
			
		}
		
		this.iboton4.on("click", contenido4.bind(this));
		
		function contenido4(e){
			this.parent.cambiarEscenario(new lib.mc_escenario2(),19);
			//root.mc_escenario2.gotoAndStop(10);
			//mc_escenario2.parent.gotoAndPlay("fotograma10");
			
		}
		
		this.iboton5.on("click", contenido5.bind(this));
		
		function contenido5(e){
			this.parent.cambiarEscenario(new lib.mc_escenario6(),0);
			//root.mc_escenario2.gotoAndStop(10);
			//mc_escenario2.parent.gotoAndPlay("fotograma10");
			
		}
		
		this.iboton7.on("click", contenido7.bind(this));
		
		function contenido7(e){
			this.parent.cambiarEscenario(new lib.mc_escenario5(),0);
			//root.mc_escenario2.gotoAndStop(10);
			//mc_escenario2.parent.gotoAndPlay("fotograma10");
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Capa_1
	this.iboton7 = new lib.boton7();
	this.iboton7.name = "iboton7";
	this.iboton7.setTransform(1057.9,587.65);
	new cjs.ButtonHelper(this.iboton7, 0, 1, 2, false, new lib.boton7(), 3);

	this.iboton5 = new lib.boton5();
	this.iboton5.name = "iboton5";
	this.iboton5.setTransform(667.4,572.55);
	new cjs.ButtonHelper(this.iboton5, 0, 1, 2, false, new lib.boton5(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9933CC").s().p("AifCjQg+g+AAhgQAAhmA8g+QA8hBBlAAQBjAAA9A/QA+A+AABjQAABkg9A+Qg+A/hjgBQhgABg/g+gAg4g8QgVAZAAAjQAAAjAVAZQAXAbAhAAQAjAAAWgbQAVgZAAgjQAAgigWgbQgVgagjAAQghAAgXAbg");
	this.shape.setTransform(851.575,219.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9933CC").s().p("Ai8D/Qg2g+AAhfQAAhgA0g8QA4hDBeAAQBBABAlAqQAGAHADAAQAEAAAAgLIgChmIgBhlQAAgMAGgCQAcgBAygEQBWgLgIAAQAIAAABAJQgBgCgDAhQgEAwgDBMQgDBXgBBtQAAC1ALBNIAAALQAAAEgGABQgQADhkAAQgYgBgDgIIgDgiQAAgEgDgDIgHAFQgvAvhGAAQhdAAg3hBgAg9AiQgWAaAAAkQAAAkAWAZQAWAaAjAAQAiAAAYgaQAXgaAAgkQAAgjgXgaQgZgaghAAQgkAAgVAagADqk/IAAAAIAAAAg");
	this.shape_1.setTransform(800.65,209.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9933CC").s().p("ABPDYQgNgDAAgPIABg+IABg/IgBgwIAAgxQAAg7g1gBQgPAAgYAPQgYARAAARIAADrQAAAPgNACQgQACgvgBQg0ABgQgDQgNgCAAgNIABhnIAAhnQAAhtgRg/IgBgGQAAgHAHgDIBKgJQBFgOAJAAQAFAAACAeQADAdAFAAQgFABA1gfQAygeAoAAQA3AAAlAZQArAfAAA2IAACLIAABWIAABVQAAAMgMACQgNACg0gBQg3ABgNgDg");
	this.shape_2.setTransform(748.65,219);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#9933CC").s().p("ABNDRQgJgCgCgJIgDgaQgCgTgDgBIgBAAIABAAQADABgwAdQgyAdgpAAQh1AAgVhoQgKgyAAhbQAAhkARg7QAEgSAOAAIA9ABIA+AAQANAAAAAMIgBAJQgJA8AAA9QAABMAFAcQAIAxAygBQASABAXgSQAWgRABgTIABjbQAAgOACgDQADgFANAAIBBABIBBABQANgBACAHIABAKQAAAhgDBBQgDBBAAAfIACBgQACA/AAAfQAAAMgLADQgRAFg2gBQgwAAgSgCg");
	this.shape_3.setTransform(697.475,219.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#9933CC").s().p("ADRDZQgNgCgBgUIABg7IACg+QAAhLgCghQgDg0guAAQgVAAgVARQgUASgCAUQgCATAABZIACA+IABA/QAAAPgNAAIiEAAQgNAAAAgSIACg+IABg/IgBgwIgBgyQAAg+gvAAQgUAAgWAPQgZAQAAASIABB3IAAB2QAAALgDAEQgCACgLABQgUACgqgBQgdABgigDQgLgBgBgCQgDgCAAgMIAAhpIABhoQAAhIgLhaIgBgIQAAgHAHgDQAKgEAagCIAngFIAjgJQAVgGAOAAQAIAAABAfQAAAeADAAQAEgBAGgFQAogeAWgMQAjgRAnAAQApAAAeASQAkAVAKAlQAYghApgVQAogVAngBQA6AAAkAbQAqAfAAA4IgBBHIgCBEIACBUIABBSQAAAQgOACQgNACg0gBQg1ABgNgDg");
	this.shape_4.setTransform(631.25,218.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#9933CC").s().p("AhEEzQgKgCgBgKIAAgTIABh1IABh1IAAinQgBhhgKhHIAAgHQAAgKALAAICcAAQALAAgBAKIgBAHQgLC/AACQIABC5IABAjIACAiQAAAJgLACQgUAEgzgBQg0ABgPgEg");
	this.shape_5.setTransform(558.1042,209.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9933CC").s().p("AiQCoQhCg+AAhnQAAhkA7hAQA9hDBigBQBVAAA7A+QA7A9AABVQAAAsgdAGIhbAKQg0AFhmAIQAHAdAfAOQAZANAgAAQAnAAAngVIAigVQAJAEAXAoQAVApAAALQAAADgHAHQg2A6hwgBQhoABhAg+gAg1hdQgRAWAAAdQAAALANAAQAgABBEgLQAOgBAAgGQAAgagUgVQgSgVgbAAQgbAAgSAXg");
	this.shape_6.setTransform(523.95,218.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9933CC").s().p("ABPDYQgNgCAAgQIABg/IABg/IgBgwIAAgvQAAg9g1AAQgQABgWAPQgZAQAAAQIAADtQAAAOgOACQgPACgwAAQgzAAgQgDQgNgCAAgMIABhoIAAhmQAAhugRg+IgBgHQAAgHAGgCIBKgKQBGgOAJAAQAFAAACAeQADAdAFABQgFgBA0geQAzgeAngBQA4AAAmAaQApAfAAA2IAACMIAABVIABBVQAAAMgMACQgMACg0AAQg3AAgOgDg");
	this.shape_7.setTransform(1206.45,116);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#9933CC").s().p("AiQCoQhCg+AAhnQAAhkA7hBQA8hDBkABQBUAAA7A9QA7A+AABVQAAArgcAGIhbAKQg1AFhmAIQAHAdAfAPQAZAMAgAAQAnAAAogVIAhgVQAJAEAWApQAWAoAAALQAAADgHAHQg1A5hyABQhnAAhAg+gAg1hcQgRAVAAAdQAAAMAMAAQAhgBBDgJQAPgCAAgFQAAgcgTgUQgUgVgZAAQgcAAgSAYg");
	this.shape_8.setTransform(1159.3,115.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9933CC").s().p("Ai4CcQg1hAAAhXQAAhlA3g+QA5hABkAAQBEAAAoAwQAAABAAAAQABABAAAAQABAAAAAAQAAAAABAAQAEAAAFgVQAFgVAHAAQAQAAAuAJQArAJATAGQAHADAAAEIgCAJQgOBQAABZQAAAgAEBDQAEBDAAAhQAAASgPABQg3AEhGAAQgIAAgDgZQgDgZgEgBQgEACgFAGQgxAxg4AAQhVAAg5hDgAhAhBQgXAYAAAmQAAAjAYAZQAZAaAjAAQAkAAAYgYQAYgZAAglQAAglgYgYQgXgZglAAQgmAAgXAYg");
	this.shape_9.setTransform(1086.675,116.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#9933CC").s().p("Ai9D+Qg1g9AAheQAAhgA0g+QA4hCBeAAQBBABAlAqQAGAHADAAQAEAAAAgMIgChlIgChkQAAgNAHgCQAdgBAwgEQBWgLgHAAQAIAAABAJQgBgCgCAhQgFAxgDBMQgEBWABBsQgBC2ALBNIABAKQgBAGgGAAQgQAChlAAQgXABgEgKIgBghQgBgEgDgDIgGAFQgwAvhGAAQhdAAg4hCgAg9AiQgWAaAAAlQAAAjAWAYQAVAbAkAAQAiAAAYgbQAYgZAAgkQAAgjgZgaQgYgaghAAQgkAAgVAagADqk/IAAAAIAAAAg");
	this.shape_10.setTransform(1033.9,106.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#9933CC").s().p("AhCEtQgKgCgCgDQgBgCAAgMIAChbIABhcQAAh8gKhJIgBgJQAAgKAMABQAMAAAaACQAZADAMAAQAMAAAagDIAmgCQALAAAAAJIgBAJQgKBWAABvIACBgIABBfQAAAJgLACQgPADg0AAQg0AAgPgDgAg7ipQgagVAAgkQAAgiAbgXQAZgTAigBQAjAAAZAVQAbAWAAAiQAABMhXAAQgjAAgZgTg");
	this.shape_11.setTransform(995.525,107.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#9933CC").s().p("Ag2DQQgKgDgGgGQgagdgxhGQg0hNgKgbQgLgeAAg9IAAgzIABg0QAAgMAPAAIBEACIBDABQAKAAAAANIgCAmIgBAlQAAAuACAdQACAPAYAoQAZAsAKAAQALAAAYgrQAYgnABgPQAEgeAAgtQAAgNgDgaQgCgZAAgNQAAgNAJAAIAfAAIAgABIAggCIAfgCQALAAAEAMQAHAZAABMQAABMgEAOQgLAegyBKQgsBAgfAlQgMANg5AAQgxAAgPgDg");
	this.shape_12.setTransform(958.975,116.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#9933CC").s().p("Ai4CcQg1hAAAhXQAAhlA3g+QA5hABkAAQBEAAAoAwQAAABAAAAQABABAAAAQABAAAAAAQAAAAABAAQAEAAAFgVQAFgVAHAAQAQAAAuAJQArAJATAGQAHADAAAEIgCAJQgOBQAABZQAAAgAEBDQAEBDAAAhQAAASgPABQg3AEhGAAQgIAAgDgZQgDgZgEgBQgEACgFAGQgxAxg4AAQhVAAg5hDgAhAhBQgXAYAAAmQAAAjAYAZQAZAaAjAAQAkAAAYgYQAYgZAAglQAAglgYgYQgXgZglAAQgmAAgXAYg");
	this.shape_13.setTransform(885.175,116.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#9933CC").s().p("AhEEzQgKgCgBgKIAAgTIABh1IABh0IAAioQgBhhgKhGIAAgIQAAgJALAAICcAAQALAAgBAJIgBAIQgLC9AACSIABC3IABAjIACAjQAAAJgLACQgUADgzABQg0gBgPgDg");
	this.shape_14.setTransform(847.4542,106.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9933CC").s().p("AiQCoQhCg+AAhnQAAhkA7hBQA9hDBiABQBVAAA7A9QA7A+AABVQAAArgdAGIhbAKQg0AFhmAIQAHAdAfAPQAZAMAgAAQAnAAAngVIAigVQAJAEAXApQAVAoAAALQAAADgHAHQg2A5hwABQhoAAhAg+gAg1hcQgRAVAAAdQAAAMANAAQAggBBEgJQAOgCAAgFQAAgcgUgUQgSgVgbAAQgbAAgSAYg");
	this.shape_15.setTransform(790.8,115.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#9933CC").s().p("Ai8D+Qg2g9AAheQAAhgA0g+QA4hCBeAAQBBABAlAqQAGAHADAAQAEAAAAgMIgChlIgBhkQAAgNAGgCQAcgBAygEQBVgLgHAAQAIAAABAJQgBgCgDAhQgEAxgDBMQgDBWgBBsQAAC2ALBNIAAAKQAAAGgGAAQgQAChkAAQgYABgDgKIgDghQAAgEgDgDIgHAFQgvAvhGAAQhdAAg3hCgAg9AiQgWAaAAAlQAAAjAWAYQAWAbAjAAQAiAAAYgbQAYgZgBgkQAAgjgXgaQgZgaghAAQgkAAgVAagADqk/IAAAAIAAAAg");
	this.shape_16.setTransform(740.8,106.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#9933CC").s().p("AhqC+QgfgwAAgLQAAgEAFgBIA+gLQAngMAAgdQAAgTgXgZIgpguQgXggAAgjQAAhCBDguQA6gpBFAAQAGAAAcAvQAcAvAAAIQAAAFgHAHQgMgDgNAAQgZAAgSALQgVAOAAAYQAAAPAXAYQAiAkAHALQAXAhAAAmQAAAXgJAZQgKAcgQAMQggAcgrAUQgvAUgnAAQgJAAgegvg");
	this.shape_17.setTransform(675.9,115.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#9933CC").s().p("AiQCoQhCg+AAhnQAAhkA7hBQA9hDBiABQBVAAA7A9QA7A+AABVQAAArgcAGIhbAKQg0AFhnAIQAHAdAfAPQAZAMAgAAQAnAAAogVIAhgVQAJAEAWApQAWAoAAALQAAADgHAHQg2A5hxABQhnAAhAg+gAg1hcQgRAVAAAdQAAAMAMAAQAhgBBDgJQAPgCAAgFQAAgcgTgUQgUgVgZAAQgcAAgSAYg");
	this.shape_18.setTransform(638.1,115.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#9933CC").s().p("ABPDYQgNgCAAgQIACg/IABg/IgBgwIgBgvQAAg9g0AAQgRABgXAPQgYAQAAAQIAADtQAAAOgOACQgPACgwAAQgzAAgPgDQgOgCAAgMIAAhoIABhmQAAhugRg+IgBgHQAAgHAHgCIBJgKQBGgOAJAAQAFAAADAeQACAdAFABQgFgBA1geQAzgeAmgBQA4AAAlAaQAqAfAAA2IAACMIAABVIABBVQAAAMgMACQgNACgzAAQg4AAgNgDg");
	this.shape_19.setTransform(589.2,116);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#9933CC").s().p("AifCjQg+g+AAhhQAAhkA8hAQA8hABlAAQBjABA9A+QA+A+AABjQAABjg9A/Qg+A/hjAAQhggBg/g9gAg4g9QgVAaAAAjQAAAjAVAaQAXAbAhAAQAjAAAWgbQAVgaAAgjQAAgjgWgaQgVgagjgBQghAAgXAbg");
	this.shape_20.setTransform(540.425,116.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#9933CC").s().p("AhCEtQgKgCgCgDQgBgCAAgMIAChbIABhcQAAh8gKhJIgBgJQAAgKAMABQAMAAAaACQAZADAMAAQAMAAAagDIAmgCQALAAAAAJIgBAJQgKBWAABvIACBgIABBfQAAAJgLACQgPADg0AAQg0AAgPgDgAg7ipQgagVAAgkQAAgiAbgXQAZgTAigBQAjAAAZAVQAbAWAAAiQAABMhXAAQgjAAgZgTg");
	this.shape_21.setTransform(504.225,107.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#9933CC").s().p("AhvCjQg+hCAAhgQAAhgA/hBQA/hCBfAAQBBAAAyAcQALAGAAAFQAAAGgNAvQgMAsgEAJQgEAKgDAAIgbgHQgagIgQAAQgoABgXAXQgWAYAAAmQAAAoAYAXQAaAXApAAQATAAAYgKIAXgKQAIAAALA4QAKAzAAARQAAAQg2AMQgqAKgagBQhgABg/hBg");
	this.shape_22.setTransform(473.475,115.95);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#9933CC").s().p("Ai4CcQg1hAAAhXQAAhlA3g+QA5hABkAAQBEAAAoAwQAAABAAAAQABABAAAAQABAAAAAAQAAAAABAAQAEAAAFgVQAFgVAHAAQAQAAAuAJQArAJATAGQAHADAAAEIgCAJQgOBQAABZQAAAgAEBDQAEBDAAAhQAAASgPABQg3AEhGAAQgIAAgDgZQgDgZgEgBQgEACgFAGQgxAxg4AAQhVAAg5hDgAhAhBQgXAYAAAmQAAAjAYAZQAZAaAjAAQAkAAAYgYQAYgZAAglQAAglgYgYQgXgZglAAQgmAAgXAYg");
	this.shape_23.setTransform(427.175,116.275);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#9933CC").s().p("Ah4DYQgOgCAAgNIAAhpIABhoQgBhogShDIgBgGQAAgHAGgCIBHgKIBHgNQAIAAACAcQACAaAFABIAAAAIAAAAQgEgBAogWQArgXAnAAQAZAAgBALQAAAMgCAYIgDAkIAAAiIABAhQAAASgTAAIgYgBIgYgCQgkAAgNAMQgOALAAAiIABA6IAAA5IACAmIACAmQAAAKgOABQgUACgsAAQgqAAgZgCg");
	this.shape_24.setTransform(385.05,116.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#9933CC").s().p("Ag+EZQgDgDgDAAQgEAAgEAQQgDARgGABQgHADh2AAQgbAAgBgLIABgGQAJhGAAjEQAAi7gNiLIAAgFQAAgHANgBIBNgGQAvgFAdAAQAIAAAAAPIgBAtIgEAuQgCArAABLQAAAOAHAAQAEAAADgDQAngrA/AAQBhAAA1BCQAzA8AABiQAABdg1A+Qg4BChbAAQhBAAgogmgAg2AgQgWAZAAAlQAAAnAVAYQAWAZAkAAQAmAAAWgaQAVgYgBgmQABglgXgZQgWgZgkAAQgkAAgVAZg");
	this.shape_25.setTransform(341.3,106.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#9933CC").s().p("AiQCoQhCg+AAhnQAAhkA7hBQA9hDBiABQBVAAA7A9QA7A+AABVQAAArgcAGIhbAKQg0AFhnAIQAHAdAfAPQAZAMAgAAQAnAAAogVIAhgVQAJAEAXApQAVAoAAALQAAADgHAHQg2A5hxABQhnAAhAg+gAg1hcQgRAVAAAdQAAAMAMAAQAhgBBDgJQAPgCAAgFQAAgcgTgUQgUgVgZAAQgcAAgSAYg");
	this.shape_26.setTransform(292.05,115.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#9933CC").s().p("AhEEzQgKgCgBgKIAAgTIABh1IABh0IAAioQgBhhgKhGIAAgIQAAgJALAAICcAAQALAAgBAJIgBAIQgLC9AACSIABC3IABAjIACAjQAAAJgLACQgUADgzABQg0gBgPgDg");
	this.shape_27.setTransform(257.1042,106.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#9933CC").s().p("AiQCoQhCg+AAhnQAAhkA7hBQA8hDBkABQBUAAA7A9QA7A+AABVQAAArgdAGIhaAKQg1AFhlAIQAGAdAfAPQAZAMAgAAQAnAAAogVIAhgVQAKAEAVApQAWAoAAALQAAADgHAHQg1A5hyABQhnAAhAg+gAg1hcQgRAVAAAdQAAAMAMAAQAhgBBDgJQAPgCAAgFQAAgcgTgUQgUgVgZAAQgcAAgSAYg");
	this.shape_28.setTransform(222.95,115.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#9933CC").s().p("Ai1DmQhThbAAiKQAAiFBShdQBVhhCBAAQCPAABRBXQAJAKAAAHQAAAJgfA1QgfA2gHAGQgEAEgFAAQgCAAgUgSQgYgVgXgMQgjgRglAAQg/AAgnAwQgkAtAABCQAABCAkAtQAnAxA/AAQAmAAAjgQQAWgLAXgUQAUgRACAAQAEAAAFAFQAHAIAfAvQAgAxAAAEQAAAHgJAMQhRBgiGAAQiIAAhWhdg");
	this.shape_29.setTransform(172.875,106.825);

	this.iboton4 = new lib.boton4();
	this.iboton4.name = "iboton4";
	this.iboton4.setTransform(1170.05,437.1);
	new cjs.ButtonHelper(this.iboton4, 0, 1, 2, false, new lib.boton4(), 3);

	this.iboton3 = new lib.boton3();
	this.iboton3.name = "iboton3";
	this.iboton3.setTransform(851.55,437.1);
	new cjs.ButtonHelper(this.iboton3, 0, 1, 2, false, new lib.boton3(), 3);

	this.iboton2 = new lib.boton2();
	this.iboton2.name = "iboton2";
	this.iboton2.setTransform(535.55,437.1);
	new cjs.ButtonHelper(this.iboton2, 0, 1, 2, false, new lib.boton2(), 3);

	this.iboton1 = new lib.boton1();
	this.iboton1.name = "iboton1";
	this.iboton1.setTransform(226.6,437.1);
	new cjs.ButtonHelper(this.iboton1, 0, 1, 2, false, new lib.boton1(), 3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FF0000").s().p("AmPB8IAAj3IMfAAIAAD3g");
	this.shape_30.setTransform(677.55,651.525);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#CCCCCC").s().p("EhqtA2EMAAAhsHMDVbAAAMAAABsHgEgHFAnxIAAD3IAADwIMfAAIAAjwIAAj3IAAgJIsfAAg");
	this.shape_31.setTransform(683,384.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.iboton1},{t:this.iboton2},{t:this.iboton3},{t:this.iboton4},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.iboton5},{t:this.iboton7}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mc_escenario1, new cjs.Rectangle(0,38.7,1366,692), null);


(lib.LetrasPeru = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// p
	this.instance = new lib.PeruP("synched",0);
	this.instance.setTransform(-39.3,81.55,0.1001,0.1001,-49.4432,0,0,-1.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,scaleX:0.9999,scaleY:0.9999,rotation:-5.6644,x:-12.15,y:75.4},4).wait(16));

	// e
	this.instance_1 = new lib.PeruE("synched",0);
	this.instance_1.setTransform(-36.5,81.15,0.1001,0.1001,-31.2243,0,0,-0.5,-0.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.9999,scaleY:0.9999,rotation:8.9845,x:17.8,y:90.55},4).wait(11));

	// r
	this.instance_2 = new lib.PeruR("synched",0);
	this.instance_2.setTransform(-34,81.15,0.1001,0.1001,-26.0028,0,0,-0.7,0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({_off:false},0).to({regX:0.2,regY:0.1,scaleX:1,scaleY:1,rotation:16.9545,x:48.3,y:116.75},4).wait(6));

	// u
	this.instance_3 = new lib.PeruU("synched",0);
	this.instance_3.setTransform(-31.1,81.9,0.1001,0.1001,-4.4396,0,0,-0.5,-0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(15).to({_off:false},0).to({regX:0.1,regY:0,scaleX:0.9999,scaleY:0.9999,rotation:34.5029,x:60.3,y:128.45},4).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.1,39.2,141.1,125.89999999999999);


(lib.LetrasParaguay = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_39 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(39).call(this.frame_39).wait(1));

	// p
	this.instance = new lib.ParaguayP("synched",0);
	this.instance.setTransform(-39.3,81.55,0.1001,0.1001,25.5576,0,0,-0.9,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,regY:0.3,scaleX:0.9999,scaleY:0.9999,rotation:22.2864,x:-24.05,y:81.3},4).wait(36));

	// a
	this.instance_1 = new lib.ParaguayA("synched",0);
	this.instance_1.setTransform(-36.5,81.05,0.1001,0.1001,36.5172,0,0,-0.3,-0.4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({regX:0.2,regY:0.1,scaleX:0.9999,scaleY:0.9999,rotation:4.4566,x:3.9,y:94},4).wait(31));

	// r
	this.instance_2 = new lib.ParaguayR("synched",0);
	this.instance_2.setTransform(-34,81.2,0.1001,0.1001,33.9976,0,0,-0.6,1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({_off:false},0).to({regX:0.2,regY:0.1,scaleX:0.9999,scaleY:0.9999,rotation:-0.2606,x:38.15,y:115.6},4).wait(26));

	// a
	this.instance_3 = new lib.ParaguayA2("synched",0);
	this.instance_3.setTransform(-31.15,81.9,0.1001,0.1001,34.5328,0,0,-0.8,0.6);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(15).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.9999,scaleY:0.9999,rotation:-21.2132,x:53.4,y:117.3},4).wait(21));

	// g
	this.instance_4 = new lib.ParaguayG("synched",0);
	this.instance_4.setTransform(-29.3,83.05,0.1001,0.1001,25.5459,0,0,0,1.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(20).to({_off:false},0).to({regX:0.5,regY:0,scaleX:0.9998,scaleY:0.9998,rotation:-38.2228,x:83.95,y:121.85},4).wait(16));

	// u
	this.instance_5 = new lib.ParaguayU("synched",0);
	this.instance_5.setTransform(-27.8,84.25,0.1001,0.1001,25.5538);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({regX:0.3,scaleX:0.9999,scaleY:0.9999,rotation:-48.9143,x:114.1,y:115.25},4).wait(11));

	// a
	this.instance_6 = new lib.ParaguayA3("synched",0);
	this.instance_6.setTransform(-27.8,84.25,0.1001,0.1001,25.5538);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(30).to({_off:false},0).to({regX:0.4,scaleX:0.9999,scaleY:0.9999,rotation:-66.243,x:143.05,y:106},4).wait(6));

	// y
	this.instance_7 = new lib.ParaguayY("synched",0);
	this.instance_7.setTransform(-27.8,84.25,0.1001,0.1001,25.5538);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(35).to({_off:false},0).to({regX:0.3,regY:-0.1,scaleX:0.9998,scaleY:0.9998,rotation:-77.2635,x:168,y:85.2},4).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.1,46.1,268.1,108.20000000000002);


(lib.LetrasCuba = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// c
	this.instance = new lib.CubaC("synched",0);
	this.instance.setTransform(-39.3,81.55,0.1001,0.1001,-49.4432,0,0,-1.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,scaleX:0.9999,scaleY:0.9999,rotation:-5.6644,x:-12.15,y:75.4},4).wait(16));

	// u
	this.instance_1 = new lib.CubaU("synched",0);
	this.instance_1.setTransform(-36.5,81.15,0.1001,0.1001,-31.2243,0,0,-0.5,-0.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.9999,scaleY:0.9999,rotation:8.9845,x:17.8,y:90.55},4).wait(11));

	// b
	this.instance_2 = new lib.CubaB("synched",0);
	this.instance_2.setTransform(-34,81.15,0.1001,0.1001,-26.0028,0,0,-0.7,0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({_off:false},0).to({regX:0.2,regY:0.1,scaleX:1,scaleY:1,rotation:16.9545,x:48.3,y:116.75},4).to({scaleX:0.9999,scaleY:0.9999,rotation:19.4464,y:117.6},5).wait(1));

	// a
	this.instance_3 = new lib.CubaA("synched",0);
	this.instance_3.setTransform(-31.1,81.9,0.1001,0.1001,-4.4396,0,0,-0.5,-0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(15).to({_off:false},0).to({regX:0.1,scaleX:0.9999,scaleY:0.9999,rotation:44.9963,x:63.3,y:140.25},4).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.1,39.2,141.8,134.2);


(lib.LetrasColombia = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_39 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(39).call(this.frame_39).wait(1));

	// C
	this.instance = new lib.ColombiaC("synched",0);
	this.instance.setTransform(-39.3,81.55,0.1001,0.1001,-49.4432,0,0,-1.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,scaleX:0.9999,scaleY:0.9999,rotation:-5.6644,x:-12.15,y:75.4},4).wait(36));

	// o
	this.instance_1 = new lib.ColombiaO("synched",0);
	this.instance_1.setTransform(-36.5,81.15,0.1001,0.1001,-31.2243,0,0,-0.5,-0.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.9999,scaleY:0.9999,rotation:8.9845,x:17.8,y:90.55},4).wait(31));

	// l
	this.instance_2 = new lib.ColombiaL("synched",0);
	this.instance_2.setTransform(-34,81.15,0.1001,0.1001,-26.0028,0,0,-0.7,0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({_off:false},0).to({regX:0.2,regY:0.1,scaleX:1,scaleY:1,rotation:16.9545,x:48.3,y:116.75},4).wait(26));

	// o
	this.instance_3 = new lib.ColombiaO2("synched",0);
	this.instance_3.setTransform(-31.1,81.9,0.1001,0.1001,-4.4396,0,0,-0.5,-0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(15).to({_off:false},0).to({regX:0.1,regY:0,scaleX:0.9999,scaleY:0.9999,rotation:34.5029,x:60.3,y:128.45},4).wait(21));

	// m
	this.instance_4 = new lib.ColombiaM("synched",0);
	this.instance_4.setTransform(-29.25,83.05,0.1001,0.1001,10.5532,0,0,0.2,1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(20).to({_off:false},0).to({regX:0.5,regY:-0.1,scaleX:0.9998,scaleY:0.9998,rotation:40.7806,x:75.15,y:157},4).wait(16));

	// b
	this.instance_5 = new lib.ColombiaB("synched",0);
	this.instance_5.setTransform(-27.8,84.25,0.1001,0.1001,25.5538);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({regX:0.3,regY:-0.1,scaleX:0.9999,scaleY:0.9999,rotation:59.4676,x:89.05,y:212.7},4).to({rotation:59.4676},5).wait(6));

	// i
	this.instance_6 = new lib.ColombiaI("synched",0);
	this.instance_6.setTransform(-27.8,84.25,0.1001,0.1001,25.5538);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(30).to({_off:false},0).to({regX:0.4,regY:-0.1,scaleX:0.9999,scaleY:0.9999,rotation:74.4673,x:86.3,y:252},4).wait(6));

	// a
	this.instance_7 = new lib.ColombiaA("synched",0);
	this.instance_7.setTransform(-27.8,84.25,0.1001,0.1001,25.5538);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(35).to({_off:false},0).to({regX:0.4,regY:-0.2,scaleX:0.9999,scaleY:0.9999,rotation:89.4675,x:79.8,y:278.7},4).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.1,39.2,162.3,278.3);


(lib.LetrasBrasil = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_29 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(29).call(this.frame_29).wait(1));

	// B
	this.instance = new lib.BrasilB("synched",0);
	this.instance.setTransform(-39.3,81.55,0.1001,0.1001,-49.4432,0,0,-1.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.2,scaleX:0.9999,scaleY:0.9999,rotation:-5.6644,x:-12.05,y:75.4},4).wait(26));

	// r
	this.instance_1 = new lib.BrasilR("synched",0);
	this.instance_1.setTransform(-36.5,81.15,0.1001,0.1001,-31.2243,0,0,-0.5,-0.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.9999,scaleY:0.9999,rotation:8.9845,x:14.35,y:92.05},4).wait(21));

	// a
	this.instance_2 = new lib.BrasilA("synched",0);
	this.instance_2.setTransform(-34,81.15,0.1001,0.1001,-26.0028,0,0,-0.7,0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.9999,scaleY:0.9999,rotation:22.9035,x:37.45,y:114},4).wait(16));

	// s
	this.instance_3 = new lib.BrasilS("synched",0);
	this.instance_3.setTransform(-31.1,81.9,0.1001,0.1001,-4.4396,0,0,-0.5,-0.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(15).to({_off:false},0).to({regX:0.1,regY:0,scaleX:0.9999,scaleY:0.9999,rotation:34.5029,x:53.05,y:142.9},4).wait(11));

	// i
	this.instance_4 = new lib.BrasilI("synched",0);
	this.instance_4.setTransform(-29.25,83.05,0.1001,0.1001,10.5532,0,0,0.2,1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(20).to({_off:false},0).to({regX:0.4,regY:-0.1,scaleX:0.9999,scaleY:0.9999,rotation:44.7737,x:62.2,y:169.65},4).wait(6));

	// l
	this.instance_5 = new lib.BrasilL("synched",0);
	this.instance_5.setTransform(-27.8,84.25,0.1001,0.1001,25.5538);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({regX:0.3,regY:-0.1,scaleX:0.9999,scaleY:0.9999,rotation:59.4676,x:68.05,y:199},4).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.1,39.2,141.2,170.7);


(lib.Fondo5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Símbolo2();
	this.instance.setTransform(243,110.8,1,1,0,0,0,243,110.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:110.7,x:248,y:110.7},0).wait(1).to({x:253},0).wait(1).to({x:258},0).wait(1).to({x:263},0).wait(1).to({x:267},0).wait(1).to({x:271},0).wait(1).to({x:275},0).wait(1).to({x:279},0).wait(1).to({x:283},0).wait(1).to({x:287},0).wait(1).to({x:291},0).wait(1).to({x:295},0).wait(1).to({x:299},0).wait(1).to({x:303},0).wait(1).to({x:307},0).wait(1).to({x:311},0).wait(1).to({x:315},0).wait(1).to({x:319},0).wait(1).to({x:323},0).wait(1).to({x:327},0).wait(1).to({x:331},0).wait(1).to({x:335},0).wait(1).to({x:339},0).wait(1).to({x:343},0).wait(1).to({x:347},0).wait(1).to({x:351},0).wait(1).to({x:355},0).wait(1).to({x:359},0).wait(1).to({x:363},0).wait(1).to({x:367},0).wait(1).to({x:371},0).wait(1).to({x:375},0).wait(1).to({x:379},0).wait(1).to({x:383},0).wait(1).to({x:387},0).wait(1).to({x:391},0).wait(1).to({x:395},0).wait(1).to({x:399},0).wait(1).to({x:403},0).wait(1).to({x:407},0).wait(1).to({x:411},0).wait(1).to({x:415},0).wait(1).to({x:419},0).wait(1).to({x:423},0).wait(1).to({x:427},0).wait(1).to({x:431},0).wait(1).to({x:435},0).wait(1).to({x:439},0).wait(1).to({x:443},0).wait(1).to({x:439},0).wait(1).to({x:435},0).wait(1).to({x:431},0).wait(1).to({x:427},0).wait(1).to({x:423},0).wait(1).to({x:419},0).wait(1).to({x:415},0).wait(1).to({x:411},0).wait(1).to({x:407},0).wait(1).to({x:403},0).wait(1).to({x:399},0).wait(1).to({x:395},0).wait(1).to({x:391},0).wait(1).to({x:387},0).wait(1).to({x:383},0).wait(1).to({x:379},0).wait(1).to({x:375},0).wait(1).to({x:371},0).wait(1).to({x:367},0).wait(1).to({x:363},0).wait(1).to({x:359},0).wait(1).to({x:355},0).wait(1).to({x:351},0).wait(1).to({x:347},0).wait(1).to({x:343},0).wait(1).to({x:339},0).wait(1).to({x:335},0).wait(1).to({x:331},0).wait(1).to({x:327},0).wait(1).to({x:323},0).wait(1).to({x:319},0).wait(1).to({x:315},0).wait(1).to({x:311},0).wait(1).to({x:307},0).wait(1).to({x:303},0).wait(1).to({x:299},0).wait(1).to({x:295},0).wait(1).to({x:291},0).wait(1).to({x:287},0).wait(1).to({x:283},0).wait(1).to({x:279},0).wait(1).to({x:275},0).wait(1).to({x:271},0).wait(1).to({x:267},0).wait(1).to({x:263},0).wait(1).to({x:259},0).wait(1).to({x:255},0).wait(1).to({x:251},0).wait(1).to({x:247},0).wait(1).to({x:243},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,686.1,221.5);


(lib.Fondo4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Símbolo1();
	this.instance.setTransform(164.1,86.2,1,1,0,0,0,164.1,86.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:169.1},0).wait(1).to({x:174.1},0).wait(1).to({x:179.1},0).wait(1).to({x:184.1},0).wait(1).to({x:188.1},0).wait(1).to({x:192.1},0).wait(1).to({x:196.1},0).wait(1).to({x:200.1},0).wait(1).to({x:204.1},0).wait(1).to({x:208.1},0).wait(1).to({x:212.1},0).wait(1).to({x:216.1},0).wait(1).to({x:220.1},0).wait(1).to({x:224.1},0).wait(1).to({x:228.1},0).wait(1).to({x:232.1},0).wait(1).to({x:236.1},0).wait(1).to({x:240.1},0).wait(1).to({x:244.1},0).wait(1).to({x:248.1},0).wait(1).to({x:252.1},0).wait(1).to({x:256.1},0).wait(1).to({x:260.1},0).wait(1).to({x:264.1},0).wait(1).to({x:268.1},0).wait(1).to({x:272.1},0).wait(1).to({x:276.1},0).wait(1).to({x:280.1},0).wait(1).to({x:284.1},0).wait(1).to({x:288.1},0).wait(1).to({x:292.1},0).wait(1).to({x:296.1},0).wait(1).to({x:300.1},0).wait(1).to({x:304.1},0).wait(1).to({x:308.1},0).wait(1).to({x:312.1},0).wait(1).to({x:316.1},0).wait(1).to({x:320.1},0).wait(1).to({x:324.1},0).wait(1).to({x:320.1},0).wait(1).to({x:316.1},0).wait(1).to({x:312.1},0).wait(1).to({x:308.1},0).wait(1).to({x:304.1},0).wait(1).to({x:300.1},0).wait(1).to({x:296.1},0).wait(1).to({x:292.1},0).wait(1).to({x:288.1},0).wait(1).to({x:284.1},0).wait(1).to({x:280.1},0).wait(1).to({x:276.1},0).wait(1).to({x:272.1},0).wait(1).to({x:268.1},0).wait(1).to({x:264.1},0).wait(1).to({x:260.1},0).wait(1).to({x:256.1},0).wait(1).to({x:252.1},0).wait(1).to({x:248.1},0).wait(1).to({x:244.1},0).wait(1).to({x:240.1},0).wait(1).to({x:236.1},0).wait(1).to({x:232.1},0).wait(1).to({x:228.1},0).wait(1).to({x:224.1},0).wait(1).to({x:220.1},0).wait(1).to({x:216.1},0).wait(1).to({x:212.1},0).wait(1).to({x:208.1},0).wait(1).to({x:204.1},0).wait(1).to({x:200.1},0).wait(1).to({x:196.1},0).wait(1).to({x:192.1},0).wait(1).to({x:188.1},0).wait(1).to({x:184.1},0).wait(1).to({x:180.1},0).wait(1).to({x:176.1},0).wait(1).to({x:172.1},0).wait(1).to({x:168.1},0).wait(1).to({x:164.1},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,488.2,172.4);


(lib.Fondo3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.fondo3cp();
	this.instance.setTransform(267.5,134.1,1,1,0,0,0,267.5,134.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:275},0).wait(1).to({x:282.5},0).wait(1).to({x:290},0).wait(1).to({x:297.5},0).wait(1).to({x:303.5},0).wait(1).to({x:309.5},0).wait(1).to({x:315.5},0).wait(1).to({x:321.5},0).wait(1).to({x:327.5},0).wait(1).to({x:333.5},0).wait(1).to({x:339.5},0).wait(1).to({x:345.5},0).wait(1).to({x:351.5},0).wait(1).to({x:357.5},0).wait(1).to({x:363.5},0).wait(1).to({x:369.5},0).wait(1).to({x:375.5},0).wait(1).to({x:381.5},0).wait(1).to({x:387.5},0).wait(1).to({x:393.5},0).wait(1).to({x:399.5},0).wait(1).to({x:405.5},0).wait(1).to({x:411.5},0).wait(1).to({x:417.5},0).wait(1).to({x:423.5},0).wait(1).to({x:429.5},0).wait(1).to({x:435.5},0).wait(1).to({x:441.5},0).wait(1).to({x:447.5},0).wait(1).to({x:453.5},0).wait(1).to({x:459.5},0).wait(1).to({x:465.5},0).wait(1).to({x:471.5},0).wait(1).to({x:477.5},0).wait(1).to({x:483.5},0).wait(1).to({x:489.5},0).wait(1).to({x:495.5},0).wait(1).to({x:501.5},0).wait(1).to({x:507.5},0).wait(1).to({x:501.5},0).wait(1).to({x:495.5},0).wait(1).to({x:489.5},0).wait(1).to({x:483.5},0).wait(1).to({x:477.5},0).wait(1).to({x:471.5},0).wait(1).to({x:465.5},0).wait(1).to({x:459.5},0).wait(1).to({x:453.5},0).wait(1).to({x:447.5},0).wait(1).to({x:441.5},0).wait(1).to({x:435.5},0).wait(1).to({x:429.5},0).wait(1).to({x:423.5},0).wait(1).to({x:417.5},0).wait(1).to({x:411.5},0).wait(1).to({x:405.5},0).wait(1).to({x:399.5},0).wait(1).to({x:393.5},0).wait(1).to({x:387.5},0).wait(1).to({x:381.5},0).wait(1).to({x:375.5},0).wait(1).to({x:369.5},0).wait(1).to({x:363.5},0).wait(1).to({x:357.5},0).wait(1).to({x:351.5},0).wait(1).to({x:345.5},0).wait(1).to({x:339.5},0).wait(1).to({x:333.5},0).wait(1).to({x:327.5},0).wait(1).to({x:321.5},0).wait(1).to({x:315.5},0).wait(1).to({x:309.5},0).wait(1).to({x:303.5},0).wait(1).to({x:297.5},0).wait(1).to({x:291.5},0).wait(1).to({x:285.5},0).wait(1).to({x:279.5},0).wait(1).to({x:273.5},0).wait(1).to({x:267.5},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,775.1,268.2);


(lib.Fondo2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Fondo2CP();
	this.instance.setTransform(309.2,153.3,1,1,0,0,0,459.2,153.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:296.7},0).wait(1).to({x:284.2},0).wait(1).to({x:271.7},0).wait(1).to({x:259.2},0).wait(1).to({x:249.2},0).wait(1).to({x:239.2},0).wait(1).to({x:229.2},0).wait(1).to({x:219.2},0).wait(1).to({x:209.2},0).wait(1).to({x:199.2},0).wait(1).to({x:189.2},0).wait(1).to({x:179.2},0).wait(1).to({x:169.2},0).wait(1).to({x:159.2},0).wait(1).to({x:149.2},0).wait(1).to({x:139.2},0).wait(1).to({x:129.2},0).wait(1).to({x:119.2},0).wait(1).to({x:109.2},0).wait(1).to({x:99.2},0).wait(1).to({x:89.2},0).wait(1).to({x:79.2},0).wait(1).to({x:69.2},0).wait(1).to({x:59.2},0).wait(1).to({x:49.2},0).wait(1).to({x:39.2},0).wait(1).to({x:29.2},0).wait(1).to({x:19.2},0).wait(1).to({x:9.2},0).wait(1).to({x:-0.8},0).wait(1).to({x:-10.8},0).wait(1).to({x:-20.8},0).wait(1).to({x:-30.8},0).wait(1).to({x:-40.8},0).wait(1).to({x:-50.8},0).wait(1).to({x:-60.8},0).wait(1).to({x:-70.8},0).wait(1).to({x:-80.8},0).wait(1).to({x:-90.85},0).wait(1).to({x:-80.8},0).wait(1).to({x:-70.8},0).wait(1).to({x:-60.8},0).wait(1).to({x:-50.8},0).wait(1).to({x:-40.8},0).wait(1).to({x:-30.8},0).wait(1).to({x:-20.8},0).wait(1).to({x:-10.8},0).wait(1).to({x:-0.8},0).wait(1).to({x:9.2},0).wait(1).to({x:19.2},0).wait(1).to({x:29.2},0).wait(1).to({x:39.2},0).wait(1).to({x:49.2},0).wait(1).to({x:59.2},0).wait(1).to({x:69.2},0).wait(1).to({x:79.2},0).wait(1).to({x:89.2},0).wait(1).to({x:99.2},0).wait(1).to({x:109.2},0).wait(1).to({x:119.2},0).wait(1).to({x:129.2},0).wait(1).to({x:139.2},0).wait(1).to({x:149.2},0).wait(1).to({x:159.2},0).wait(1).to({x:169.2},0).wait(1).to({x:179.2},0).wait(1).to({x:189.2},0).wait(1).to({x:199.2},0).wait(1).to({x:209.2},0).wait(1).to({x:219.2},0).wait(1).to({x:229.2},0).wait(1).to({x:239.2},0).wait(1).to({x:249.2},0).wait(1).to({x:259.2},0).wait(1).to({x:269.2},0).wait(1).to({x:279.2},0).wait(1).to({x:289.2},0).wait(1).to({x:299.2},0).wait(1).to({x:309.15},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-550,0,1318.4,306.7);


(lib.Fondo1CP = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Fondo1_1();
	this.instance.setTransform(111,109,1,1,0,0,0,239,109);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({x:116.45},0).wait(1).to({x:121.9},0).wait(1).to({x:127.3},0).wait(1).to({x:132.75},0).wait(1).to({x:138.15},0).wait(1).to({x:143.6},0).wait(1).to({x:149},0).wait(1).to({x:154.45},0).wait(1).to({x:159.9},0).wait(1).to({x:165.3},0).wait(1).to({x:170.75},0).wait(1).to({x:176.15},0).wait(1).to({x:181.6},0).wait(1).to({x:187},0).wait(1).to({x:192.8},0).wait(1).to({x:198.6},0).wait(1).to({x:204.35},0).wait(1).to({x:210.15},0).wait(1).to({x:215.9},0).wait(1).to({x:221.7},0).wait(1).to({x:227.45},0).wait(1).to({x:233.25},0).wait(1).to({x:239},0).wait(1).to({x:246.75},0).wait(1).to({x:254.5},0).wait(1).to({x:262.25},0).wait(1).to({x:270},0).wait(1).to({x:277.75},0).wait(1).to({x:285.5},0).wait(1).to({x:293.25},0).wait(1).to({x:301},0).wait(1).to({x:308.75},0).wait(1).to({x:316.5},0).wait(1).to({x:324.25},0).wait(1).to({x:332},0).wait(1).to({x:339.75},0).wait(1).to({x:347.5},0).wait(1).to({x:355.25},0).wait(1).to({x:363},0).wait(1).to({x:355.45},0).wait(1).to({x:347.95},0).wait(1).to({x:340.45},0).wait(1).to({x:332.95},0).wait(1).to({x:325.45},0).wait(1).to({x:317.95},0).wait(1).to({x:310.45},0).wait(1).to({x:302.95},0).wait(1).to({x:295.45},0).wait(1).to({x:287.95},0).wait(1).to({x:280.55},0).wait(1).to({x:273.15},0).wait(1).to({x:265.75},0).wait(1).to({x:258.35},0).wait(1).to({x:250.95},0).wait(1).to({x:243.55},0).wait(1).to({x:236.2},0).wait(1).to({x:228.8},0).wait(1).to({x:221.4},0).wait(1).to({x:214},0).wait(1).to({x:209.45},0).wait(1).to({x:204.9},0).wait(1).to({x:200.35},0).wait(1).to({x:195.8},0).wait(1).to({x:191.25},0).wait(1).to({x:186.7},0).wait(1).to({x:182.15},0).wait(1).to({x:177.6},0).wait(1).to({x:173.05},0).wait(1).to({x:167.6},0).wait(1).to({x:162.15},0).wait(1).to({x:156.65},0).wait(1).to({x:151.2},0).wait(1).to({x:145.75},0).wait(1).to({x:140.3},0).wait(1).to({x:134.8},0).wait(1).to({x:129.35},0).wait(1).to({x:123.9},0).wait(1).to({x:118.45},0).wait(1).to({x:112.95},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-128,0,730,218);


(lib.botonpais5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_5
	this.instance = new lib.LetrasPeru();
	this.instance.setTransform(325.4,24.2,0.9999,0.9999,-62.8198,0,0,-39,81.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({_off:true},1).wait(1));

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AlMMVQiahBh3h2Qh2h3hBiZQhEigAAiuQAAitBEifQBBiaB2h3QB3h2CahBQCfhECtAAQCuAACgBEQCZBBB3B2QB2B3BBCaQBECfAACtQAACuhECgQhBCZh2B3Qh3B2iZBBQigBEiuAAQitAAifhEg");
	var mask_graphics_1 = new cjs.Graphics().p("ATmOUQizhLiKiKQiJiJhMizQhOi5AAjKQAAjJBOi5QBMizCJiJQCKiKCzhLQC5hPDKAAQDKAAC5BPQCyBLCKCKQCJCJBMCzQBOC5AADJQAADKhOC5QhMCziJCJQiKCKiyBLQi5BPjKAAQjKAAi5hPg");
	var mask_graphics_2 = new cjs.Graphics().p("ATlOUQiyhLiKiKQiJiJhMizQhOi5AAjKQAAjJBOi5QBMizCJiJQCKiKCyhLQC6hPDKAAQDKAAC5BPQCyBLCKCKQCJCJBMCzQBOC5AADJQAADKhOC5QhMCziJCJQiKCKiyBLQi5BPjKAAQjKAAi6hPg");
	var mask_graphics_3 = new cjs.Graphics().p("AlMMVQiahBh3h2Qh2h3hBiZQhEigAAiuQAAitBEifQBBiaB2h3QB3h2CahBQCfhECtAAQCuAACgBEQCZBBB3B2QB2B3BBCaQBECfAACtQAACuhECgQhBCZh2B3Qh3B2iZBBQigBEiuAAQitAAifhEg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:426.375,y:92.475}).wait(1).to({graphics:mask_graphics_1,x:263.4993,y:92.556}).wait(1).to({graphics:mask_graphics_2,x:263.4954,y:92.5546}).wait(1).to({graphics:mask_graphics_3,x:426.375,y:92.475}).wait(1));

	// Capa_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("Ai6OKIAbiFQBAANA8ADIgGCHQhGgDhLgPgABZMQQA9gGA9gRIAlCDQhIAUhIAIgAnMMiIBEh2QA3AgA6AWIgxB/QhDgahBglgAFJLOQA6gbAzgiIBMBxQg/AqhBAdgAqvJqIBlhbQArAwAwAmIhWBqQg7gwgvg1gAIYJEQAtgqAogyIBrBUQgyA9gxAugAtNF1IB8g3QAcA9AfAxIhyBKQgmg7gfhGgAKyF/QAeg1AWg8ICAAuQgaBFgjBBgAuXBaICIgNQAGBBAPA6IiEAiQgShGgHhKgAMHCVQAMg7AChBICHAEQgCBOgNBEgAucABQAAhIAMhJICGAVQgKA/AAA9gAL2jdICBgnQAWBHAJBJIiHARQgIg+gRg8gAtukfQAYhHAhhAIB5A+QgeA6gSA5gAKKm+IBwhNQAqA8AgBCIh7A7Qgbg4gkg0gAroojQAsg7A1gzIBfBhQgrAqgnA0gAHepyIBShtQA5ArA0A3IhiBeQgtgugwglgAoXrwQA8grBBggIA9B6Qg7AdgwAjgAECroIAsiBQBFAYBCAjIhBB4Qg4geg6gUgAkStyQBFgVBKgLIAUCHQhBAJg5ASgAAMsTIACiIQBMABBHANIgYCGQg8gLhBgBg");
	this.shape.setTransform(426.35,92.425);

	this.instance_1 = new lib.Fondo5();
	this.instance_1.setTransform(113,0,0.5022,0.508);

	this.instance_2 = new lib.Fondo5_1();
	this.instance_2.setTransform(291.8,92.8,1,1,0,0,0,243,110.8);
	var instance_2Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_1];
	this.instance_2.cache(-2,-2,690,226);

	var maskedShapeInstanceList = [this.shape,this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:426.35,y:92.425}}]}).to({state:[{t:this.instance_2},{t:this.shape,p:{scaleX:1.1609,scaleY:1.1609,x:427.5079,y:92.498}}]},1).to({state:[{t:this.instance_2},{t:this.shape,p:{scaleX:1.1609,scaleY:1.1609,x:427.5014,y:92.4965}}]},1).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:426.35,y:92.425}}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_1).wait(2).to(new cjs.ColorFilter(0.42,0.42,0.42,1,147.9,147.9,147.9,0), 0).wait(1));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_2, startFrame:1, endFrame:1, x:-2, y:-2, w:690, h:226});
	this.filterCacheList.push({instance: this.instance_2, startFrame:2, endFrame:2, x:-2, y:-2, w:690, h:226});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:3, x:-2, y:-2, w:690, h:226});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:4, x:-2, y:-2, w:690, h:226});
	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(320.7,-6.9,206.3,198.9);


(lib.botonpais4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_6
	this.instance = new lib.LetrasCuba();
	this.instance.setTransform(179.55,-17.25,0.9999,0.9999,-35.613,0,0,-39,81.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({_off:true},1).wait(1));

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AnJHKQi9i+AAkMQAAkLC9i+QC+i9ELAAQEMAAC+C9QC9C+AAELQAAEMi9C+Qi+C9kMAAQkLAAi+i9g");
	var mask_graphics_1 = new cjs.Graphics().p("ACbJeQj6j7AAljQAAlhD6j8QD7j7FjAAQFjAAD7D7QD7D8AAFhQAAFjj7D7Qj7D7ljAAQljAAj7j7g");
	var mask_graphics_2 = new cjs.Graphics().p("ACbJeQj6j7AAljQAAlhD6j8QD7j7FjAAQFjAAD7D7QD7D8AAFhQAAFjj7D7Qj7D7ljAAQljAAj7j7g");
	var mask_graphics_3 = new cjs.Graphics().p("AnJHKQi9i+AAkMQAAkLC9i+QC+i9ELAAQEMAAC+C9QC9C+AAELQAAEMi9C+Qi+C9kMAAQkLAAi+i9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:237.525,y:71.175}).wait(1).to({graphics:mask_graphics_1,x:161.8014,y:69.6795}).wait(1).to({graphics:mask_graphics_2,x:161.8014,y:69.6795}).wait(1).to({graphics:mask_graphics_3,x:237.525,y:71.175}).wait(1));

	// Capa_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AhTLEIAQiHQA9AIA8gGIAMCHQghADghABQgrgBgogFgACtIoQA5gSA2gfIBDB2QhBAlhJAXgAltJlIBGh1QAzAfA7AUIgsCBQhJgZg/gmgAF/GwQAvgoAjgxIBtBRQgrA8g6AzgApIGbIBvhPQAkAyAsApIhcBkQg4g1grg7gAIPDvQAZg4ANg8ICFAeQgQBJgfBFgAq9CIICFgaQAMA9AYA3Ih9A1QgehFgOhKgAJDADIAAgEQAAg7gMg5ICGgbQAOBIAABHIAAAFgArKgBQAAhNAPhHICFAcQgMA5AAA/gAHXlSIBuhPQAtA/AdBDIh8A2QgYg2gkgzgAqMkkQAfhGAsg8IBuBQQglAygYA3gAEkn1IBFh1QBBAmA4AyIhcBlQgwgrgygdgAndoVQA5gzBBglIBEB2Qg1AeguApgAA/pBIAPiHQBIAIBKAYIgqCBQg6gSg9gIgAjaqqQBKgXBJgIIANCIQg6AGg8ATg");
	this.shape.setTransform(237.525,71.35);

	this.instance_1 = new lib.Fondo3();
	this.instance_1.setTransform(37,0,0.4894,0.4894);

	this.instance_2 = new lib.Fondo4_1();
	this.instance_2.setTransform(152.15,69.6,1.0977,1.0977,0,0,0,164.1,86.2);
	var instance_2Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_1];
	this.instance_2.cache(-2,-2,492,176);

	var maskedShapeInstanceList = [this.shape,this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:237.525,y:71.35}}]}).to({state:[{t:this.instance_2},{t:this.shape,p:{scaleX:1.3239,scaleY:1.3239,x:237.9126,y:69.9112}}]},1).to({state:[{t:this.instance_2},{t:this.shape,p:{scaleX:1.3239,scaleY:1.3239,x:237.9126,y:69.9112}}]},1).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:237.525,y:71.35}}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_1).wait(2).to(new cjs.ColorFilter(0.42,0.42,0.42,1,147.9,147.9,147.9,0), 0).wait(1));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_2, startFrame:1, endFrame:1, x:-2, y:-2, w:492, h:176});
	this.filterCacheList.push({instance: this.instance_2, startFrame:2, endFrame:2, x:-2, y:-2, w:492, h:176});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:3, x:-2, y:-2, w:492, h:176});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:4, x:-2, y:-2, w:492, h:176});
	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(152.2,-20.4,171.40000000000003,175.8);


(lib.botonpais3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_5
	this.instance = new lib.LetrasParaguay();
	this.instance.setTransform(127.95,211.5,1,1,0,0,0,-39.1,81.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({_off:true},1).wait(1));

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AlzNyQishJiEiEQiFiFhJisQhLixAAjDQAAjBBLiyQBJisCFiEQCEiFCshJQCxhLDCAAQDCAACyBLQCsBJCECFQCFCEBJCsQBLCyAADBQAADDhLCxQhJCsiFCFQiECEisBJQiyBLjCAAQjCAAixhLg");
	var mask_graphics_1 = new cjs.Graphics().p("ADERIQjUhaililQikikhbjWQhdjdAAjyQAAjxBdjdQBbjVCkilQClilDUhaQDdheDyAAQDyAADdBeQDVBaClClQClClBbDVQBdDdAADxQAADyhdDdQhbDWilCkQilCljVBaQjdBejyAAQjyAAjdheg");
	var mask_graphics_2 = new cjs.Graphics().p("ADERIQjUhaililQikikhbjWQhdjdAAjyQAAjxBdjdQBbjVCkilQClilDUhaQDdheDyAAQDyAADdBeQDVBaClClQClClBbDVQBdDdAADxQAADyhdDdQhbDWilCkQilCljVBaQjdBejyAAQjyAAjdheg");
	var mask_graphics_3 = new cjs.Graphics().p("AlzNyQishJiEiEQiFiFhJisQhLixAAjDQAAjBBLiyQBJisCFiEQCEiFCshJQCxhLDCAAQDCAACyBLQCsBJCECFQCFCEBJCsQBLCyAADBQAADDhLCxQhJCsiFCFQiECEisBJQiyBLjCAAQjCAAixhLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:252.025,y:102.475}).wait(1).to({graphics:mask_graphics_1,x:184.8889,y:103.1167}).wait(1).to({graphics:mask_graphics_2,x:184.8889,y:103.1167}).wait(1).to({graphics:mask_graphics_3,x:252.025,y:102.475}).wait(1));

	// Capa_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AAWN5QBAgBA+gLIAWCGQhHAMhJACgAkGPfIAjiEQA6AQBCAIIgQCHQhJgIhGgTgAEONPQA6gSA7gcIA8B5QhAAghHAWgAoRNtIBGh0QA3AiA6AYIg1B9QhEgdg+gmgAHxLiQA2gmAtgpIBbBlQg1Axg9ApgArxK2IBkhcQAuAyAtAkIhWBqQg4gugxg2gAKrI5QAqgyAgg1IB0BIQgoA/gtA3gAuWHHIB6g8QAcA3AkA1IhwBNQgpg7ghhCgAMvFiQAZg5ARg+ICEAkQgVBKgcA/gAvwCzICGgYQAKA9AUA+IiBAqQgWhGgNhHgANyBvQAHg4AAg2IAAgPICIgCIAAARQAABCgIA9gAwAABQAAhHAKhJICHATQgJBAAAA9IABAdIiIAFgANRkGICCgpQAVBGAMBJIiGAUQgJg5gUhBgAvXkeQAVhIAehAIB7A4QgbA8gQA6gALlnqIByhLQAoA+AfBBIh7A7Qgag5gkg2gAtfomQAqhBAtg0IBnBYQgqAyghA0gAI+qmIBYhnQA4AwAwA1IhmBaQgsgwgugogAqisCQA3gwA9goIBLByQgzAhgyArgAFpsrIA3h8QBCAcA+AoIhIBzQg2gig5gZgAmvugQBEggBFgUIAnCCQg+ASg4AbgAB2twIASiHQBIAKBHAUIglCDQg8gRhAgJgAiZv0QBKgLBHgBIABCIQhCACg7AIg");
	this.shape.setTransform(252.025,102.45);

	this.instance_1 = new lib.Fondo4();
	this.instance_1.setTransform(-71,-8,0.5313,0.5313);

	this.instance_2 = new lib.Fondo3_1();
	this.instance_2.setTransform(116.5,100.1,1,1,0,0,0,267.5,134.1);
	var instance_2Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_1];
	this.instance_2.cache(-2,-2,779,272);

	var maskedShapeInstanceList = [this.shape,this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:252.025,y:102.45}}]}).to({state:[{t:this.instance_2},{t:this.shape,p:{scaleX:1.2434,scaleY:1.2434,x:250.8161,y:103.0856}}]},1).to({state:[{t:this.instance_2},{t:this.shape,p:{scaleX:1.2434,scaleY:1.2434,x:250.8161,y:103.0856}}]},1).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:252.025,y:102.45}}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_1).wait(2).to(new cjs.ColorFilter(0.42,0.42,0.42,1,147.9,147.9,147.9,0), 0).wait(1));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_2, startFrame:1, endFrame:1, x:-2, y:-2, w:779, h:272});
	this.filterCacheList.push({instance: this.instance_2, startFrame:2, endFrame:2, x:-2, y:-2, w:779, h:272});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:3, x:-2, y:-2, w:779, h:272});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:4, x:-2, y:-2, w:779, h:272});
	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(123.4,-15.8,246.4,237.9);


(lib.botonpais2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa8
	this.instance = new lib.LetrasColombia();
	this.instance.setTransform(128.4,324.2,1.0671,1.0781,-177.7394,0,0,-39.4,81.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({_off:true},1).wait(1));

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AnhR2QjfheirirQisishejeQhhjnAAj8QAAj7BhjmQBejfCsirQCrisDfheQDmhhD7gBQD8ABDnBhQDeBeCrCsQCsCrBeDfQBhDmAAD7QAAD8hhDnQheDeisCsQirCrjeBeQjnBij8AAQj7AAjmhig");
	var mask_graphics_1 = new cjs.Graphics().p("AllWVQkIhvjLjLQjLjLhwkIQhzkRAAkrQAAkpBzkRQBwkIDLjLQDLjMEIhvQERhzEpAAQErAAERBzQEHBvDLDMQDMDLBvEIQBzERAAEpQAAErhzERQhvEIjMDLQjLDLkHBvQkRB0krAAQkpAAkRh0g");
	var mask_graphics_2 = new cjs.Graphics().p("AllWVQkIhvjLjLQjLjLhwkIQhzkRAAkrQAAkpBzkRQBwkIDLjLQDLjMEIhvQERhzEpAAQErAAERBzQEHBvDLDMQDMDLBvEIQBzERAAEpQAAErhzERQhvEIjMDLQjLDLkHBvQkRB0krAAQkpAAkRh0g");
	var mask_graphics_3 = new cjs.Graphics().p("AnhR2QjfheirirQisishejeQhhjnAAj8QAAj7BhjmQBejfCsirQCrisDfheQDmhhD7gBQD8ABDnBhQDeBeCrCsQCsCrBeDfQBhDmAAD7QAAD8hhDnQheDeisCsQirCrjeBeQjnBij8AAQj7AAjmhig");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:188.875,y:162.6}).wait(1).to({graphics:mask_graphics_1,x:168.1443,y:154.4924}).wait(1).to({graphics:mask_graphics_2,x:168.1443,y:154.4924}).wait(1).to({graphics:mask_graphics_3,x:188.875,y:162.6}).wait(1));

	// Capa_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AgCUbIAAiIIACAAQBBAAA8gGIAPCHQhFAHhHAAgAkfT7IAeiEQA+AOBBAHIgPCHQhJgIhFgQgAD8R4QBAgOA8gUIArCBQhGAXhEAPgAotSeIA6h7QA2AbBBAWIgtCAQhFgYg/gegAHvQmQBAgeAxgfIBHB0QhAAng/AdgAshQIIBThrQAxAmA5AjIhHB0Qg/gng3grgALKOhQAzgnAugtIBeBiQg1Azg3AqgAvuNBIBohXQAmAuAxAxIheBhQg1gzgsg2gAODLvQArgzAig0IBxBMQgmA5gwA5gAyMJSIB5g+QAeA5AjA2IhyBLQgng8ghhAgAQRIaQAdg4AYg+IB/AxQgZBBgiBCgAzxFGICDghQARA/AWA7Ih/AwQgZhCgShHgARtEqQARhDAJg6ICGATQgKBIgSBFgA0aArICIgEQADBDAIA9IiGATQgLhLgChEgASTAtIAAgtQAAglgCguICHgJQADAuAAAuIgBAygA0aAAQAAhHAHhHICIAPQgHA7AABEgARjlPICCgnQAUBCANBJIiFAZQgNhBgRg8gAz7kcQANg/AZhLICBAsQgUA6gPBCgAP/o7IB2hDQAkA/AbBCIh9A1QgYg5ggg6gAyforQAehAAmg+IB0BHQgiA3gbA6gANqsMIBlhaQAwA1ApA7IhuBPQgjgygtgzgAwJsfQArg4Ayg0IBiBeQgsAugoAzgAKru3IBPhvQA9AsAzAuIhbBlQgtgog3gogAtDvtQAzgqBAgrIBLBxQgxAhg2AsgAHLw1IA2h9QBFAeA7AhIhCB3Qg4ggg8gZgApUyLQBAggBDgaIAwB/Qg9AXg4AdgADWx/IAZiGQBDAMBIAWIgnCCQg8gShBgMgAlJzxQBGgSBHgKIATCHQg+AJhAAQgAgpySIgFiIQBMgCBDAFIgKCIQg8gFhEACg");
	this.shape.setTransform(188.875,162.6083);

	this.instance_1 = new lib.Fondo2();
	this.instance_1.setTransform(24,32,0.4922,0.4922);

	this.instance_2 = new lib.Fondo2_1();
	this.instance_2.setTransform(624.2,165.6,1.0327,1.0327,0,0,0,459.2,153.4);
	var instance_2Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_1];
	this.instance_2.cache(-552,-2,1322,311);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B20016").s().p("AgCUbIAAiIIACAAQBBAAA8gGIAPCHQhFAHhHAAgAkfT7IAeiEQA+AOBBAHIgPCHQhJgIhFgQgAD8R4QBAgOA8gUIArCBQhGAXhEAPgAotSeIA6h7QA2AbBBAWIgtCAQhFgYg/gegAHvQmQBAgeAxgfIBHB0QhAAng/AdgAshQIIBThrQAxAmA5AjIhHB0Qg/gng3grgALKOhQAzgnAugtIBeBiQg1Azg3AqgAvuNBIBohXQAmAuAxAxIheBhQg1gzgsg2gAODLvQArgzAig0IBxBMQgmA5gwA5gAyMJSIB5g+QAeA5AjA2IhyBLQgng8ghhAgAQRIaQAdg4AYg+IB/AxQgZBBgiBCgAzxFGICDghQARA/AWA7Ih/AwQgZhCgShHgARtEqQARhDAJg6ICGATQgKBIgSBFgA0aArICIgEQADBDAIA9IiGATQgLhLgChEgASTAtIAAgtQAAglgCguICHgJQADAuAAAuIgBAygA0aAAQAAhHAHhHICIAPQgHA7AABEgARjlPICCgnQAUBCANBJIiFAZQgNhBgRg8gAz7kcQANg/AZhLICBAsQgUA6gPBCgAP/o7IB2hDQAkA/AbBCIh9A1QgYg5ggg6gAyforQAehAAmg+IB0BHQgiA3gbA6gANqsMIBlhaQAwA1ApA7IhuBPQgjgygtgzgAwJsfQArg4Ayg0IBiBeQgsAugoAzgAKru3IBPhvQA9AsAzAuIhbBlQgtgog3gogAtDvtQAzgqBAgrIBLBxQgxAhg2AsgAHLw1IA2h9QBFAeA7AhIhCB3Qg4ggg8gZgApUyLQBAggBDgaIAwB/Qg9AXg4AdgADWx/IAZiGQBDAMBIAWIgnCCQg8gShBgMgAlJzxQBGgSBHgKIATCHQg+AJhAAQgAgpySIgFiIQBMgCBDAFIgKCIQg8gFhEACg");
	this.shape_1.setTransform(189.4491,162.1256,1.1849,1.1849);

	var maskedShapeInstanceList = [this.shape,this.instance_1,this.instance_2,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:188.875,y:162.6083}}]}).to({state:[{t:this.shape_1},{t:this.instance_2,p:{y:165.6}},{t:this.shape,p:{scaleX:1.1849,scaleY:1.1849,x:189.4491,y:162.1256}}]},1).to({state:[{t:this.shape_1},{t:this.instance_2,p:{y:165.35}},{t:this.shape,p:{scaleX:1.1849,scaleY:1.1849,x:189.4491,y:162.1256}}]},1).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:188.875,y:162.6083}}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_1).wait(2).to(new cjs.ColorFilter(0.42,0.42,0.42,1,147.9,147.9,147.9,0), 0).wait(1));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_2, startFrame:1, endFrame:1, x:-552, y:-2, w:1322, h:311});
	this.filterCacheList.push({instance: this.instance_2, startFrame:2, endFrame:2, x:-552, y:-2, w:1322, h:311});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:3, x:-552, y:-2, w:1322, h:311});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:4, x:-552, y:-2, w:1322, h:311});
	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(42.6,15.3,293.7,314.09999999999997);


(lib.botonpais1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_5
	this.instance = new lib.LetrasBrasil();
	this.instance.setTransform(322.95,-17.85,1,1,0,0,0,73.9,60.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(1).to({_off:true},1).wait(1));

	// Capa_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AksLIQiKg7hrhrQhrhrg7iKQg9iQAAidQAAicA9iQQA7iLBrhqQBrhrCKg7QCQg9CcAAQCdAACQA9QCKA7BrBrQBrBqA7CLQA9CQAACcQAACdg9CQQg7CKhrBrQhqBriLA7QiQA9idAAQicAAiQg9g");
	var mask_graphics_1 = new cjs.Graphics().p("AmVPBQi7hPiQiRQiRiQhPi7QhRjCAAjUQAAjTBRjCQBPi7CRiQQCQiQC7hQQDChSDUAAQDTAADCBSQBFAeBAAmQBrBBBbBbQCQCQBQC7QBSDCAADTQAADUhSDCQhQC7iQCQQhaBbhsBCQhAAmhFAdQjCBSjTAAQjUAAjChSg");
	var mask_graphics_2 = new cjs.Graphics().p("AmVPBQi7hPiQiRQiRiQhPi7QhRjCAAjUQAAjTBRjCQBPi7CRiQQCQiQC7hQQDChSDUAAQDTAADCBSQC7BQCQCQQCQCQBQC7QBSDCAADTQAADUhSDCQhQC7iQCQQiPCRi8BPQjCBSjTAAQjUAAjChSg");
	var mask_graphics_3 = new cjs.Graphics().p("AksLIQiKg7hrhrQhrhrg7iKQg9iQAAidQAAicA9iQQA7iLBrhqQBrhrCKg7QCQg9CcAAQCdAACQA9QCKA7BrBrQBrBqA7CLQA9CQAACcQAACdg9CQQg7CKhrBrQhqBriLA7QiQA9idAAQicAAiQg9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:168.125,y:123.425}).wait(1).to({graphics:mask_graphics_1,x:168.15,y:123.425}).wait(1).to({graphics:mask_graphics_2,x:168.15,y:123.425}).wait(1).to({graphics:mask_graphics_3,x:168.125,y:123.425}).wait(1));

	// Capa_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B20016").s().p("AABLBQA8AAA/gLIAYCGQhKANhIAAgAkdMXIAuiAQA6AVA9AKIgXCGQhJgNhFgYgADyKWQA7gWA0geIBFB1QhAAlhFAagAoaKFIBXhoQAuAnA3AfIhEB2Qg/gkg5gwgAHGIbQAtgmAqgxIBoBXQguA4g6AwgArWGmIB1hEQAeAzApAxIhoBYQgvg3glhBgAJjFfQAfg2AVg5ICAAuQgYBEgmBBgAs7CUICGgYQAKA6AWA9Ih/AvQgahGgNhIgAK2B5QALg7AAg+ICIAAIAAAAQAABLgNBGgAtIACIAAgCQAAhHANhKICGAYQgLA8AAA9IAAACgAKWjxICAgvQAZBEANBKIiGAYQgLg+gVg5gAsVkeQAZhGAlg/IB2BEQgfA1gVA6gAIbnFIBphXQAvA5AlA/Ih2BEQgfg1gogwgAqDobQAtg2A6gyIBYBoQgyArglAsgAFgpiIBEh2QA9AjA7AxIhXBpQgugng3gggAmkrXQBCglBDgZIAvCAQg6AVg2AfgAB6q1IAXiGQBMANBCAZIguB/Qg6gVg9gKgAiRs7QBIgNBJAAIAACIQg+AAg8ALg");
	this.shape.setTransform(168.125,123.425);

	this.instance_1 = new lib.Fondo1();
	this.instance_1.setTransform(-23,41,0.5499,0.5571);

	this.instance_2 = new lib.Fondo1CP();
	this.instance_2.setTransform(172,122,1,1,0,0,0,239,109);
	var instance_2Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_2.filters = [instance_2Filter_1];
	this.instance_2.cache(-130,-2,734,222);

	var maskedShapeInstanceList = [this.shape,this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:168.125,y:123.425}}]}).to({state:[{t:this.instance_2},{t:this.shape,p:{scaleX:1.3092,scaleY:1.3092,x:168.1522,y:123.4329}}]},1).to({state:[{t:this.instance_2},{t:this.shape,p:{scaleX:1.3092,scaleY:1.3092,x:168.1522,y:123.4329}}]},1).to({state:[{t:this.instance_1},{t:this.shape,p:{scaleX:1,scaleY:1,x:168.125,y:123.425}}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_2Filter_1).wait(2).to(new cjs.ColorFilter(0.42,0.42,0.42,1,147.9,147.9,147.9,0), 0).wait(1));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_2, startFrame:1, endFrame:1, x:-130, y:-2, w:734, h:222});
	this.filterCacheList.push({instance: this.instance_2, startFrame:2, endFrame:2, x:-130, y:-2, w:734, h:222});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:3, x:-130, y:-2, w:734, h:222});
	this.filterCacheList.push({instance: this.instance_2, startFrame:3, endFrame:4, x:-130, y:-2, w:734, h:222});
	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(63.9,-1.9,208.49999999999997,229.6);


(lib.mc_escenario5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_9 = function() {
		this.stop();
		
		this.botonpais1.on("click", cohete.bind(this));
		this.botonpais2.on("click", cohete.bind(this));
		this.botonpais3.on("click", cohete.bind(this));
		this.botonpais4.on("click", cohete.bind(this));
		this.botonpais5.on("click", cohete.bind(this));
		
		function cohete(e){
			this.gotoAndPlay(12);
		}
		
		
		this.botonpais1.on("click", valor.bind(this));
		
		function valor(){
			bn=1;
			return bn;
		}
		
		this.botonpais2.on("click", valor2.bind(this));
		
		function valor2(){
			bn=2;
			return bn;
		}
		
		this.botonpais3.on("click", valor3.bind(this));
		
		function valor3(){
			bn=3;
			return bn;
		}
		this.boton6.addEventListener("click", abrir);
		
		function abrir() {
		    window.open("card.html", "_blank");
		}
	}
	this.frame_32 = function() {
		this.stop();
		
		//alert("El valor de"+bn);
		
		if (bn == 1){
			this.parent.cambiarEscenario(new lib.mc_escenario3(),1);	
		} else if (bn == 2){
			this.parent.cambiarEscenario(new lib.mc_escenario1(),1);
		} else if (bn == 3){
			this.parent.cambiarEscenario(new lib.mc_escenario6(),1);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(9).call(this.frame_9).wait(23).call(this.frame_32).wait(1));

	// Btn_Tarjeta
	this.boton6 = new lib.boton6();
	this.boton6.name = "boton6";
	this.boton6.setTransform(1184.05,55.3);
	this.boton6._off = true;
	new cjs.ButtonHelper(this.boton6, 0, 1, 2, false, new lib.boton6(), 3);

	this.timeline.addTween(cjs.Tween.get(this.boton6).wait(9).to({_off:false},0).to({_off:true},1).wait(23));

	// Avion
	this.Avion = new lib.Avion();
	this.Avion.name = "Avion";
	this.Avion.setTransform(-120,927.25,1,1,0,0,0,176.1,99.5);
	this.Avion._off = true;

	this.timeline.addTween(cjs.Tween.get(this.Avion).wait(10).to({_off:false},0).wait(1).to({scaleX:1.0272,scaleY:1.0272,rotation:-8.4346,x:-96.85,y:877.25},0).wait(1).to({scaleX:1.0544,scaleY:1.0544,rotation:-7.0819,x:-8.25,y:746.45},0).wait(1).to({scaleX:1.0816,scaleY:1.0816,rotation:-5.7291,x:75.3,y:642.35},0).wait(1).to({scaleX:1.1088,scaleY:1.1088,rotation:-2.7431,x:133.95,y:579.1},0).wait(1).to({scaleX:1.136,scaleY:1.136,rotation:0.2597,x:188.6,y:538.2},0).wait(1).to({scaleX:1.1632,scaleY:1.1632,rotation:6.7253,x:219.15,y:521.45},0).wait(1).to({scaleX:1.7666,scaleY:1.7666,rotation:7.8855,x:301.15,y:459.2},0).wait(1).to({scaleX:2.1994,scaleY:2.1994,rotation:9.0458,x:374.55,y:416.95},0).wait(1).to({scaleX:2.6323,scaleY:2.6323,rotation:10.2061,x:511.95,y:350.55},0).wait(1).to({scaleX:2.7158,scaleY:2.7158,rotation:15.4076,x:673.6,y:295.1},0).wait(1).to({scaleX:2.7995,scaleY:2.7995,rotation:17.8584,x:805.8,y:250.15},0).wait(1).to({scaleX:2.8831,scaleY:2.8831,rotation:19.4719,x:887.65,y:218.5},0).wait(1).to({scaleX:2.9667,scaleY:2.9667,rotation:21.0854,x:981.4,y:185.4},0).wait(1).to({scaleX:3.0503,scaleY:3.0503,x:1081.8,y:160.6},0).wait(1).to({scaleX:3.2633,scaleY:3.2633,x:1161.85,y:129.7},0).wait(1).to({scaleX:3.4763,scaleY:3.4763,x:1249.1,y:91.65},0).wait(1).to({x:1324.85,y:45.3},0).wait(1).to({x:1513.85,y:-45.7},0).wait(1).to({x:1676.55},0).wait(1).to({x:1856.65,y:-103.8},0).wait(1).to({x:1975,y:-258.65},0).to({_off:true},1).wait(1));

	// Desvanecer
	this.instance = new lib.Símbolo3();
	this.instance.setTransform(-455,1081.35,1,1,0,0,0,550.9,452.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).wait(1).to({regY:453,scaleX:1.0147,scaleY:1.0137,rotation:0.3889,x:-383.65,y:1019.6},0).wait(1).to({scaleX:1.0293,scaleY:1.0273,rotation:0.7778,x:-305.4,y:969.65},0).wait(1).to({scaleX:1.044,scaleY:1.0409,rotation:1.1666,x:-229.4,y:907.9},0).wait(1).to({scaleX:1.0587,scaleY:1.0546,rotation:1.5555,x:-123.05,y:831.85},0).wait(1).to({scaleX:1.0733,scaleY:1.0682,rotation:1.9444,x:-26.25,y:784.25},0).wait(1).to({scaleX:1.1381,scaleY:1.0663,rotation:2.3333,x:104.4,y:724.85},0).wait(1).to({scaleX:1.2026,scaleY:1.0644,rotation:2.7222,x:268.4,y:632.2},0).wait(1).to({scaleX:1.2114,scaleY:1.137,rotation:8.4312,x:372.95,y:551.1},0).wait(1).to({scaleX:1.2906,scaleY:1.2132,rotation:11.8987,x:434.75,y:501.2},0).wait(1).to({scaleX:1.3658,scaleY:1.5252,rotation:21.5361,x:557.15,y:448.9},0).wait(1).to({scaleX:1.6936,scaleY:1.7886,rotation:22.655,x:557.2},0).wait(1).to({scaleX:1.7658,scaleY:1.988,rotation:23.7738,y:448.95},0).wait(1).to({scaleX:1.8764,scaleY:2.293,rotation:26.2452,x:557.1,y:454.75},0).wait(1).to({scaleX:2.0722,scaleY:2.7761,x:557.15,y:460.6},0).wait(1).to({scaleX:2.4425,scaleY:3.2721,y:466.45},0).wait(1).to({scaleX:3.5023,scaleY:4.6918,x:557.25,y:472.3},0).wait(1).to({scaleX:6.2475,x:557.4,y:472.35},0).to({_off:true},1).wait(1));

	// Texto
	this.instance_1 = new lib.TextosInicial2();
	this.instance_1.setTransform(27,48,0.218,0.218);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(9).to({_off:false},0).wait(1).to({_off:true},22).wait(1));

	// Circulo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhqyA8AMAAAh3/MDVlAAAMAAAB3/g");
	this.shape.setTransform(682.45,384);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhqyBG4MDVlh3/MAAAB3/gEhqyhG3MDVlAAAMjVlB3/g");
	this.shape_1.setTransform(682.45,354.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ehc+BJmMDVlh3/MAAAB3/gEh4mhJlMDVlAAAMjVlB3/g");
	this.shape_2.setTransform(711.025,328.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("EhLLBO5MDVlh3/MAAAB3/gEiKZhO4MDVlAAAMjVlB3/g");
	this.shape_3.setTransform(726.425,328.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Eg/4BS+MDVlh3/MAAAB3/gEiVshS+MDVlAAAMjVlB4Ag");
	this.shape_4.setTransform(724.775,354.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("EgypBbZMDVlh3/MAAAB3/gEii7hbYMDVlAAAMjVlB3/g");
	this.shape_5.setTransform(701.675,356.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("EglaBoJMDVlh3/MAAAB3/gEiwKhoIMDVlAAAMjVlB3/g");
	this.shape_6.setTransform(703.2,348.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("EgXdBwkMDVlh3/MAAAB3/gEi+HhwkMDVlAAAMjVlB4Ag");
	this.shape_7.setTransform(684.725,365.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("EgBwB8HMDVlh4AMAAAB4AgEjT0h8HMDVlAAAMjVlB4Bg");
	this.shape_8.setTransform(665.95,381.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[]},24).wait(1));

	// Botones
	this.botonpais3 = new lib.botonpais3();
	this.botonpais3.name = "botonpais3";
	this.botonpais3.setTransform(1053.1,482.55,1,1,0,0,0,229.3,102.5);
	new cjs.ButtonHelper(this.botonpais3, 0, 1, 2, false, new lib.botonpais3(), 3);

	this.botonpais4 = new lib.botonpais4();
	this.botonpais4.name = "botonpais4";
	this.botonpais4.setTransform(889.2,273.1,1,1,0,0,0,182.4,81.7);
	new cjs.ButtonHelper(this.botonpais4, 0, 1, 2, false, new lib.botonpais4(), 3);

	this.botonpais2 = new lib.botonpais2();
	this.botonpais2.name = "botonpais2";
	this.botonpais2.setTransform(701.75,436.15,1,1,0,0,0,188.8,162.6);
	new cjs.ButtonHelper(this.botonpais2, 0, 1, 2, false, new lib.botonpais2(), 3);

	this.botonpais5 = new lib.botonpais5();
	this.botonpais5.name = "botonpais5";
	this.botonpais5.setTransform(1100.95,303.5,1,1,0,0,0,283.4,120.2);
	new cjs.ButtonHelper(this.botonpais5, 0, 1, 2, false, new lib.botonpais5(), 3);

	this.botonpais1 = new lib.botonpais1();
	this.botonpais1.name = "botonpais1";
	this.botonpais1.setTransform(511.6,264.55,1,1,0,0,0,168.1,123.4);
	new cjs.ButtonHelper(this.botonpais1, 0, 1, 2, false, new lib.botonpais1(), 3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#B20016").s().p("AguAHQAVgcALgYIA9AcQgMAZgaAmg");
	this.shape_9.setTransform(1242.375,279);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#B20016").s().p("A0YZwIAGhEQBGAGBAABIgCBEQhFgBhFgGgAwHYyQBIgEA+gGIAHBEQg9AGhNAEgA4pZFIAPhCQA5ANBKAMIgKBEQhMgNg8gOgAr8YXQA7gJBIgPIAOBCQhFAPhCAKgA8xXyIAag/QA7AYBCAVIgUBBQhIgWg7gZgAn3XfQA/gRA9gZIAbA+Qg8AZhJAVgEggnAVzIAkg5QAzAgBAAiIgfA8Qg+ggg6glgAkHV5QAzgfA2guIAsA0Qg4Awg5AjgEgkAATDIAwgvQAwAvAyApIgqA1Qg5gugvgwgAhBTQQAlgqAvg9IA1AqQg0BEgjAmgEgmrAPmIA7giQAgA2AqA3Ig2ApQgsg4gjg8gABmP+QArg4ArgzIA0AtQgqAwgrA3gEgoYALlIBBgSQASBAAaA8Ig/AaQgchDgShBgAEcMuQA2gyA1gnIApA3Qg1AmgwAugAH9KJQA4ggBEgdIAbA+Qg9Aag5AggEgpBAHRIBEgCQABBCAKBBIhDAKQgKhEgChHgAL7IbQA8gTBJgSIAQBCQhBAQg/AUgAQHHaQBIgNBAgHIAIBDQhGAJg+ALgAUXG4IAQgCQA8gFA6gGIAIBDQgvAGhJAGIgQABgAYeGTQBPgWAKgZIBAAYQgWA6hyAegEgo9AFGQAGhJAMhBIBDAMQgLA5gHBKgAXiDAIApg2QBFA1AmAlIgvAxQglgkhAgxgAUGAgIApg2IBtBPIgnA3gEgoLAA0QAPg2ATg2IAIgWIBAAXIgIAWQgUA7gNAtgAQviKIAugzQAsAoA6AuIgqA1Qg9gxgtgngEgmygDOIAviAIBAAYIgwB/gAOPkwIgdgnIA4goIAaAkQAbAiAeAfIgyAvQgjgmgZgfgEAnJgE2IAFhEQA8AEBGgHIAHBDQg2AFgnAAQgZAAgYgBgEAi7gGVIApg2QAzAmA7ATIgWBBQhFgYg8gsgEArPgGUQA5gRBAgfIAeA9QhJAig7ASgEglUgHNQAbhLASg1IBBAXIguCAgEAu+gIDQA5giA3gmIAnA4Qg7Aog6AigAMBpcIBDgNQAMBAAaA6Ig+AcQgehEgNhFgEAgKgJyIA7ghQAkBBAjAtIg2ApQglgwgnhGgEAybgKZQA0goA1gsIAsA0Qg0Arg4ArgEgj9gLNQAYhLAMg2IBCARQgPBAgWBEgAL4rsQAEhHAWhGIBBAUQgUA/gDA+gAfKruQgohPgWgnIA8ggIA+B4IABACIg9AegEA1pgNGQAxguAugwIAxAuQgoAsg6A2gEgjAgPPQAIg3AAgyIAAgZIBEgDIAAAcQAAAzgIA/gAb1w4IAwgwQAvAwArA9Ig4AnQgmg4gsgsgANOv8QAmg/AxgyIAxAvQgtAughA3gAYgzFIAZg/QBEAbA6AmIglA5Qg1gig9gZgAQTzJQA+gpBBgYIAYBAQg8AXg2AjgEgkKgU4IA1grQAvA5AYBHIhAAWQgUg7gogwgAUmzoIgIhDQBJgJBHAKIgJBEQg/gJhAAHgEgnWgXSIAeg9QBAAfA5ArIgoA2Qgzgmg8gdgEg34gYgQBMgUA5gNIAPBDQhGAPg9ARgEgrPgYgIAMhDQBFALBDAVIgUBBQg8gThEgLgEgzsgZbQBFgLBEgHIAHBEQg+AGhHAMgEgvXgYxIgChEQBBgCBKAEIgEBEQhGgEg/ACg");
	this.shape_10.setTransform(875.925,383.8417);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#B20016").s().p("AgrgTQAJgFA4gSIAVA/Qg9AWAAAAg");
	this.shape_11.setTransform(502.8,235.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.botonpais1},{t:this.botonpais5},{t:this.botonpais2},{t:this.botonpais4},{t:this.botonpais3}]},9).to({state:[]},1).wait(23));
	this.botonpais3.addEventListener("tick", AdobeAn.handleFilterCache);
	this.botonpais4.addEventListener("tick", AdobeAn.handleFilterCache);
	this.botonpais2.addEventListener("tick", AdobeAn.handleFilterCache);
	this.botonpais5.addEventListener("tick", AdobeAn.handleFilterCache);
	this.botonpais1.addEventListener("tick", AdobeAn.handleFilterCache);

	// Fondo
	this.instance_2 = new lib.FondoPersonaje();
	this.instance_2.setTransform(0,0,0.2396,0.24);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},32).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3049.2,-580.9,7632.7,3394.7000000000003);


// stage content:
(lib.proyectolente = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var escenario = new lib.mc_escenario1();
		this.addChild(escenario);
		
		this.cambiarEscenario = function(nuevoEscenario,variable1){
			this.addChild(nuevoEscenario);
			nuevoEscenario.gotoAndPlay(variable1);
			this.removeChild(escenario);	
			escenario = nuevoEscenario;
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);
// library properties:
lib.properties = {
	id: '146303678F78AE4F82E5FB243DF64578',
	width: 1366,
	height: 768,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/avion.png?1629365601891", id:"avion"},
		{src:"images/Chica.png?1629365601891", id:"Chica"},
		{src:"images/Chico.png?1629365601891", id:"Chico"},
		{src:"images/Fondo1.png?1629365601891", id:"Fondo1"},
		{src:"images/Fondo2.png?1629365601891", id:"Fondo2"},
		{src:"images/Fondo3.png?1629365601891", id:"Fondo3"},
		{src:"images/Fondo4.png?1629365601891", id:"Fondo4"},
		{src:"images/Fondo5.png?1629365601891", id:"Fondo5"},
		{src:"images/FondoPersonaje.png?1629365601891", id:"FondoPersonaje"},
		{src:"images/Intro1366768.png?1629365601891", id:"Intro1366768"},
		{src:"images/Intro21366768.png?1629365601891", id:"Intro21366768"},
		{src:"images/IntroTitulo1366768.png?1629365601891", id:"IntroTitulo1366768"},
		{src:"images/TextosInicial2.png?1629365601891", id:"TextosInicial2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['146303678F78AE4F82E5FB243DF64578'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;